/*
 * jQuery JavaScript Library v1.3.2
 * http://jquery.com/
 *
 * Copyright (c) 2009 John Resig
 * Dual licensed under the MIT and GPL licenses.
 * http://docs.jquery.com/License
 *
 * Date: 2009-02-19 17:34:21 -0500 (Thu, 19 Feb 2009)
 * Revision: 6246
 */
(function(){var l=this,g,y=l.jQuery,p=l.$,o=l.jQuery=l.$=function(E,F){return new o.fn.init(E,F)},D=/^[^<]*(<(.|\s)+>)[^>]*$|^#([\w-]+)$/,f=/^.[^:#\[\.,]*$/;o.fn=o.prototype={init:function(E,H){E=E||document;if(E.nodeType){this[0]=E;this.length=1;this.context=E;return this}if(typeof E==="string"){var G=D.exec(E);if(G&&(G[1]||!H)){if(G[1]){E=o.clean([G[1]],H)}else{var I=document.getElementById(G[3]);if(I&&I.id!=G[3]){return o().find(E)}var F=o(I||[]);F.context=document;F.selector=E;return F}}else{return o(H).find(E)}}else{if(o.isFunction(E)){return o(document).ready(E)}}if(E.selector&&E.context){this.selector=E.selector;this.context=E.context}return this.setArray(o.isArray(E)?E:o.makeArray(E))},selector:"",jquery:"1.3.2",size:function(){return this.length},get:function(E){return E===g?Array.prototype.slice.call(this):this[E]},pushStack:function(F,H,E){var G=o(F);G.prevObject=this;G.context=this.context;if(H==="find"){G.selector=this.selector+(this.selector?" ":"")+E}else{if(H){G.selector=this.selector+"."+H+"("+E+")"}}return G},setArray:function(E){this.length=0;Array.prototype.push.apply(this,E);return this},each:function(F,E){return o.each(this,F,E)},index:function(E){return o.inArray(E&&E.jquery?E[0]:E,this)},attr:function(F,H,G){var E=F;if(typeof F==="string"){if(H===g){return this[0]&&o[G||"attr"](this[0],F)}else{E={};E[F]=H}}return this.each(function(I){for(F in E){o.attr(G?this.style:this,F,o.prop(this,E[F],G,I,F))}})},css:function(E,F){if((E=="width"||E=="height")&&parseFloat(F)<0){F=g}return this.attr(E,F,"curCSS")},text:function(F){if(typeof F!=="object"&&F!=null){return this.empty().append((this[0]&&this[0].ownerDocument||document).createTextNode(F))}var E="";o.each(F||this,function(){o.each(this.childNodes,function(){if(this.nodeType!=8){E+=this.nodeType!=1?this.nodeValue:o.fn.text([this])}})});return E},wrapAll:function(E){if(this[0]){var F=o(E,this[0].ownerDocument).clone();if(this[0].parentNode){F.insertBefore(this[0])}F.map(function(){var G=this;while(G.firstChild){G=G.firstChild}return G}).append(this)}return this},wrapInner:function(E){return this.each(function(){o(this).contents().wrapAll(E)})},wrap:function(E){return this.each(function(){o(this).wrapAll(E)})},append:function(){return this.domManip(arguments,true,function(E){if(this.nodeType==1){this.appendChild(E)}})},prepend:function(){return this.domManip(arguments,true,function(E){if(this.nodeType==1){this.insertBefore(E,this.firstChild)}})},before:function(){return this.domManip(arguments,false,function(E){this.parentNode.insertBefore(E,this)})},after:function(){return this.domManip(arguments,false,function(E){this.parentNode.insertBefore(E,this.nextSibling)})},end:function(){return this.prevObject||o([])},push:[].push,sort:[].sort,splice:[].splice,find:function(E){if(this.length===1){var F=this.pushStack([],"find",E);F.length=0;o.find(E,this[0],F);return F}else{return this.pushStack(o.unique(o.map(this,function(G){return o.find(E,G)})),"find",E)}},clone:function(G){var E=this.map(function(){if(!o.support.noCloneEvent&&!o.isXMLDoc(this)){var I=this.outerHTML;if(!I){var J=this.ownerDocument.createElement("div");J.appendChild(this.cloneNode(true));I=J.innerHTML}return o.clean([I.replace(/ jQuery\d+="(?:\d+|null)"/g,"").replace(/^\s*/,"")])[0]}else{return this.cloneNode(true)}});if(G===true){var H=this.find("*").andSelf(),F=0;E.find("*").andSelf().each(function(){if(this.nodeName!==H[F].nodeName){return}var I=o.data(H[F],"events");for(var K in I){for(var J in I[K]){o.event.add(this,K,I[K][J],I[K][J].data)}}F++})}return E},filter:function(E){return this.pushStack(o.isFunction(E)&&o.grep(this,function(G,F){return E.call(G,F)})||o.multiFilter(E,o.grep(this,function(F){return F.nodeType===1})),"filter",E)},closest:function(E){var G=o.expr.match.POS.test(E)?o(E):null,F=0;return this.map(function(){var H=this;while(H&&H.ownerDocument){if(G?G.index(H)>-1:o(H).is(E)){o.data(H,"closest",F);return H}H=H.parentNode;F++}})},not:function(E){if(typeof E==="string"){if(f.test(E)){return this.pushStack(o.multiFilter(E,this,true),"not",E)}else{E=o.multiFilter(E,this)}}var F=E.length&&E[E.length-1]!==g&&!E.nodeType;return this.filter(function(){return F?o.inArray(this,E)<0:this!=E})},add:function(E){return this.pushStack(o.unique(o.merge(this.get(),typeof E==="string"?o(E):o.makeArray(E))))},is:function(E){return !!E&&o.multiFilter(E,this).length>0},hasClass:function(E){return !!E&&this.is("."+E)},val:function(K){if(K===g){var E=this[0];if(E){if(o.nodeName(E,"option")){return(E.attributes.value||{}).specified?E.value:E.text}if(o.nodeName(E,"select")){var I=E.selectedIndex,L=[],M=E.options,H=E.type=="select-one";if(I<0){return null}for(var F=H?I:0,J=H?I+1:M.length;F<J;F++){var G=M[F];if(G.selected){K=o(G).val();if(H){return K}L.push(K)}}return L}return(E.value||"").replace(/\r/g,"")}return g}if(typeof K==="number"){K+=""}return this.each(function(){if(this.nodeType!=1){return}if(o.isArray(K)&&/radio|checkbox/.test(this.type)){this.checked=(o.inArray(this.value,K)>=0||o.inArray(this.name,K)>=0)}else{if(o.nodeName(this,"select")){var N=o.makeArray(K);o("option",this).each(function(){this.selected=(o.inArray(this.value,N)>=0||o.inArray(this.text,N)>=0)});if(!N.length){this.selectedIndex=-1}}else{this.value=K}}})},html:function(E){return E===g?(this[0]?this[0].innerHTML.replace(/ jQuery\d+="(?:\d+|null)"/g,""):null):this.empty().append(E)},replaceWith:function(E){return this.after(E).remove()},eq:function(E){return this.slice(E,+E+1)},slice:function(){return this.pushStack(Array.prototype.slice.apply(this,arguments),"slice",Array.prototype.slice.call(arguments).join(","))},map:function(E){return this.pushStack(o.map(this,function(G,F){return E.call(G,F,G)}))},andSelf:function(){return this.add(this.prevObject)},domManip:function(J,M,L){if(this[0]){var I=(this[0].ownerDocument||this[0]).createDocumentFragment(),F=o.clean(J,(this[0].ownerDocument||this[0]),I),H=I.firstChild;if(H){for(var G=0,E=this.length;G<E;G++){L.call(K(this[G],H),this.length>1||G>0?I.cloneNode(true):I)}}if(F){o.each(F,z)}}return this;function K(N,O){return M&&o.nodeName(N,"table")&&o.nodeName(O,"tr")?(N.getElementsByTagName("tbody")[0]||N.appendChild(N.ownerDocument.createElement("tbody"))):N}}};o.fn.init.prototype=o.fn;function z(E,F){if(F.src){o.ajax({url:F.src,async:false,dataType:"script"})}else{o.globalEval(F.text||F.textContent||F.innerHTML||"")}if(F.parentNode){F.parentNode.removeChild(F)}}function e(){return +new Date}o.extend=o.fn.extend=function(){var J=arguments[0]||{},H=1,I=arguments.length,E=false,G;if(typeof J==="boolean"){E=J;J=arguments[1]||{};H=2}if(typeof J!=="object"&&!o.isFunction(J)){J={}}if(I==H){J=this;--H}for(;H<I;H++){if((G=arguments[H])!=null){for(var F in G){var K=J[F],L=G[F];if(J===L){continue}if(E&&L&&typeof L==="object"&&!L.nodeType){J[F]=o.extend(E,K||(L.length!=null?[]:{}),L)}else{if(L!==g){J[F]=L}}}}}return J};var b=/z-?index|font-?weight|opacity|zoom|line-?height/i,q=document.defaultView||{},s=Object.prototype.toString;o.extend({noConflict:function(E){l.$=p;if(E){l.jQuery=y}return o},isFunction:function(E){return s.call(E)==="[object Function]"},isArray:function(E){return s.call(E)==="[object Array]"},isXMLDoc:function(E){return E.nodeType===9&&E.documentElement.nodeName!=="HTML"||!!E.ownerDocument&&o.isXMLDoc(E.ownerDocument)},globalEval:function(G){if(G&&/\S/.test(G)){var F=document.getElementsByTagName("head")[0]||document.documentElement,E=document.createElement("script");E.type="text/javascript";if(o.support.scriptEval){E.appendChild(document.createTextNode(G))}else{E.text=G}F.insertBefore(E,F.firstChild);F.removeChild(E)}},nodeName:function(F,E){return F.nodeName&&F.nodeName.toUpperCase()==E.toUpperCase()},each:function(G,K,F){var E,H=0,I=G.length;if(F){if(I===g){for(E in G){if(K.apply(G[E],F)===false){break}}}else{for(;H<I;){if(K.apply(G[H++],F)===false){break}}}}else{if(I===g){for(E in G){if(K.call(G[E],E,G[E])===false){break}}}else{for(var J=G[0];H<I&&K.call(J,H,J)!==false;J=G[++H]){}}}return G},prop:function(H,I,G,F,E){if(o.isFunction(I)){I=I.call(H,F)}return typeof I==="number"&&G=="curCSS"&&!b.test(E)?I+"px":I},className:{add:function(E,F){o.each((F||"").split(/\s+/),function(G,H){if(E.nodeType==1&&!o.className.has(E.className,H)){E.className+=(E.className?" ":"")+H}})},remove:function(E,F){if(E.nodeType==1){E.className=F!==g?o.grep(E.className.split(/\s+/),function(G){return !o.className.has(F,G)}).join(" "):""}},has:function(F,E){return F&&o.inArray(E,(F.className||F).toString().split(/\s+/))>-1}},swap:function(H,G,I){var E={};for(var F in G){E[F]=H.style[F];H.style[F]=G[F]}I.call(H);for(var F in G){H.style[F]=E[F]}},css:function(H,F,J,E){if(F=="width"||F=="height"){var L,G={position:"absolute",visibility:"hidden",display:"block"},K=F=="width"?["Left","Right"]:["Top","Bottom"];function I(){L=F=="width"?H.offsetWidth:H.offsetHeight;if(E==="border"){return}o.each(K,function(){if(!E){L-=parseFloat(o.curCSS(H,"padding"+this,true))||0}if(E==="margin"){L+=parseFloat(o.curCSS(H,"margin"+this,true))||0}else{L-=parseFloat(o.curCSS(H,"border"+this+"Width",true))||0}})}if(H.offsetWidth!==0){I()}else{o.swap(H,G,I)}return Math.max(0,Math.round(L))}return o.curCSS(H,F,J)},curCSS:function(I,F,G){var L,E=I.style;if(F=="opacity"&&!o.support.opacity){L=o.attr(E,"opacity");return L==""?"1":L}if(F.match(/float/i)){F=w}if(!G&&E&&E[F]){L=E[F]}else{if(q.getComputedStyle){if(F.match(/float/i)){F="float"}F=F.replace(/([A-Z])/g,"-$1").toLowerCase();var M=q.getComputedStyle(I,null);if(M){L=M.getPropertyValue(F)}if(F=="opacity"&&L==""){L="1"}}else{if(I.currentStyle){var J=F.replace(/\-(\w)/g,function(N,O){return O.toUpperCase()});L=I.currentStyle[F]||I.currentStyle[J];if(!/^\d+(px)?$/i.test(L)&&/^\d/.test(L)){var H=E.left,K=I.runtimeStyle.left;I.runtimeStyle.left=I.currentStyle.left;E.left=L||0;L=E.pixelLeft+"px";E.left=H;I.runtimeStyle.left=K}}}}return L},clean:function(F,K,I){K=K||document;if(typeof K.createElement==="undefined"){K=K.ownerDocument||K[0]&&K[0].ownerDocument||document}if(!I&&F.length===1&&typeof F[0]==="string"){var H=/^<(\w+)\s*\/?>$/.exec(F[0]);if(H){return[K.createElement(H[1])]}}var G=[],E=[],L=K.createElement("div");o.each(F,function(P,S){if(typeof S==="number"){S+=""}if(!S){return}if(typeof S==="string"){S=S.replace(/(<(\w+)[^>]*?)\/>/g,function(U,V,T){return T.match(/^(abbr|br|col|img|input|link|meta|param|hr|area|embed)$/i)?U:V+"></"+T+">"});var O=S.replace(/^\s+/,"").substring(0,10).toLowerCase();var Q=!O.indexOf("<opt")&&[1,"<select multiple='multiple'>","</select>"]||!O.indexOf("<leg")&&[1,"<fieldset>","</fieldset>"]||O.match(/^<(thead|tbody|tfoot|colg|cap)/)&&[1,"<table>","</table>"]||!O.indexOf("<tr")&&[2,"<table><tbody>","</tbody></table>"]||(!O.indexOf("<td")||!O.indexOf("<th"))&&[3,"<table><tbody><tr>","</tr></tbody></table>"]||!O.indexOf("<col")&&[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"]||!o.support.htmlSerialize&&[1,"div<div>","</div>"]||[0,"",""];L.innerHTML=Q[1]+S+Q[2];while(Q[0]--){L=L.lastChild}if(!o.support.tbody){var R=/<tbody/i.test(S),N=!O.indexOf("<table")&&!R?L.firstChild&&L.firstChild.childNodes:Q[1]=="<table>"&&!R?L.childNodes:[];for(var M=N.length-1;M>=0;--M){if(o.nodeName(N[M],"tbody")&&!N[M].childNodes.length){N[M].parentNode.removeChild(N[M])}}}if(!o.support.leadingWhitespace&&/^\s/.test(S)){L.insertBefore(K.createTextNode(S.match(/^\s*/)[0]),L.firstChild)}S=o.makeArray(L.childNodes)}if(S.nodeType){G.push(S)}else{G=o.merge(G,S)}});if(I){for(var J=0;G[J];J++){if(o.nodeName(G[J],"script")&&(!G[J].type||G[J].type.toLowerCase()==="text/javascript")){E.push(G[J].parentNode?G[J].parentNode.removeChild(G[J]):G[J])}else{if(G[J].nodeType===1){G.splice.apply(G,[J+1,0].concat(o.makeArray(G[J].getElementsByTagName("script"))))}I.appendChild(G[J])}}return E}return G},attr:function(J,G,K){if(!J||J.nodeType==3||J.nodeType==8){return g}var H=!o.isXMLDoc(J),L=K!==g;G=H&&o.props[G]||G;if(J.tagName){var F=/href|src|style/.test(G);if(G=="selected"&&J.parentNode){J.parentNode.selectedIndex}if(G in J&&H&&!F){if(L){if(G=="type"&&o.nodeName(J,"input")&&J.parentNode){throw"type property can't be changed"}J[G]=K}if(o.nodeName(J,"form")&&J.getAttributeNode(G)){return J.getAttributeNode(G).nodeValue}if(G=="tabIndex"){var I=J.getAttributeNode("tabIndex");return I&&I.specified?I.value:J.nodeName.match(/(button|input|object|select|textarea)/i)?0:J.nodeName.match(/^(a|area)$/i)&&J.href?0:g}return J[G]}if(!o.support.style&&H&&G=="style"){return o.attr(J.style,"cssText",K)}if(L){J.setAttribute(G,""+K)}var E=!o.support.hrefNormalized&&H&&F?J.getAttribute(G,2):J.getAttribute(G);return E===null?g:E}if(!o.support.opacity&&G=="opacity"){if(L){J.zoom=1;J.filter=(J.filter||"").replace(/alpha\([^)]*\)/,"")+(parseInt(K)+""=="NaN"?"":"alpha(opacity="+K*100+")")}return J.filter&&J.filter.indexOf("opacity=")>=0?(parseFloat(J.filter.match(/opacity=([^)]*)/)[1])/100)+"":""}G=G.replace(/-([a-z])/ig,function(M,N){return N.toUpperCase()});if(L){J[G]=K}return J[G]},trim:function(E){return(E||"").replace(/^\s+|\s+$/g,"")},makeArray:function(G){var E=[];if(G!=null){var F=G.length;if(F==null||typeof G==="string"||o.isFunction(G)||G.setInterval){E[0]=G}else{while(F){E[--F]=G[F]}}}return E},inArray:function(G,H){for(var E=0,F=H.length;E<F;E++){if(H[E]===G){return E}}return -1},merge:function(H,E){var F=0,G,I=H.length;if(!o.support.getAll){while((G=E[F++])!=null){if(G.nodeType!=8){H[I++]=G}}}else{while((G=E[F++])!=null){H[I++]=G}}return H},unique:function(K){var F=[],E={};try{for(var G=0,H=K.length;G<H;G++){var J=o.data(K[G]);if(!E[J]){E[J]=true;F.push(K[G])}}}catch(I){F=K}return F},grep:function(F,J,E){var G=[];for(var H=0,I=F.length;H<I;H++){if(!E!=!J(F[H],H)){G.push(F[H])}}return G},map:function(E,J){var F=[];for(var G=0,H=E.length;G<H;G++){var I=J(E[G],G);if(I!=null){F[F.length]=I}}return F.concat.apply([],F)}});var C=navigator.userAgent.toLowerCase();o.browser={version:(C.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/)||[0,"0"])[1],safari:/webkit/.test(C),opera:/opera/.test(C),msie:/msie/.test(C)&&!/opera/.test(C),mozilla:/mozilla/.test(C)&&!/(compatible|webkit)/.test(C)};o.each({parent:function(E){return E.parentNode},parents:function(E){return o.dir(E,"parentNode")},next:function(E){return o.nth(E,2,"nextSibling")},prev:function(E){return o.nth(E,2,"previousSibling")},nextAll:function(E){return o.dir(E,"nextSibling")},prevAll:function(E){return o.dir(E,"previousSibling")},siblings:function(E){return o.sibling(E.parentNode.firstChild,E)},children:function(E){return o.sibling(E.firstChild)},contents:function(E){return o.nodeName(E,"iframe")?E.contentDocument||E.contentWindow.document:o.makeArray(E.childNodes)}},function(E,F){o.fn[E]=function(G){var H=o.map(this,F);if(G&&typeof G=="string"){H=o.multiFilter(G,H)}return this.pushStack(o.unique(H),E,G)}});o.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(E,F){o.fn[E]=function(G){var J=[],L=o(G);for(var K=0,H=L.length;K<H;K++){var I=(K>0?this.clone(true):this).get();o.fn[F].apply(o(L[K]),I);J=J.concat(I)}return this.pushStack(J,E,G)}});o.each({removeAttr:function(E){o.attr(this,E,"");if(this.nodeType==1){this.removeAttribute(E)}},addClass:function(E){o.className.add(this,E)},removeClass:function(E){o.className.remove(this,E)},toggleClass:function(F,E){if(typeof E!=="boolean"){E=!o.className.has(this,F)}o.className[E?"add":"remove"](this,F)},remove:function(E){if(!E||o.filter(E,[this]).length){o("*",this).add([this]).each(function(){o.event.remove(this);o.removeData(this)});if(this.parentNode){this.parentNode.removeChild(this)}}},empty:function(){o(this).children().remove();while(this.firstChild){this.removeChild(this.firstChild)}}},function(E,F){o.fn[E]=function(){return this.each(F,arguments)}});function j(E,F){return E[0]&&parseInt(o.curCSS(E[0],F,true),10)||0}var h="jQuery"+e(),v=0,A={};o.extend({cache:{},data:function(F,E,G){F=F==l?A:F;var H=F[h];if(!H){H=F[h]=++v}if(E&&!o.cache[H]){o.cache[H]={}}if(G!==g){o.cache[H][E]=G}return E?o.cache[H][E]:H},removeData:function(F,E){F=F==l?A:F;var H=F[h];if(E){if(o.cache[H]){delete o.cache[H][E];E="";for(E in o.cache[H]){break}if(!E){o.removeData(F)}}}else{try{delete F[h]}catch(G){if(F.removeAttribute){F.removeAttribute(h)}}delete o.cache[H]}},queue:function(F,E,H){if(F){E=(E||"fx")+"queue";var G=o.data(F,E);if(!G||o.isArray(H)){G=o.data(F,E,o.makeArray(H))}else{if(H){G.push(H)}}}return G},dequeue:function(H,G){var E=o.queue(H,G),F=E.shift();if(!G||G==="fx"){F=E[0]}if(F!==g){F.call(H)}}});o.fn.extend({data:function(E,G){var H=E.split(".");H[1]=H[1]?"."+H[1]:"";if(G===g){var F=this.triggerHandler("getData"+H[1]+"!",[H[0]]);if(F===g&&this.length){F=o.data(this[0],E)}return F===g&&H[1]?this.data(H[0]):F}else{return this.trigger("setData"+H[1]+"!",[H[0],G]).each(function(){o.data(this,E,G)})}},removeData:function(E){return this.each(function(){o.removeData(this,E)})},queue:function(E,F){if(typeof E!=="string"){F=E;E="fx"}if(F===g){return o.queue(this[0],E)}return this.each(function(){var G=o.queue(this,E,F);if(E=="fx"&&G.length==1){G[0].call(this)}})},dequeue:function(E){return this.each(function(){o.dequeue(this,E)})}});
/*
 * Sizzle CSS Selector Engine - v0.9.3
 *  Copyright 2009, The Dojo Foundation
 *  Released under the MIT, BSD, and GPL Licenses.
 *  More information: http://sizzlejs.com/
 */
(function(){var R=/((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^[\]]*\]|['"][^'"]*['"]|[^[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?/g,L=0,H=Object.prototype.toString;var F=function(Y,U,ab,ac){ab=ab||[];U=U||document;if(U.nodeType!==1&&U.nodeType!==9){return[]}if(!Y||typeof Y!=="string"){return ab}var Z=[],W,af,ai,T,ad,V,X=true;R.lastIndex=0;while((W=R.exec(Y))!==null){Z.push(W[1]);if(W[2]){V=RegExp.rightContext;break}}if(Z.length>1&&M.exec(Y)){if(Z.length===2&&I.relative[Z[0]]){af=J(Z[0]+Z[1],U)}else{af=I.relative[Z[0]]?[U]:F(Z.shift(),U);while(Z.length){Y=Z.shift();if(I.relative[Y]){Y+=Z.shift()}af=J(Y,af)}}}else{var ae=ac?{expr:Z.pop(),set:E(ac)}:F.find(Z.pop(),Z.length===1&&U.parentNode?U.parentNode:U,Q(U));af=F.filter(ae.expr,ae.set);if(Z.length>0){ai=E(af)}else{X=false}while(Z.length){var ah=Z.pop(),ag=ah;if(!I.relative[ah]){ah=""}else{ag=Z.pop()}if(ag==null){ag=U}I.relative[ah](ai,ag,Q(U))}}if(!ai){ai=af}if(!ai){throw"Syntax error, unrecognized expression: "+(ah||Y)}if(H.call(ai)==="[object Array]"){if(!X){ab.push.apply(ab,ai)}else{if(U.nodeType===1){for(var aa=0;ai[aa]!=null;aa++){if(ai[aa]&&(ai[aa]===true||ai[aa].nodeType===1&&K(U,ai[aa]))){ab.push(af[aa])}}}else{for(var aa=0;ai[aa]!=null;aa++){if(ai[aa]&&ai[aa].nodeType===1){ab.push(af[aa])}}}}}else{E(ai,ab)}if(V){F(V,U,ab,ac);if(G){hasDuplicate=false;ab.sort(G);if(hasDuplicate){for(var aa=1;aa<ab.length;aa++){if(ab[aa]===ab[aa-1]){ab.splice(aa--,1)}}}}}return ab};F.matches=function(T,U){return F(T,null,null,U)};F.find=function(aa,T,ab){var Z,X;if(!aa){return[]}for(var W=0,V=I.order.length;W<V;W++){var Y=I.order[W],X;if((X=I.match[Y].exec(aa))){var U=RegExp.leftContext;if(U.substr(U.length-1)!=="\\"){X[1]=(X[1]||"").replace(/\\/g,"");Z=I.find[Y](X,T,ab);if(Z!=null){aa=aa.replace(I.match[Y],"");break}}}}if(!Z){Z=T.getElementsByTagName("*")}return{set:Z,expr:aa}};F.filter=function(ad,ac,ag,W){var V=ad,ai=[],aa=ac,Y,T,Z=ac&&ac[0]&&Q(ac[0]);while(ad&&ac.length){for(var ab in I.filter){if((Y=I.match[ab].exec(ad))!=null){var U=I.filter[ab],ah,af;T=false;if(aa==ai){ai=[]}if(I.preFilter[ab]){Y=I.preFilter[ab](Y,aa,ag,ai,W,Z);if(!Y){T=ah=true}else{if(Y===true){continue}}}if(Y){for(var X=0;(af=aa[X])!=null;X++){if(af){ah=U(af,Y,X,aa);var ae=W^!!ah;if(ag&&ah!=null){if(ae){T=true}else{aa[X]=false}}else{if(ae){ai.push(af);T=true}}}}}if(ah!==g){if(!ag){aa=ai}ad=ad.replace(I.match[ab],"");if(!T){return[]}break}}}if(ad==V){if(T==null){throw"Syntax error, unrecognized expression: "+ad}else{break}}V=ad}return aa};var I=F.selectors={order:["ID","NAME","TAG"],match:{ID:/#((?:[\w\u00c0-\uFFFF_-]|\\.)+)/,CLASS:/\.((?:[\w\u00c0-\uFFFF_-]|\\.)+)/,NAME:/\[name=['"]*((?:[\w\u00c0-\uFFFF_-]|\\.)+)['"]*\]/,ATTR:/\[\s*((?:[\w\u00c0-\uFFFF_-]|\\.)+)\s*(?:(\S?=)\s*(['"]*)(.*?)\3|)\s*\]/,TAG:/^((?:[\w\u00c0-\uFFFF\*_-]|\\.)+)/,CHILD:/:(only|nth|last|first)-child(?:\((even|odd|[\dn+-]*)\))?/,POS:/:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^-]|$)/,PSEUDO:/:((?:[\w\u00c0-\uFFFF_-]|\\.)+)(?:\((['"]*)((?:\([^\)]+\)|[^\2\(\)]*)+)\2\))?/},attrMap:{"class":"className","for":"htmlFor"},attrHandle:{href:function(T){return T.getAttribute("href")}},relative:{"+":function(aa,T,Z){var X=typeof T==="string",ab=X&&!/\W/.test(T),Y=X&&!ab;if(ab&&!Z){T=T.toUpperCase()}for(var W=0,V=aa.length,U;W<V;W++){if((U=aa[W])){while((U=U.previousSibling)&&U.nodeType!==1){}aa[W]=Y||U&&U.nodeName===T?U||false:U===T}}if(Y){F.filter(T,aa,true)}},">":function(Z,U,aa){var X=typeof U==="string";if(X&&!/\W/.test(U)){U=aa?U:U.toUpperCase();for(var V=0,T=Z.length;V<T;V++){var Y=Z[V];if(Y){var W=Y.parentNode;Z[V]=W.nodeName===U?W:false}}}else{for(var V=0,T=Z.length;V<T;V++){var Y=Z[V];if(Y){Z[V]=X?Y.parentNode:Y.parentNode===U}}if(X){F.filter(U,Z,true)}}},"":function(W,U,Y){var V=L++,T=S;if(!U.match(/\W/)){var X=U=Y?U:U.toUpperCase();T=P}T("parentNode",U,V,W,X,Y)},"~":function(W,U,Y){var V=L++,T=S;if(typeof U==="string"&&!U.match(/\W/)){var X=U=Y?U:U.toUpperCase();T=P}T("previousSibling",U,V,W,X,Y)}},find:{ID:function(U,V,W){if(typeof V.getElementById!=="undefined"&&!W){var T=V.getElementById(U[1]);return T?[T]:[]}},NAME:function(V,Y,Z){if(typeof Y.getElementsByName!=="undefined"){var U=[],X=Y.getElementsByName(V[1]);for(var W=0,T=X.length;W<T;W++){if(X[W].getAttribute("name")===V[1]){U.push(X[W])}}return U.length===0?null:U}},TAG:function(T,U){return U.getElementsByTagName(T[1])}},preFilter:{CLASS:function(W,U,V,T,Z,aa){W=" "+W[1].replace(/\\/g,"")+" ";if(aa){return W}for(var X=0,Y;(Y=U[X])!=null;X++){if(Y){if(Z^(Y.className&&(" "+Y.className+" ").indexOf(W)>=0)){if(!V){T.push(Y)}}else{if(V){U[X]=false}}}}return false},ID:function(T){return T[1].replace(/\\/g,"")},TAG:function(U,T){for(var V=0;T[V]===false;V++){}return T[V]&&Q(T[V])?U[1]:U[1].toUpperCase()},CHILD:function(T){if(T[1]=="nth"){var U=/(-?)(\d*)n((?:\+|-)?\d*)/.exec(T[2]=="even"&&"2n"||T[2]=="odd"&&"2n+1"||!/\D/.test(T[2])&&"0n+"+T[2]||T[2]);T[2]=(U[1]+(U[2]||1))-0;T[3]=U[3]-0}T[0]=L++;return T},ATTR:function(X,U,V,T,Y,Z){var W=X[1].replace(/\\/g,"");if(!Z&&I.attrMap[W]){X[1]=I.attrMap[W]}if(X[2]==="~="){X[4]=" "+X[4]+" "}return X},PSEUDO:function(X,U,V,T,Y){if(X[1]==="not"){if(X[3].match(R).length>1||/^\w/.test(X[3])){X[3]=F(X[3],null,null,U)}else{var W=F.filter(X[3],U,V,true^Y);if(!V){T.push.apply(T,W)}return false}}else{if(I.match.POS.test(X[0])||I.match.CHILD.test(X[0])){return true}}return X},POS:function(T){T.unshift(true);return T}},filters:{enabled:function(T){return T.disabled===false&&T.type!=="hidden"},disabled:function(T){return T.disabled===true},checked:function(T){return T.checked===true},selected:function(T){T.parentNode.selectedIndex;return T.selected===true},parent:function(T){return !!T.firstChild},empty:function(T){return !T.firstChild},has:function(V,U,T){return !!F(T[3],V).length},header:function(T){return/h\d/i.test(T.nodeName)},text:function(T){return"text"===T.type},radio:function(T){return"radio"===T.type},checkbox:function(T){return"checkbox"===T.type},file:function(T){return"file"===T.type},password:function(T){return"password"===T.type},submit:function(T){return"submit"===T.type},image:function(T){return"image"===T.type},reset:function(T){return"reset"===T.type},button:function(T){return"button"===T.type||T.nodeName.toUpperCase()==="BUTTON"},input:function(T){return/input|select|textarea|button/i.test(T.nodeName)}},setFilters:{first:function(U,T){return T===0},last:function(V,U,T,W){return U===W.length-1},even:function(U,T){return T%2===0},odd:function(U,T){return T%2===1},lt:function(V,U,T){return U<T[3]-0},gt:function(V,U,T){return U>T[3]-0},nth:function(V,U,T){return T[3]-0==U},eq:function(V,U,T){return T[3]-0==U}},filter:{PSEUDO:function(Z,V,W,aa){var U=V[1],X=I.filters[U];if(X){return X(Z,W,V,aa)}else{if(U==="contains"){return(Z.textContent||Z.innerText||"").indexOf(V[3])>=0}else{if(U==="not"){var Y=V[3];for(var W=0,T=Y.length;W<T;W++){if(Y[W]===Z){return false}}return true}}}},CHILD:function(T,W){var Z=W[1],U=T;switch(Z){case"only":case"first":while(U=U.previousSibling){if(U.nodeType===1){return false}}if(Z=="first"){return true}U=T;case"last":while(U=U.nextSibling){if(U.nodeType===1){return false}}return true;case"nth":var V=W[2],ac=W[3];if(V==1&&ac==0){return true}var Y=W[0],ab=T.parentNode;if(ab&&(ab.sizcache!==Y||!T.nodeIndex)){var X=0;for(U=ab.firstChild;U;U=U.nextSibling){if(U.nodeType===1){U.nodeIndex=++X}}ab.sizcache=Y}var aa=T.nodeIndex-ac;if(V==0){return aa==0}else{return(aa%V==0&&aa/V>=0)}}},ID:function(U,T){return U.nodeType===1&&U.getAttribute("id")===T},TAG:function(U,T){return(T==="*"&&U.nodeType===1)||U.nodeName===T},CLASS:function(U,T){return(" "+(U.className||U.getAttribute("class"))+" ").indexOf(T)>-1},ATTR:function(Y,W){var V=W[1],T=I.attrHandle[V]?I.attrHandle[V](Y):Y[V]!=null?Y[V]:Y.getAttribute(V),Z=T+"",X=W[2],U=W[4];return T==null?X==="!=":X==="="?Z===U:X==="*="?Z.indexOf(U)>=0:X==="~="?(" "+Z+" ").indexOf(U)>=0:!U?Z&&T!==false:X==="!="?Z!=U:X==="^="?Z.indexOf(U)===0:X==="$="?Z.substr(Z.length-U.length)===U:X==="|="?Z===U||Z.substr(0,U.length+1)===U+"-":false},POS:function(X,U,V,Y){var T=U[2],W=I.setFilters[T];if(W){return W(X,V,U,Y)}}}};var M=I.match.POS;for(var O in I.match){I.match[O]=RegExp(I.match[O].source+/(?![^\[]*\])(?![^\(]*\))/.source)}var E=function(U,T){U=Array.prototype.slice.call(U);if(T){T.push.apply(T,U);return T}return U};try{Array.prototype.slice.call(document.documentElement.childNodes)}catch(N){E=function(X,W){var U=W||[];if(H.call(X)==="[object Array]"){Array.prototype.push.apply(U,X)}else{if(typeof X.length==="number"){for(var V=0,T=X.length;V<T;V++){U.push(X[V])}}else{for(var V=0;X[V];V++){U.push(X[V])}}}return U}}var G;if(document.documentElement.compareDocumentPosition){G=function(U,T){var V=U.compareDocumentPosition(T)&4?-1:U===T?0:1;if(V===0){hasDuplicate=true}return V}}else{if("sourceIndex" in document.documentElement){G=function(U,T){var V=U.sourceIndex-T.sourceIndex;if(V===0){hasDuplicate=true}return V}}else{if(document.createRange){G=function(W,U){var V=W.ownerDocument.createRange(),T=U.ownerDocument.createRange();V.selectNode(W);V.collapse(true);T.selectNode(U);T.collapse(true);var X=V.compareBoundaryPoints(Range.START_TO_END,T);if(X===0){hasDuplicate=true}return X}}}}(function(){var U=document.createElement("form"),V="script"+(new Date).getTime();U.innerHTML="<input name='"+V+"'/>";var T=document.documentElement;T.insertBefore(U,T.firstChild);if(!!document.getElementById(V)){I.find.ID=function(X,Y,Z){if(typeof Y.getElementById!=="undefined"&&!Z){var W=Y.getElementById(X[1]);return W?W.id===X[1]||typeof W.getAttributeNode!=="undefined"&&W.getAttributeNode("id").nodeValue===X[1]?[W]:g:[]}};I.filter.ID=function(Y,W){var X=typeof Y.getAttributeNode!=="undefined"&&Y.getAttributeNode("id");return Y.nodeType===1&&X&&X.nodeValue===W}}T.removeChild(U)})();(function(){var T=document.createElement("div");T.appendChild(document.createComment(""));if(T.getElementsByTagName("*").length>0){I.find.TAG=function(U,Y){var X=Y.getElementsByTagName(U[1]);if(U[1]==="*"){var W=[];for(var V=0;X[V];V++){if(X[V].nodeType===1){W.push(X[V])}}X=W}return X}}T.innerHTML="<a href='#'></a>";if(T.firstChild&&typeof T.firstChild.getAttribute!=="undefined"&&T.firstChild.getAttribute("href")!=="#"){I.attrHandle.href=function(U){return U.getAttribute("href",2)}}})();if(document.querySelectorAll){(function(){var T=F,U=document.createElement("div");U.innerHTML="<p class='TEST'></p>";if(U.querySelectorAll&&U.querySelectorAll(".TEST").length===0){return}F=function(Y,X,V,W){X=X||document;if(!W&&X.nodeType===9&&!Q(X)){try{return E(X.querySelectorAll(Y),V)}catch(Z){}}return T(Y,X,V,W)};F.find=T.find;F.filter=T.filter;F.selectors=T.selectors;F.matches=T.matches})()}if(document.getElementsByClassName&&document.documentElement.getElementsByClassName){(function(){var T=document.createElement("div");T.innerHTML="<div class='test e'></div><div class='test'></div>";if(T.getElementsByClassName("e").length===0){return}T.lastChild.className="e";if(T.getElementsByClassName("e").length===1){return}I.order.splice(1,0,"CLASS");I.find.CLASS=function(U,V,W){if(typeof V.getElementsByClassName!=="undefined"&&!W){return V.getElementsByClassName(U[1])}}})()}function P(U,Z,Y,ad,aa,ac){var ab=U=="previousSibling"&&!ac;for(var W=0,V=ad.length;W<V;W++){var T=ad[W];if(T){if(ab&&T.nodeType===1){T.sizcache=Y;T.sizset=W}T=T[U];var X=false;while(T){if(T.sizcache===Y){X=ad[T.sizset];break}if(T.nodeType===1&&!ac){T.sizcache=Y;T.sizset=W}if(T.nodeName===Z){X=T;break}T=T[U]}ad[W]=X}}}function S(U,Z,Y,ad,aa,ac){var ab=U=="previousSibling"&&!ac;for(var W=0,V=ad.length;W<V;W++){var T=ad[W];if(T){if(ab&&T.nodeType===1){T.sizcache=Y;T.sizset=W}T=T[U];var X=false;while(T){if(T.sizcache===Y){X=ad[T.sizset];break}if(T.nodeType===1){if(!ac){T.sizcache=Y;T.sizset=W}if(typeof Z!=="string"){if(T===Z){X=true;break}}else{if(F.filter(Z,[T]).length>0){X=T;break}}}T=T[U]}ad[W]=X}}}var K=document.compareDocumentPosition?function(U,T){return U.compareDocumentPosition(T)&16}:function(U,T){return U!==T&&(U.contains?U.contains(T):true)};var Q=function(T){return T.nodeType===9&&T.documentElement.nodeName!=="HTML"||!!T.ownerDocument&&Q(T.ownerDocument)};var J=function(T,aa){var W=[],X="",Y,V=aa.nodeType?[aa]:aa;while((Y=I.match.PSEUDO.exec(T))){X+=Y[0];T=T.replace(I.match.PSEUDO,"")}T=I.relative[T]?T+"*":T;for(var Z=0,U=V.length;Z<U;Z++){F(T,V[Z],W)}return F.filter(X,W)};o.find=F;o.filter=F.filter;o.expr=F.selectors;o.expr[":"]=o.expr.filters;F.selectors.filters.hidden=function(T){return T.offsetWidth===0||T.offsetHeight===0};F.selectors.filters.visible=function(T){return T.offsetWidth>0||T.offsetHeight>0};F.selectors.filters.animated=function(T){return o.grep(o.timers,function(U){return T===U.elem}).length};o.multiFilter=function(V,T,U){if(U){V=":not("+V+")"}return F.matches(V,T)};o.dir=function(V,U){var T=[],W=V[U];while(W&&W!=document){if(W.nodeType==1){T.push(W)}W=W[U]}return T};o.nth=function(X,T,V,W){T=T||1;var U=0;for(;X;X=X[V]){if(X.nodeType==1&&++U==T){break}}return X};o.sibling=function(V,U){var T=[];for(;V;V=V.nextSibling){if(V.nodeType==1&&V!=U){T.push(V)}}return T};return;l.Sizzle=F})();o.event={add:function(I,F,H,K){if(I.nodeType==3||I.nodeType==8){return}if(I.setInterval&&I!=l){I=l}if(!H.guid){H.guid=this.guid++}if(K!==g){var G=H;H=this.proxy(G);H.data=K}var E=o.data(I,"events")||o.data(I,"events",{}),J=o.data(I,"handle")||o.data(I,"handle",function(){return typeof o!=="undefined"&&!o.event.triggered?o.event.handle.apply(arguments.callee.elem,arguments):g});J.elem=I;o.each(F.split(/\s+/),function(M,N){var O=N.split(".");N=O.shift();H.type=O.slice().sort().join(".");var L=E[N];if(o.event.specialAll[N]){o.event.specialAll[N].setup.call(I,K,O)}if(!L){L=E[N]={};if(!o.event.special[N]||o.event.special[N].setup.call(I,K,O)===false){if(I.addEventListener){I.addEventListener(N,J,false)}else{if(I.attachEvent){I.attachEvent("on"+N,J)}}}}L[H.guid]=H;o.event.global[N]=true});I=null},guid:1,global:{},remove:function(K,H,J){if(K.nodeType==3||K.nodeType==8){return}var G=o.data(K,"events"),F,E;if(G){if(H===g||(typeof H==="string"&&H.charAt(0)==".")){for(var I in G){this.remove(K,I+(H||""))}}else{if(H.type){J=H.handler;H=H.type}o.each(H.split(/\s+/),function(M,O){var Q=O.split(".");O=Q.shift();var N=RegExp("(^|\\.)"+Q.slice().sort().join(".*\\.")+"(\\.|$)");if(G[O]){if(J){delete G[O][J.guid]}else{for(var P in G[O]){if(N.test(G[O][P].type)){delete G[O][P]}}}if(o.event.specialAll[O]){o.event.specialAll[O].teardown.call(K,Q)}for(F in G[O]){break}if(!F){if(!o.event.special[O]||o.event.special[O].teardown.call(K,Q)===false){if(K.removeEventListener){K.removeEventListener(O,o.data(K,"handle"),false)}else{if(K.detachEvent){K.detachEvent("on"+O,o.data(K,"handle"))}}}F=null;delete G[O]}}})}for(F in G){break}if(!F){var L=o.data(K,"handle");if(L){L.elem=null}o.removeData(K,"events");o.removeData(K,"handle")}}},trigger:function(I,K,H,E){var G=I.type||I;if(!E){I=typeof I==="object"?I[h]?I:o.extend(o.Event(G),I):o.Event(G);if(G.indexOf("!")>=0){I.type=G=G.slice(0,-1);I.exclusive=true}if(!H){I.stopPropagation();if(this.global[G]){o.each(o.cache,function(){if(this.events&&this.events[G]){o.event.trigger(I,K,this.handle.elem)}})}}if(!H||H.nodeType==3||H.nodeType==8){return g}I.result=g;I.target=H;K=o.makeArray(K);K.unshift(I)}I.currentTarget=H;var J=o.data(H,"handle");if(J){J.apply(H,K)}if((!H[G]||(o.nodeName(H,"a")&&G=="click"))&&H["on"+G]&&H["on"+G].apply(H,K)===false){I.result=false}if(!E&&H[G]&&!I.isDefaultPrevented()&&!(o.nodeName(H,"a")&&G=="click")){this.triggered=true;try{H[G]()}catch(L){}}this.triggered=false;if(!I.isPropagationStopped()){var F=H.parentNode||H.ownerDocument;if(F){o.event.trigger(I,K,F,true)}}},handle:function(K){var J,E;K=arguments[0]=o.event.fix(K||l.event);K.currentTarget=this;var L=K.type.split(".");K.type=L.shift();J=!L.length&&!K.exclusive;var I=RegExp("(^|\\.)"+L.slice().sort().join(".*\\.")+"(\\.|$)");E=(o.data(this,"events")||{})[K.type];for(var G in E){var H=E[G];if(J||I.test(H.type)){K.handler=H;K.data=H.data;var F=H.apply(this,arguments);if(F!==g){K.result=F;if(F===false){K.preventDefault();K.stopPropagation()}}if(K.isImmediatePropagationStopped()){break}}}},props:"altKey attrChange attrName bubbles button cancelable charCode clientX clientY ctrlKey currentTarget data detail eventPhase fromElement handler keyCode metaKey newValue originalTarget pageX pageY prevValue relatedNode relatedTarget screenX screenY shiftKey srcElement target toElement view wheelDelta which".split(" "),fix:function(H){if(H[h]){return H}var F=H;H=o.Event(F);for(var G=this.props.length,J;G;){J=this.props[--G];H[J]=F[J]}if(!H.target){H.target=H.srcElement||document}if(H.target.nodeType==3){H.target=H.target.parentNode}if(!H.relatedTarget&&H.fromElement){H.relatedTarget=H.fromElement==H.target?H.toElement:H.fromElement}if(H.pageX==null&&H.clientX!=null){var I=document.documentElement,E=document.body;H.pageX=H.clientX+(I&&I.scrollLeft||E&&E.scrollLeft||0)-(I.clientLeft||0);H.pageY=H.clientY+(I&&I.scrollTop||E&&E.scrollTop||0)-(I.clientTop||0)}if(!H.which&&((H.charCode||H.charCode===0)?H.charCode:H.keyCode)){H.which=H.charCode||H.keyCode}if(!H.metaKey&&H.ctrlKey){H.metaKey=H.ctrlKey}if(!H.which&&H.button){H.which=(H.button&1?1:(H.button&2?3:(H.button&4?2:0)))}return H},proxy:function(F,E){E=E||function(){return F.apply(this,arguments)};E.guid=F.guid=F.guid||E.guid||this.guid++;return E},special:{ready:{setup:B,teardown:function(){}}},specialAll:{live:{setup:function(E,F){o.event.add(this,F[0],c)},teardown:function(G){if(G.length){var E=0,F=RegExp("(^|\\.)"+G[0]+"(\\.|$)");o.each((o.data(this,"events").live||{}),function(){if(F.test(this.type)){E++}});if(E<1){o.event.remove(this,G[0],c)}}}}}};o.Event=function(E){if(!this.preventDefault){return new o.Event(E)}if(E&&E.type){this.originalEvent=E;this.type=E.type}else{this.type=E}this.timeStamp=e();this[h]=true};function k(){return false}function u(){return true}o.Event.prototype={preventDefault:function(){this.isDefaultPrevented=u;var E=this.originalEvent;if(!E){return}if(E.preventDefault){E.preventDefault()}E.returnValue=false},stopPropagation:function(){this.isPropagationStopped=u;var E=this.originalEvent;if(!E){return}if(E.stopPropagation){E.stopPropagation()}E.cancelBubble=true},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=u;this.stopPropagation()},isDefaultPrevented:k,isPropagationStopped:k,isImmediatePropagationStopped:k};var a=function(F){var E=F.relatedTarget;while(E&&E!=this){try{E=E.parentNode}catch(G){E=this}}if(E!=this){F.type=F.data;o.event.handle.apply(this,arguments)}};o.each({mouseover:"mouseenter",mouseout:"mouseleave"},function(F,E){o.event.special[E]={setup:function(){o.event.add(this,F,a,E)},teardown:function(){o.event.remove(this,F,a)}}});o.fn.extend({bind:function(F,G,E){return F=="unload"?this.one(F,G,E):this.each(function(){o.event.add(this,F,E||G,E&&G)})},one:function(G,H,F){var E=o.event.proxy(F||H,function(I){o(this).unbind(I,E);return(F||H).apply(this,arguments)});return this.each(function(){o.event.add(this,G,E,F&&H)})},unbind:function(F,E){return this.each(function(){o.event.remove(this,F,E)})},trigger:function(E,F){return this.each(function(){o.event.trigger(E,F,this)})},triggerHandler:function(E,G){if(this[0]){var F=o.Event(E);F.preventDefault();F.stopPropagation();o.event.trigger(F,G,this[0]);return F.result}},toggle:function(G){var E=arguments,F=1;while(F<E.length){o.event.proxy(G,E[F++])}return this.click(o.event.proxy(G,function(H){this.lastToggle=(this.lastToggle||0)%F;H.preventDefault();return E[this.lastToggle++].apply(this,arguments)||false}))},hover:function(E,F){return this.mouseenter(E).mouseleave(F)},ready:function(E){B();if(o.isReady){E.call(document,o)}else{o.readyList.push(E)}return this},live:function(G,F){var E=o.event.proxy(F);E.guid+=this.selector+G;o(document).bind(i(G,this.selector),this.selector,E);return this},die:function(F,E){o(document).unbind(i(F,this.selector),E?{guid:E.guid+this.selector+F}:null);return this}});function c(H){var E=RegExp("(^|\\.)"+H.type+"(\\.|$)"),G=true,F=[];o.each(o.data(this,"events").live||[],function(I,J){if(E.test(J.type)){var K=o(H.target).closest(J.data)[0];if(K){F.push({elem:K,fn:J})}}});F.sort(function(J,I){return o.data(J.elem,"closest")-o.data(I.elem,"closest")});o.each(F,function(){if(this.fn.call(this.elem,H,this.fn.data)===false){return(G=false)}});return G}function i(F,E){return["live",F,E.replace(/\./g,"`").replace(/ /g,"|")].join(".")}o.extend({isReady:false,readyList:[],ready:function(){if(!o.isReady){o.isReady=true;if(o.readyList){o.each(o.readyList,function(){this.call(document,o)});o.readyList=null}o(document).triggerHandler("ready")}}});var x=false;function B(){if(x){return}x=true;if(document.addEventListener){document.addEventListener("DOMContentLoaded",function(){document.removeEventListener("DOMContentLoaded",arguments.callee,false);o.ready()},false)}else{if(document.attachEvent){document.attachEvent("onreadystatechange",function(){if(document.readyState==="complete"){document.detachEvent("onreadystatechange",arguments.callee);o.ready()}});if(document.documentElement.doScroll&&l==l.top){(function(){if(o.isReady){return}try{document.documentElement.doScroll("left")}catch(E){setTimeout(arguments.callee,0);return}o.ready()})()}}}o.event.add(l,"load",o.ready)}o.each(("blur,focus,load,resize,scroll,unload,click,dblclick,mousedown,mouseup,mousemove,mouseover,mouseout,mouseenter,mouseleave,change,select,submit,keydown,keypress,keyup,error").split(","),function(F,E){o.fn[E]=function(G){return G?this.bind(E,G):this.trigger(E)}});o(l).bind("unload",function(){for(var E in o.cache){if(E!=1&&o.cache[E].handle){o.event.remove(o.cache[E].handle.elem)}}});(function(){o.support={};var F=document.documentElement,G=document.createElement("script"),K=document.createElement("div"),J="script"+(new Date).getTime();K.style.display="none";K.innerHTML='   <link/><table></table><a href="/a" style="color:red;float:left;opacity:.5;">a</a><select><option>text</option></select><object><param/></object>';var H=K.getElementsByTagName("*"),E=K.getElementsByTagName("a")[0];if(!H||!H.length||!E){return}o.support={leadingWhitespace:K.firstChild.nodeType==3,tbody:!K.getElementsByTagName("tbody").length,objectAll:!!K.getElementsByTagName("object")[0].getElementsByTagName("*").length,htmlSerialize:!!K.getElementsByTagName("link").length,style:/red/.test(E.getAttribute("style")),hrefNormalized:E.getAttribute("href")==="/a",opacity:E.style.opacity==="0.5",cssFloat:!!E.style.cssFloat,scriptEval:false,noCloneEvent:true,boxModel:null};G.type="text/javascript";try{G.appendChild(document.createTextNode("window."+J+"=1;"))}catch(I){}F.insertBefore(G,F.firstChild);if(l[J]){o.support.scriptEval=true;delete l[J]}F.removeChild(G);if(K.attachEvent&&K.fireEvent){K.attachEvent("onclick",function(){o.support.noCloneEvent=false;K.detachEvent("onclick",arguments.callee)});K.cloneNode(true).fireEvent("onclick")}o(function(){var L=document.createElement("div");L.style.width=L.style.paddingLeft="1px";document.body.appendChild(L);o.boxModel=o.support.boxModel=L.offsetWidth===2;document.body.removeChild(L).style.display="none"})})();var w=o.support.cssFloat?"cssFloat":"styleFloat";o.props={"for":"htmlFor","class":"className","float":w,cssFloat:w,styleFloat:w,readonly:"readOnly",maxlength:"maxLength",cellspacing:"cellSpacing",rowspan:"rowSpan",tabindex:"tabIndex"};o.fn.extend({_load:o.fn.load,load:function(G,J,K){if(typeof G!=="string"){return this._load(G)}var I=G.indexOf(" ");if(I>=0){var E=G.slice(I,G.length);G=G.slice(0,I)}var H="GET";if(J){if(o.isFunction(J)){K=J;J=null}else{if(typeof J==="object"){J=o.param(J);H="POST"}}}var F=this;o.ajax({url:G,type:H,dataType:"html",data:J,complete:function(M,L){if(L=="success"||L=="notmodified"){F.html(E?o("<div/>").append(M.responseText.replace(/<script(.|\s)*?\/script>/g,"")).find(E):M.responseText)}if(K){F.each(K,[M.responseText,L,M])}}});return this},serialize:function(){return o.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?o.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||/select|textarea/i.test(this.nodeName)||/text|hidden|password|search/i.test(this.type))}).map(function(E,F){var G=o(this).val();return G==null?null:o.isArray(G)?o.map(G,function(I,H){return{name:F.name,value:I}}):{name:F.name,value:G}}).get()}});o.each("ajaxStart,ajaxStop,ajaxComplete,ajaxError,ajaxSuccess,ajaxSend".split(","),function(E,F){o.fn[F]=function(G){return this.bind(F,G)}});var r=e();o.extend({get:function(E,G,H,F){if(o.isFunction(G)){H=G;G=null}return o.ajax({type:"GET",url:E,data:G,success:H,dataType:F})},getScript:function(E,F){return o.get(E,null,F,"script")},getJSON:function(E,F,G){return o.get(E,F,G,"json")},post:function(E,G,H,F){if(o.isFunction(G)){H=G;G={}}return o.ajax({type:"POST",url:E,data:G,success:H,dataType:F})},ajaxSetup:function(E){o.extend(o.ajaxSettings,E)},ajaxSettings:{url:location.href,global:true,type:"GET",contentType:"application/x-www-form-urlencoded",processData:true,async:true,xhr:function(){return l.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):new XMLHttpRequest()},accepts:{xml:"application/xml, text/xml",html:"text/html",script:"text/javascript, application/javascript",json:"application/json, text/javascript",text:"text/plain",_default:"*/*"}},lastModified:{},ajax:function(M){M=o.extend(true,M,o.extend(true,{},o.ajaxSettings,M));var W,F=/=\?(&|$)/g,R,V,G=M.type.toUpperCase();if(M.data&&M.processData&&typeof M.data!=="string"){M.data=o.param(M.data)}if(M.dataType=="jsonp"){if(G=="GET"){if(!M.url.match(F)){M.url+=(M.url.match(/\?/)?"&":"?")+(M.jsonp||"callback")+"=?"}}else{if(!M.data||!M.data.match(F)){M.data=(M.data?M.data+"&":"")+(M.jsonp||"callback")+"=?"}}M.dataType="json"}if(M.dataType=="json"&&(M.data&&M.data.match(F)||M.url.match(F))){W="jsonp"+r++;if(M.data){M.data=(M.data+"").replace(F,"="+W+"$1")}M.url=M.url.replace(F,"="+W+"$1");M.dataType="script";l[W]=function(X){V=X;I();L();l[W]=g;try{delete l[W]}catch(Y){}if(H){H.removeChild(T)}}}if(M.dataType=="script"&&M.cache==null){M.cache=false}if(M.cache===false&&G=="GET"){var E=e();var U=M.url.replace(/(\?|&)_=.*?(&|$)/,"$1_="+E+"$2");M.url=U+((U==M.url)?(M.url.match(/\?/)?"&":"?")+"_="+E:"")}if(M.data&&G=="GET"){M.url+=(M.url.match(/\?/)?"&":"?")+M.data;M.data=null}if(M.global&&!o.active++){o.event.trigger("ajaxStart")}var Q=/^(\w+:)?\/\/([^\/?#]+)/.exec(M.url);if(M.dataType=="script"&&G=="GET"&&Q&&(Q[1]&&Q[1]!=location.protocol||Q[2]!=location.host)){var H=document.getElementsByTagName("head")[0];var T=document.createElement("script");T.src=M.url;if(M.scriptCharset){T.charset=M.scriptCharset}if(!W){var O=false;T.onload=T.onreadystatechange=function(){if(!O&&(!this.readyState||this.readyState=="loaded"||this.readyState=="complete")){O=true;I();L();T.onload=T.onreadystatechange=null;H.removeChild(T)}}}H.appendChild(T);return g}var K=false;var J=M.xhr();if(M.username){J.open(G,M.url,M.async,M.username,M.password)}else{J.open(G,M.url,M.async)}try{if(M.data){J.setRequestHeader("Content-Type",M.contentType)}if(M.ifModified){J.setRequestHeader("If-Modified-Since",o.lastModified[M.url]||"Thu, 01 Jan 1970 00:00:00 GMT")}J.setRequestHeader("X-Requested-With","XMLHttpRequest");J.setRequestHeader("Accept",M.dataType&&M.accepts[M.dataType]?M.accepts[M.dataType]+", */*":M.accepts._default)}catch(S){}if(M.beforeSend&&M.beforeSend(J,M)===false){if(M.global&&!--o.active){o.event.trigger("ajaxStop")}J.abort();return false}if(M.global){o.event.trigger("ajaxSend",[J,M])}var N=function(X){if(J.readyState==0){if(P){clearInterval(P);P=null;if(M.global&&!--o.active){o.event.trigger("ajaxStop")}}}else{if(!K&&J&&(J.readyState==4||X=="timeout")){K=true;if(P){clearInterval(P);P=null}R=X=="timeout"?"timeout":!o.httpSuccess(J)?"error":M.ifModified&&o.httpNotModified(J,M.url)?"notmodified":"success";if(R=="success"){try{V=o.httpData(J,M.dataType,M)}catch(Z){R="parsererror"}}if(R=="success"){var Y;try{Y=J.getResponseHeader("Last-Modified")}catch(Z){}if(M.ifModified&&Y){o.lastModified[M.url]=Y}if(!W){I()}}else{o.handleError(M,J,R)}L();if(X){J.abort()}if(M.async){J=null}}}};if(M.async){var P=setInterval(N,13);if(M.timeout>0){setTimeout(function(){if(J&&!K){N("timeout")}},M.timeout)}}try{J.send(M.data)}catch(S){o.handleError(M,J,null,S)}if(!M.async){N()}function I(){if(M.success){M.success(V,R)}if(M.global){o.event.trigger("ajaxSuccess",[J,M])}}function L(){if(M.complete){M.complete(J,R)}if(M.global){o.event.trigger("ajaxComplete",[J,M])}if(M.global&&!--o.active){o.event.trigger("ajaxStop")}}return J},handleError:function(F,H,E,G){if(F.error){F.error(H,E,G)}if(F.global){o.event.trigger("ajaxError",[H,F,G])}},active:0,httpSuccess:function(F){try{return !F.status&&location.protocol=="file:"||(F.status>=200&&F.status<300)||F.status==304||F.status==1223}catch(E){}return false},httpNotModified:function(G,E){try{var H=G.getResponseHeader("Last-Modified");return G.status==304||H==o.lastModified[E]}catch(F){}return false},httpData:function(J,H,G){var F=J.getResponseHeader("content-type"),E=H=="xml"||!H&&F&&F.indexOf("xml")>=0,I=E?J.responseXML:J.responseText;if(E&&I.documentElement.tagName=="parsererror"){throw"parsererror"}if(G&&G.dataFilter){I=G.dataFilter(I,H)}if(typeof I==="string"){if(H=="script"){o.globalEval(I)}if(H=="json"){I=l["eval"]("("+I+")")}}return I},param:function(E){var G=[];function H(I,J){G[G.length]=encodeURIComponent(I)+"="+encodeURIComponent(J)}if(o.isArray(E)||E.jquery){o.each(E,function(){H(this.name,this.value)})}else{for(var F in E){if(o.isArray(E[F])){o.each(E[F],function(){H(F,this)})}else{H(F,o.isFunction(E[F])?E[F]():E[F])}}}return G.join("&").replace(/%20/g,"+")}});var m={},n,d=[["height","marginTop","marginBottom","paddingTop","paddingBottom"],["width","marginLeft","marginRight","paddingLeft","paddingRight"],["opacity"]];function t(F,E){var G={};o.each(d.concat.apply([],d.slice(0,E)),function(){G[this]=F});return G}o.fn.extend({show:function(J,L){if(J){return this.animate(t("show",3),J,L)}else{for(var H=0,F=this.length;H<F;H++){var E=o.data(this[H],"olddisplay");this[H].style.display=E||"";if(o.css(this[H],"display")==="none"){var G=this[H].tagName,K;if(m[G]){K=m[G]}else{var I=o("<"+G+" />").appendTo("body");K=I.css("display");if(K==="none"){K="block"}I.remove();m[G]=K}o.data(this[H],"olddisplay",K)}}for(var H=0,F=this.length;H<F;H++){this[H].style.display=o.data(this[H],"olddisplay")||""}return this}},hide:function(H,I){if(H){return this.animate(t("hide",3),H,I)}else{for(var G=0,F=this.length;G<F;G++){var E=o.data(this[G],"olddisplay");if(!E&&E!=="none"){o.data(this[G],"olddisplay",o.css(this[G],"display"))}}for(var G=0,F=this.length;G<F;G++){this[G].style.display="none"}return this}},_toggle:o.fn.toggle,toggle:function(G,F){var E=typeof G==="boolean";return o.isFunction(G)&&o.isFunction(F)?this._toggle.apply(this,arguments):G==null||E?this.each(function(){var H=E?G:o(this).is(":hidden");o(this)[H?"show":"hide"]()}):this.animate(t("toggle",3),G,F)},fadeTo:function(E,G,F){return this.animate({opacity:G},E,F)},animate:function(I,F,H,G){var E=o.speed(F,H,G);return this[E.queue===false?"each":"queue"](function(){var K=o.extend({},E),M,L=this.nodeType==1&&o(this).is(":hidden"),J=this;for(M in I){if(I[M]=="hide"&&L||I[M]=="show"&&!L){return K.complete.call(this)}if((M=="height"||M=="width")&&this.style){K.display=o.css(this,"display");K.overflow=this.style.overflow}}if(K.overflow!=null){this.style.overflow="hidden"}K.curAnim=o.extend({},I);o.each(I,function(O,S){var R=new o.fx(J,K,O);if(/toggle|show|hide/.test(S)){R[S=="toggle"?L?"show":"hide":S](I)}else{var Q=S.toString().match(/^([+-]=)?([\d+-.]+)(.*)$/),T=R.cur(true)||0;if(Q){var N=parseFloat(Q[2]),P=Q[3]||"px";if(P!="px"){J.style[O]=(N||1)+P;T=((N||1)/R.cur(true))*T;J.style[O]=T+P}if(Q[1]){N=((Q[1]=="-="?-1:1)*N)+T}R.custom(T,N,P)}else{R.custom(T,S,"")}}});return true})},stop:function(F,E){var G=o.timers;if(F){this.queue([])}this.each(function(){for(var H=G.length-1;H>=0;H--){if(G[H].elem==this){if(E){G[H](true)}G.splice(H,1)}}});if(!E){this.dequeue()}return this}});o.each({slideDown:t("show",1),slideUp:t("hide",1),slideToggle:t("toggle",1),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"}},function(E,F){o.fn[E]=function(G,H){return this.animate(F,G,H)}});o.extend({speed:function(G,H,F){var E=typeof G==="object"?G:{complete:F||!F&&H||o.isFunction(G)&&G,duration:G,easing:F&&H||H&&!o.isFunction(H)&&H};E.duration=o.fx.off?0:typeof E.duration==="number"?E.duration:o.fx.speeds[E.duration]||o.fx.speeds._default;E.old=E.complete;E.complete=function(){if(E.queue!==false){o(this).dequeue()}if(o.isFunction(E.old)){E.old.call(this)}};return E},easing:{linear:function(G,H,E,F){return E+F*G},swing:function(G,H,E,F){return((-Math.cos(G*Math.PI)/2)+0.5)*F+E}},timers:[],fx:function(F,E,G){this.options=E;this.elem=F;this.prop=G;if(!E.orig){E.orig={}}}});o.fx.prototype={update:function(){if(this.options.step){this.options.step.call(this.elem,this.now,this)}(o.fx.step[this.prop]||o.fx.step._default)(this);if((this.prop=="height"||this.prop=="width")&&this.elem.style){this.elem.style.display="block"}},cur:function(F){if(this.elem[this.prop]!=null&&(!this.elem.style||this.elem.style[this.prop]==null)){return this.elem[this.prop]}var E=parseFloat(o.css(this.elem,this.prop,F));return E&&E>-10000?E:parseFloat(o.curCSS(this.elem,this.prop))||0},custom:function(I,H,G){this.startTime=e();this.start=I;this.end=H;this.unit=G||this.unit||"px";this.now=this.start;this.pos=this.state=0;var E=this;function F(J){return E.step(J)}F.elem=this.elem;if(F()&&o.timers.push(F)&&!n){n=setInterval(function(){var K=o.timers;for(var J=0;J<K.length;J++){if(!K[J]()){K.splice(J--,1)}}if(!K.length){clearInterval(n);n=g}},13)}},show:function(){this.options.orig[this.prop]=o.attr(this.elem.style,this.prop);this.options.show=true;this.custom(this.prop=="width"||this.prop=="height"?1:0,this.cur());o(this.elem).show()},hide:function(){this.options.orig[this.prop]=o.attr(this.elem.style,this.prop);this.options.hide=true;this.custom(this.cur(),0)},step:function(H){var G=e();if(H||G>=this.options.duration+this.startTime){this.now=this.end;this.pos=this.state=1;this.update();this.options.curAnim[this.prop]=true;var E=true;for(var F in this.options.curAnim){if(this.options.curAnim[F]!==true){E=false}}if(E){if(this.options.display!=null){this.elem.style.overflow=this.options.overflow;this.elem.style.display=this.options.display;if(o.css(this.elem,"display")=="none"){this.elem.style.display="block"}}if(this.options.hide){o(this.elem).hide()}if(this.options.hide||this.options.show){for(var I in this.options.curAnim){o.attr(this.elem.style,I,this.options.orig[I])}}this.options.complete.call(this.elem)}return false}else{var J=G-this.startTime;this.state=J/this.options.duration;this.pos=o.easing[this.options.easing||(o.easing.swing?"swing":"linear")](this.state,J,0,1,this.options.duration);this.now=this.start+((this.end-this.start)*this.pos);this.update()}return true}};o.extend(o.fx,{speeds:{slow:600,fast:200,_default:400},step:{opacity:function(E){o.attr(E.elem.style,"opacity",E.now)},_default:function(E){if(E.elem.style&&E.elem.style[E.prop]!=null){E.elem.style[E.prop]=E.now+E.unit}else{E.elem[E.prop]=E.now}}}});if(document.documentElement.getBoundingClientRect){o.fn.offset=function(){if(!this[0]){return{top:0,left:0}}if(this[0]===this[0].ownerDocument.body){return o.offset.bodyOffset(this[0])}var G=this[0].getBoundingClientRect(),J=this[0].ownerDocument,F=J.body,E=J.documentElement,L=E.clientTop||F.clientTop||0,K=E.clientLeft||F.clientLeft||0,I=G.top+(self.pageYOffset||o.boxModel&&E.scrollTop||F.scrollTop)-L,H=G.left+(self.pageXOffset||o.boxModel&&E.scrollLeft||F.scrollLeft)-K;return{top:I,left:H}}}else{o.fn.offset=function(){if(!this[0]){return{top:0,left:0}}if(this[0]===this[0].ownerDocument.body){return o.offset.bodyOffset(this[0])}o.offset.initialized||o.offset.initialize();var J=this[0],G=J.offsetParent,F=J,O=J.ownerDocument,M,H=O.documentElement,K=O.body,L=O.defaultView,E=L.getComputedStyle(J,null),N=J.offsetTop,I=J.offsetLeft;while((J=J.parentNode)&&J!==K&&J!==H){M=L.getComputedStyle(J,null);N-=J.scrollTop,I-=J.scrollLeft;if(J===G){N+=J.offsetTop,I+=J.offsetLeft;if(o.offset.doesNotAddBorder&&!(o.offset.doesAddBorderForTableAndCells&&/^t(able|d|h)$/i.test(J.tagName))){N+=parseInt(M.borderTopWidth,10)||0,I+=parseInt(M.borderLeftWidth,10)||0}F=G,G=J.offsetParent}if(o.offset.subtractsBorderForOverflowNotVisible&&M.overflow!=="visible"){N+=parseInt(M.borderTopWidth,10)||0,I+=parseInt(M.borderLeftWidth,10)||0}E=M}if(E.position==="relative"||E.position==="static"){N+=K.offsetTop,I+=K.offsetLeft}if(E.position==="fixed"){N+=Math.max(H.scrollTop,K.scrollTop),I+=Math.max(H.scrollLeft,K.scrollLeft)}return{top:N,left:I}}}o.offset={initialize:function(){if(this.initialized){return}var L=document.body,F=document.createElement("div"),H,G,N,I,M,E,J=L.style.marginTop,K='<div style="position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;"><div></div></div><table style="position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;" cellpadding="0" cellspacing="0"><tr><td></td></tr></table>';M={position:"absolute",top:0,left:0,margin:0,border:0,width:"1px",height:"1px",visibility:"hidden"};for(E in M){F.style[E]=M[E]}F.innerHTML=K;L.insertBefore(F,L.firstChild);H=F.firstChild,G=H.firstChild,I=H.nextSibling.firstChild.firstChild;this.doesNotAddBorder=(G.offsetTop!==5);this.doesAddBorderForTableAndCells=(I.offsetTop===5);H.style.overflow="hidden",H.style.position="relative";this.subtractsBorderForOverflowNotVisible=(G.offsetTop===-5);L.style.marginTop="1px";this.doesNotIncludeMarginInBodyOffset=(L.offsetTop===0);L.style.marginTop=J;L.removeChild(F);this.initialized=true},bodyOffset:function(E){o.offset.initialized||o.offset.initialize();var G=E.offsetTop,F=E.offsetLeft;if(o.offset.doesNotIncludeMarginInBodyOffset){G+=parseInt(o.curCSS(E,"marginTop",true),10)||0,F+=parseInt(o.curCSS(E,"marginLeft",true),10)||0}return{top:G,left:F}}};o.fn.extend({position:function(){var I=0,H=0,F;if(this[0]){var G=this.offsetParent(),J=this.offset(),E=/^body|html$/i.test(G[0].tagName)?{top:0,left:0}:G.offset();J.top-=j(this,"marginTop");J.left-=j(this,"marginLeft");E.top+=j(G,"borderTopWidth");E.left+=j(G,"borderLeftWidth");F={top:J.top-E.top,left:J.left-E.left}}return F},offsetParent:function(){var E=this[0].offsetParent||document.body;while(E&&(!/^body|html$/i.test(E.tagName)&&o.css(E,"position")=="static")){E=E.offsetParent}return o(E)}});o.each(["Left","Top"],function(F,E){var G="scroll"+E;o.fn[G]=function(H){if(!this[0]){return null}return H!==g?this.each(function(){this==l||this==document?l.scrollTo(!F?H:o(l).scrollLeft(),F?H:o(l).scrollTop()):this[G]=H}):this[0]==l||this[0]==document?self[F?"pageYOffset":"pageXOffset"]||o.boxModel&&document.documentElement[G]||document.body[G]:this[0][G]}});o.each(["Height","Width"],function(I,G){var E=I?"Left":"Top",H=I?"Right":"Bottom",F=G.toLowerCase();o.fn["inner"+G]=function(){return this[0]?o.css(this[0],F,false,"padding"):null};o.fn["outer"+G]=function(K){return this[0]?o.css(this[0],F,false,K?"margin":"border"):null};var J=G.toLowerCase();o.fn[J]=function(K){return this[0]==l?document.compatMode=="CSS1Compat"&&document.documentElement["client"+G]||document.body["client"+G]:this[0]==document?Math.max(document.documentElement["client"+G],document.body["scroll"+G],document.documentElement["scroll"+G],document.body["offset"+G],document.documentElement["offset"+G]):K===g?(this.length?o.css(this[0],J):null):this.css(J,typeof K==="string"?K:K+"px")}})})();/*
 * jQuery UI 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI
 */
jQuery.ui||(function(c){var i=c.fn.remove,d=c.browser.mozilla&&(parseFloat(c.browser.version)<1.9);c.ui={version:"1.7.2",plugin:{add:function(k,l,n){var m=c.ui[k].prototype;for(var j in n){m.plugins[j]=m.plugins[j]||[];m.plugins[j].push([l,n[j]])}},call:function(j,l,k){var n=j.plugins[l];if(!n||!j.element[0].parentNode){return}for(var m=0;m<n.length;m++){if(j.options[n[m][0]]){n[m][1].apply(j.element,k)}}}},contains:function(k,j){return document.compareDocumentPosition?k.compareDocumentPosition(j)&16:k!==j&&k.contains(j)},hasScroll:function(m,k){if(c(m).css("overflow")=="hidden"){return false}var j=(k&&k=="left")?"scrollLeft":"scrollTop",l=false;if(m[j]>0){return true}m[j]=1;l=(m[j]>0);m[j]=0;return l},isOverAxis:function(k,j,l){return(k>j)&&(k<(j+l))},isOver:function(o,k,n,m,j,l){return c.ui.isOverAxis(o,n,j)&&c.ui.isOverAxis(k,m,l)},keyCode:{BACKSPACE:8,CAPS_LOCK:20,COMMA:188,CONTROL:17,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,INSERT:45,LEFT:37,NUMPAD_ADD:107,NUMPAD_DECIMAL:110,NUMPAD_DIVIDE:111,NUMPAD_ENTER:108,NUMPAD_MULTIPLY:106,NUMPAD_SUBTRACT:109,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SHIFT:16,SPACE:32,TAB:9,UP:38}};if(d){var f=c.attr,e=c.fn.removeAttr,h="http://www.w3.org/2005/07/aaa",a=/^aria-/,b=/^wairole:/;c.attr=function(k,j,l){var m=l!==undefined;return(j=="role"?(m?f.call(this,k,j,"wairole:"+l):(f.apply(this,arguments)||"").replace(b,"")):(a.test(j)?(m?k.setAttributeNS(h,j.replace(a,"aaa:"),l):f.call(this,k,j.replace(a,"aaa:"))):f.apply(this,arguments)))};c.fn.removeAttr=function(j){return(a.test(j)?this.each(function(){this.removeAttributeNS(h,j.replace(a,""))}):e.call(this,j))}}c.fn.extend({remove:function(){c("*",this).add(this).each(function(){c(this).triggerHandler("remove")});return i.apply(this,arguments)},enableSelection:function(){return this.attr("unselectable","off").css("MozUserSelect","").unbind("selectstart.ui")},disableSelection:function(){return this.attr("unselectable","on").css("MozUserSelect","none").bind("selectstart.ui",function(){return false})},scrollParent:function(){var j;if((c.browser.msie&&(/(static|relative)/).test(this.css("position")))||(/absolute/).test(this.css("position"))){j=this.parents().filter(function(){return(/(relative|absolute|fixed)/).test(c.curCSS(this,"position",1))&&(/(auto|scroll)/).test(c.curCSS(this,"overflow",1)+c.curCSS(this,"overflow-y",1)+c.curCSS(this,"overflow-x",1))}).eq(0)}else{j=this.parents().filter(function(){return(/(auto|scroll)/).test(c.curCSS(this,"overflow",1)+c.curCSS(this,"overflow-y",1)+c.curCSS(this,"overflow-x",1))}).eq(0)}return(/fixed/).test(this.css("position"))||!j.length?c(document):j}});c.extend(c.expr[":"],{data:function(l,k,j){return !!c.data(l,j[3])},focusable:function(k){var l=k.nodeName.toLowerCase(),j=c.attr(k,"tabindex");return(/input|select|textarea|button|object/.test(l)?!k.disabled:"a"==l||"area"==l?k.href||!isNaN(j):!isNaN(j))&&!c(k)["area"==l?"parents":"closest"](":hidden").length},tabbable:function(k){var j=c.attr(k,"tabindex");return(isNaN(j)||j>=0)&&c(k).is(":focusable")}});function g(m,n,o,l){function k(q){var p=c[m][n][q]||[];return(typeof p=="string"?p.split(/,?\s+/):p)}var j=k("getter");if(l.length==1&&typeof l[0]=="string"){j=j.concat(k("getterSetter"))}return(c.inArray(o,j)!=-1)}c.widget=function(k,j){var l=k.split(".")[0];k=k.split(".")[1];c.fn[k]=function(p){var n=(typeof p=="string"),o=Array.prototype.slice.call(arguments,1);if(n&&p.substring(0,1)=="_"){return this}if(n&&g(l,k,p,o)){var m=c.data(this[0],k);return(m?m[p].apply(m,o):undefined)}return this.each(function(){var q=c.data(this,k);(!q&&!n&&c.data(this,k,new c[l][k](this,p))._init());(q&&n&&c.isFunction(q[p])&&q[p].apply(q,o))})};c[l]=c[l]||{};c[l][k]=function(o,n){var m=this;this.namespace=l;this.widgetName=k;this.widgetEventPrefix=c[l][k].eventPrefix||k;this.widgetBaseClass=l+"-"+k;this.options=c.extend({},c.widget.defaults,c[l][k].defaults,c.metadata&&c.metadata.get(o)[k],n);this.element=c(o).bind("setData."+k,function(q,p,r){if(q.target==o){return m._setData(p,r)}}).bind("getData."+k,function(q,p){if(q.target==o){return m._getData(p)}}).bind("remove",function(){return m.destroy()})};c[l][k].prototype=c.extend({},c.widget.prototype,j);c[l][k].getterSetter="option"};c.widget.prototype={_init:function(){},destroy:function(){this.element.removeData(this.widgetName).removeClass(this.widgetBaseClass+"-disabled "+this.namespace+"-state-disabled").removeAttr("aria-disabled")},option:function(l,m){var k=l,j=this;if(typeof l=="string"){if(m===undefined){return this._getData(l)}k={};k[l]=m}c.each(k,function(n,o){j._setData(n,o)})},_getData:function(j){return this.options[j]},_setData:function(j,k){this.options[j]=k;if(j=="disabled"){this.element[k?"addClass":"removeClass"](this.widgetBaseClass+"-disabled "+this.namespace+"-state-disabled").attr("aria-disabled",k)}},enable:function(){this._setData("disabled",false)},disable:function(){this._setData("disabled",true)},_trigger:function(l,m,n){var p=this.options[l],j=(l==this.widgetEventPrefix?l:this.widgetEventPrefix+l);m=c.Event(m);m.type=j;if(m.originalEvent){for(var k=c.event.props.length,o;k;){o=c.event.props[--k];m[o]=m.originalEvent[o]}}this.element.trigger(m,n);return !(c.isFunction(p)&&p.call(this.element[0],m,n)===false||m.isDefaultPrevented())}};c.widget.defaults={disabled:false};c.ui.mouse={_mouseInit:function(){var j=this;this.element.bind("mousedown."+this.widgetName,function(k){return j._mouseDown(k)}).bind("click."+this.widgetName,function(k){if(j._preventClickEvent){j._preventClickEvent=false;k.stopImmediatePropagation();return false}});if(c.browser.msie){this._mouseUnselectable=this.element.attr("unselectable");this.element.attr("unselectable","on")}this.started=false},_mouseDestroy:function(){this.element.unbind("."+this.widgetName);(c.browser.msie&&this.element.attr("unselectable",this._mouseUnselectable))},_mouseDown:function(l){l.originalEvent=l.originalEvent||{};if(l.originalEvent.mouseHandled){return}(this._mouseStarted&&this._mouseUp(l));this._mouseDownEvent=l;var k=this,m=(l.which==1),j=(typeof this.options.cancel=="string"?c(l.target).parents().add(l.target).filter(this.options.cancel).length:false);if(!m||j||!this._mouseCapture(l)){return true}this.mouseDelayMet=!this.options.delay;if(!this.mouseDelayMet){this._mouseDelayTimer=setTimeout(function(){k.mouseDelayMet=true},this.options.delay)}if(this._mouseDistanceMet(l)&&this._mouseDelayMet(l)){this._mouseStarted=(this._mouseStart(l)!==false);if(!this._mouseStarted){l.preventDefault();return true}}this._mouseMoveDelegate=function(n){return k._mouseMove(n)};this._mouseUpDelegate=function(n){return k._mouseUp(n)};c(document).bind("mousemove."+this.widgetName,this._mouseMoveDelegate).bind("mouseup."+this.widgetName,this._mouseUpDelegate);(c.browser.safari||l.preventDefault());l.originalEvent.mouseHandled=true;return true},_mouseMove:function(j){if(c.browser.msie&&!j.button){return this._mouseUp(j)}if(this._mouseStarted){this._mouseDrag(j);return j.preventDefault()}if(this._mouseDistanceMet(j)&&this._mouseDelayMet(j)){this._mouseStarted=(this._mouseStart(this._mouseDownEvent,j)!==false);(this._mouseStarted?this._mouseDrag(j):this._mouseUp(j))}return !this._mouseStarted},_mouseUp:function(j){c(document).unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate);if(this._mouseStarted){this._mouseStarted=false;this._preventClickEvent=(j.target==this._mouseDownEvent.target);this._mouseStop(j)}return false},_mouseDistanceMet:function(j){return(Math.max(Math.abs(this._mouseDownEvent.pageX-j.pageX),Math.abs(this._mouseDownEvent.pageY-j.pageY))>=this.options.distance)},_mouseDelayMet:function(j){return this.mouseDelayMet},_mouseStart:function(j){},_mouseDrag:function(j){},_mouseStop:function(j){},_mouseCapture:function(j){return true}};c.ui.mouse.defaults={cancel:null,distance:1,delay:0}})(jQuery);;/*
 * jQuery UI Draggable 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Draggables
 *
 * Depends:
 *	ui.core.js
 */
(function(a){a.widget("ui.draggable",a.extend({},a.ui.mouse,{_init:function(){if(this.options.helper=="original"&&!(/^(?:r|a|f)/).test(this.element.css("position"))){this.element[0].style.position="relative"}(this.options.addClasses&&this.element.addClass("ui-draggable"));(this.options.disabled&&this.element.addClass("ui-draggable-disabled"));this._mouseInit()},destroy:function(){if(!this.element.data("draggable")){return}this.element.removeData("draggable").unbind(".draggable").removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled");this._mouseDestroy()},_mouseCapture:function(b){var c=this.options;if(this.helper||c.disabled||a(b.target).is(".ui-resizable-handle")){return false}this.handle=this._getHandle(b);if(!this.handle){return false}return true},_mouseStart:function(b){var c=this.options;this.helper=this._createHelper(b);this._cacheHelperProportions();if(a.ui.ddmanager){a.ui.ddmanager.current=this}this._cacheMargins();this.cssPosition=this.helper.css("position");this.scrollParent=this.helper.scrollParent();this.offset=this.element.offset();this.offset={top:this.offset.top-this.margins.top,left:this.offset.left-this.margins.left};a.extend(this.offset,{click:{left:b.pageX-this.offset.left,top:b.pageY-this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()});this.originalPosition=this._generatePosition(b);this.originalPageX=b.pageX;this.originalPageY=b.pageY;if(c.cursorAt){this._adjustOffsetFromHelper(c.cursorAt)}if(c.containment){this._setContainment()}this._trigger("start",b);this._cacheHelperProportions();if(a.ui.ddmanager&&!c.dropBehaviour){a.ui.ddmanager.prepareOffsets(this,b)}this.helper.addClass("ui-draggable-dragging");this._mouseDrag(b,true);return true},_mouseDrag:function(b,d){this.position=this._generatePosition(b);this.positionAbs=this._convertPositionTo("absolute");if(!d){var c=this._uiHash();this._trigger("drag",b,c);this.position=c.position}if(!this.options.axis||this.options.axis!="y"){this.helper[0].style.left=this.position.left+"px"}if(!this.options.axis||this.options.axis!="x"){this.helper[0].style.top=this.position.top+"px"}if(a.ui.ddmanager){a.ui.ddmanager.drag(this,b)}return false},_mouseStop:function(c){var d=false;if(a.ui.ddmanager&&!this.options.dropBehaviour){d=a.ui.ddmanager.drop(this,c)}if(this.dropped){d=this.dropped;this.dropped=false}if((this.options.revert=="invalid"&&!d)||(this.options.revert=="valid"&&d)||this.options.revert===true||(a.isFunction(this.options.revert)&&this.options.revert.call(this.element,d))){var b=this;a(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),function(){b._trigger("stop",c);b._clear()})}else{this._trigger("stop",c);this._clear()}return false},_getHandle:function(b){var c=!this.options.handle||!a(this.options.handle,this.element).length?true:false;a(this.options.handle,this.element).find("*").andSelf().each(function(){if(this==b.target){c=true}});return c},_createHelper:function(c){var d=this.options;var b=a.isFunction(d.helper)?a(d.helper.apply(this.element[0],[c])):(d.helper=="clone"?this.element.clone():this.element);if(!b.parents("body").length){b.appendTo((d.appendTo=="parent"?this.element[0].parentNode:d.appendTo))}if(b[0]!=this.element[0]&&!(/(fixed|absolute)/).test(b.css("position"))){b.css("position","absolute")}return b},_adjustOffsetFromHelper:function(b){if(b.left!=undefined){this.offset.click.left=b.left+this.margins.left}if(b.right!=undefined){this.offset.click.left=this.helperProportions.width-b.right+this.margins.left}if(b.top!=undefined){this.offset.click.top=b.top+this.margins.top}if(b.bottom!=undefined){this.offset.click.top=this.helperProportions.height-b.bottom+this.margins.top}},_getParentOffset:function(){this.offsetParent=this.helper.offsetParent();var b=this.offsetParent.offset();if(this.cssPosition=="absolute"&&this.scrollParent[0]!=document&&a.ui.contains(this.scrollParent[0],this.offsetParent[0])){b.left+=this.scrollParent.scrollLeft();b.top+=this.scrollParent.scrollTop()}if((this.offsetParent[0]==document.body)||(this.offsetParent[0].tagName&&this.offsetParent[0].tagName.toLowerCase()=="html"&&a.browser.msie)){b={top:0,left:0}}return{top:b.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:b.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if(this.cssPosition=="relative"){var b=this.element.position();return{top:b.top-(parseInt(this.helper.css("top"),10)||0)+this.scrollParent.scrollTop(),left:b.left-(parseInt(this.helper.css("left"),10)||0)+this.scrollParent.scrollLeft()}}else{return{top:0,left:0}}},_cacheMargins:function(){this.margins={left:(parseInt(this.element.css("marginLeft"),10)||0),top:(parseInt(this.element.css("marginTop"),10)||0)}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var e=this.options;if(e.containment=="parent"){e.containment=this.helper[0].parentNode}if(e.containment=="document"||e.containment=="window"){this.containment=[0-this.offset.relative.left-this.offset.parent.left,0-this.offset.relative.top-this.offset.parent.top,a(e.containment=="document"?document:window).width()-this.helperProportions.width-this.margins.left,(a(e.containment=="document"?document:window).height()||document.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]}if(!(/^(document|window|parent)$/).test(e.containment)&&e.containment.constructor!=Array){var c=a(e.containment)[0];if(!c){return}var d=a(e.containment).offset();var b=(a(c).css("overflow")!="hidden");this.containment=[d.left+(parseInt(a(c).css("borderLeftWidth"),10)||0)+(parseInt(a(c).css("paddingLeft"),10)||0)-this.margins.left,d.top+(parseInt(a(c).css("borderTopWidth"),10)||0)+(parseInt(a(c).css("paddingTop"),10)||0)-this.margins.top,d.left+(b?Math.max(c.scrollWidth,c.offsetWidth):c.offsetWidth)-(parseInt(a(c).css("borderLeftWidth"),10)||0)-(parseInt(a(c).css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left,d.top+(b?Math.max(c.scrollHeight,c.offsetHeight):c.offsetHeight)-(parseInt(a(c).css("borderTopWidth"),10)||0)-(parseInt(a(c).css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top]}else{if(e.containment.constructor==Array){this.containment=e.containment}}},_convertPositionTo:function(f,h){if(!h){h=this.position}var c=f=="absolute"?1:-1;var e=this.options,b=this.cssPosition=="absolute"&&!(this.scrollParent[0]!=document&&a.ui.contains(this.scrollParent[0],this.offsetParent[0]))?this.offsetParent:this.scrollParent,g=(/(html|body)/i).test(b[0].tagName);return{top:(h.top+this.offset.relative.top*c+this.offset.parent.top*c-(a.browser.safari&&this.cssPosition=="fixed"?0:(this.cssPosition=="fixed"?-this.scrollParent.scrollTop():(g?0:b.scrollTop()))*c)),left:(h.left+this.offset.relative.left*c+this.offset.parent.left*c-(a.browser.safari&&this.cssPosition=="fixed"?0:(this.cssPosition=="fixed"?-this.scrollParent.scrollLeft():g?0:b.scrollLeft())*c))}},_generatePosition:function(e){var h=this.options,b=this.cssPosition=="absolute"&&!(this.scrollParent[0]!=document&&a.ui.contains(this.scrollParent[0],this.offsetParent[0]))?this.offsetParent:this.scrollParent,i=(/(html|body)/i).test(b[0].tagName);if(this.cssPosition=="relative"&&!(this.scrollParent[0]!=document&&this.scrollParent[0]!=this.offsetParent[0])){this.offset.relative=this._getRelativeOffset()}var d=e.pageX;var c=e.pageY;if(this.originalPosition){if(this.containment){if(e.pageX-this.offset.click.left<this.containment[0]){d=this.containment[0]+this.offset.click.left}if(e.pageY-this.offset.click.top<this.containment[1]){c=this.containment[1]+this.offset.click.top}if(e.pageX-this.offset.click.left>this.containment[2]){d=this.containment[2]+this.offset.click.left}if(e.pageY-this.offset.click.top>this.containment[3]){c=this.containment[3]+this.offset.click.top}}if(h.grid){var g=this.originalPageY+Math.round((c-this.originalPageY)/h.grid[1])*h.grid[1];c=this.containment?(!(g-this.offset.click.top<this.containment[1]||g-this.offset.click.top>this.containment[3])?g:(!(g-this.offset.click.top<this.containment[1])?g-h.grid[1]:g+h.grid[1])):g;var f=this.originalPageX+Math.round((d-this.originalPageX)/h.grid[0])*h.grid[0];d=this.containment?(!(f-this.offset.click.left<this.containment[0]||f-this.offset.click.left>this.containment[2])?f:(!(f-this.offset.click.left<this.containment[0])?f-h.grid[0]:f+h.grid[0])):f}}return{top:(c-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+(a.browser.safari&&this.cssPosition=="fixed"?0:(this.cssPosition=="fixed"?-this.scrollParent.scrollTop():(i?0:b.scrollTop())))),left:(d-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+(a.browser.safari&&this.cssPosition=="fixed"?0:(this.cssPosition=="fixed"?-this.scrollParent.scrollLeft():i?0:b.scrollLeft())))}},_clear:function(){this.helper.removeClass("ui-draggable-dragging");if(this.helper[0]!=this.element[0]&&!this.cancelHelperRemoval){this.helper.remove()}this.helper=null;this.cancelHelperRemoval=false},_trigger:function(b,c,d){d=d||this._uiHash();a.ui.plugin.call(this,b,[c,d]);if(b=="drag"){this.positionAbs=this._convertPositionTo("absolute")}return a.widget.prototype._trigger.call(this,b,c,d)},plugins:{},_uiHash:function(b){return{helper:this.helper,position:this.position,absolutePosition:this.positionAbs,offset:this.positionAbs}}}));a.extend(a.ui.draggable,{version:"1.7.2",eventPrefix:"drag",defaults:{addClasses:true,appendTo:"parent",axis:false,cancel:":input,option",connectToSortable:false,containment:false,cursor:"auto",cursorAt:false,delay:0,distance:1,grid:false,handle:false,helper:"original",iframeFix:false,opacity:false,refreshPositions:false,revert:false,revertDuration:500,scope:"default",scroll:true,scrollSensitivity:20,scrollSpeed:20,snap:false,snapMode:"both",snapTolerance:20,stack:false,zIndex:false}});a.ui.plugin.add("draggable","connectToSortable",{start:function(c,e){var d=a(this).data("draggable"),f=d.options,b=a.extend({},e,{item:d.element});d.sortables=[];a(f.connectToSortable).each(function(){var g=a.data(this,"sortable");if(g&&!g.options.disabled){d.sortables.push({instance:g,shouldRevert:g.options.revert});g._refreshItems();g._trigger("activate",c,b)}})},stop:function(c,e){var d=a(this).data("draggable"),b=a.extend({},e,{item:d.element});a.each(d.sortables,function(){if(this.instance.isOver){this.instance.isOver=0;d.cancelHelperRemoval=true;this.instance.cancelHelperRemoval=false;if(this.shouldRevert){this.instance.options.revert=true}this.instance._mouseStop(c);this.instance.options.helper=this.instance.options._helper;if(d.options.helper=="original"){this.instance.currentItem.css({top:"auto",left:"auto"})}}else{this.instance.cancelHelperRemoval=false;this.instance._trigger("deactivate",c,b)}})},drag:function(c,f){var e=a(this).data("draggable"),b=this;var d=function(i){var n=this.offset.click.top,m=this.offset.click.left;var g=this.positionAbs.top,k=this.positionAbs.left;var j=i.height,l=i.width;var p=i.top,h=i.left;return a.ui.isOver(g+n,k+m,p,h,j,l)};a.each(e.sortables,function(g){this.instance.positionAbs=e.positionAbs;this.instance.helperProportions=e.helperProportions;this.instance.offset.click=e.offset.click;if(this.instance._intersectsWith(this.instance.containerCache)){if(!this.instance.isOver){this.instance.isOver=1;this.instance.currentItem=a(b).clone().appendTo(this.instance.element).data("sortable-item",true);this.instance.options._helper=this.instance.options.helper;this.instance.options.helper=function(){return f.helper[0]};c.target=this.instance.currentItem[0];this.instance._mouseCapture(c,true);this.instance._mouseStart(c,true,true);this.instance.offset.click.top=e.offset.click.top;this.instance.offset.click.left=e.offset.click.left;this.instance.offset.parent.left-=e.offset.parent.left-this.instance.offset.parent.left;this.instance.offset.parent.top-=e.offset.parent.top-this.instance.offset.parent.top;e._trigger("toSortable",c);e.dropped=this.instance.element;e.currentItem=e.element;this.instance.fromOutside=e}if(this.instance.currentItem){this.instance._mouseDrag(c)}}else{if(this.instance.isOver){this.instance.isOver=0;this.instance.cancelHelperRemoval=true;this.instance.options.revert=false;this.instance._trigger("out",c,this.instance._uiHash(this.instance));this.instance._mouseStop(c,true);this.instance.options.helper=this.instance.options._helper;this.instance.currentItem.remove();if(this.instance.placeholder){this.instance.placeholder.remove()}e._trigger("fromSortable",c);e.dropped=false}}})}});a.ui.plugin.add("draggable","cursor",{start:function(c,d){var b=a("body"),e=a(this).data("draggable").options;if(b.css("cursor")){e._cursor=b.css("cursor")}b.css("cursor",e.cursor)},stop:function(b,c){var d=a(this).data("draggable").options;if(d._cursor){a("body").css("cursor",d._cursor)}}});a.ui.plugin.add("draggable","iframeFix",{start:function(b,c){var d=a(this).data("draggable").options;a(d.iframeFix===true?"iframe":d.iframeFix).each(function(){a('<div class="ui-draggable-iframeFix" style="background: #fff;"></div>').css({width:this.offsetWidth+"px",height:this.offsetHeight+"px",position:"absolute",opacity:"0.001",zIndex:1000}).css(a(this).offset()).appendTo("body")})},stop:function(b,c){a("div.ui-draggable-iframeFix").each(function(){this.parentNode.removeChild(this)})}});a.ui.plugin.add("draggable","opacity",{start:function(c,d){var b=a(d.helper),e=a(this).data("draggable").options;if(b.css("opacity")){e._opacity=b.css("opacity")}b.css("opacity",e.opacity)},stop:function(b,c){var d=a(this).data("draggable").options;if(d._opacity){a(c.helper).css("opacity",d._opacity)}}});a.ui.plugin.add("draggable","scroll",{start:function(c,d){var b=a(this).data("draggable");if(b.scrollParent[0]!=document&&b.scrollParent[0].tagName!="HTML"){b.overflowOffset=b.scrollParent.offset()}},drag:function(d,e){var c=a(this).data("draggable"),f=c.options,b=false;if(c.scrollParent[0]!=document&&c.scrollParent[0].tagName!="HTML"){if(!f.axis||f.axis!="x"){if((c.overflowOffset.top+c.scrollParent[0].offsetHeight)-d.pageY<f.scrollSensitivity){c.scrollParent[0].scrollTop=b=c.scrollParent[0].scrollTop+f.scrollSpeed}else{if(d.pageY-c.overflowOffset.top<f.scrollSensitivity){c.scrollParent[0].scrollTop=b=c.scrollParent[0].scrollTop-f.scrollSpeed}}}if(!f.axis||f.axis!="y"){if((c.overflowOffset.left+c.scrollParent[0].offsetWidth)-d.pageX<f.scrollSensitivity){c.scrollParent[0].scrollLeft=b=c.scrollParent[0].scrollLeft+f.scrollSpeed}else{if(d.pageX-c.overflowOffset.left<f.scrollSensitivity){c.scrollParent[0].scrollLeft=b=c.scrollParent[0].scrollLeft-f.scrollSpeed}}}}else{if(!f.axis||f.axis!="x"){if(d.pageY-a(document).scrollTop()<f.scrollSensitivity){b=a(document).scrollTop(a(document).scrollTop()-f.scrollSpeed)}else{if(a(window).height()-(d.pageY-a(document).scrollTop())<f.scrollSensitivity){b=a(document).scrollTop(a(document).scrollTop()+f.scrollSpeed)}}}if(!f.axis||f.axis!="y"){if(d.pageX-a(document).scrollLeft()<f.scrollSensitivity){b=a(document).scrollLeft(a(document).scrollLeft()-f.scrollSpeed)}else{if(a(window).width()-(d.pageX-a(document).scrollLeft())<f.scrollSensitivity){b=a(document).scrollLeft(a(document).scrollLeft()+f.scrollSpeed)}}}}if(b!==false&&a.ui.ddmanager&&!f.dropBehaviour){a.ui.ddmanager.prepareOffsets(c,d)}}});a.ui.plugin.add("draggable","snap",{start:function(c,d){var b=a(this).data("draggable"),e=b.options;b.snapElements=[];a(e.snap.constructor!=String?(e.snap.items||":data(draggable)"):e.snap).each(function(){var g=a(this);var f=g.offset();if(this!=b.element[0]){b.snapElements.push({item:this,width:g.outerWidth(),height:g.outerHeight(),top:f.top,left:f.left})}})},drag:function(u,p){var g=a(this).data("draggable"),q=g.options;var y=q.snapTolerance;var x=p.offset.left,w=x+g.helperProportions.width,f=p.offset.top,e=f+g.helperProportions.height;for(var v=g.snapElements.length-1;v>=0;v--){var s=g.snapElements[v].left,n=s+g.snapElements[v].width,m=g.snapElements[v].top,A=m+g.snapElements[v].height;if(!((s-y<x&&x<n+y&&m-y<f&&f<A+y)||(s-y<x&&x<n+y&&m-y<e&&e<A+y)||(s-y<w&&w<n+y&&m-y<f&&f<A+y)||(s-y<w&&w<n+y&&m-y<e&&e<A+y))){if(g.snapElements[v].snapping){(g.options.snap.release&&g.options.snap.release.call(g.element,u,a.extend(g._uiHash(),{snapItem:g.snapElements[v].item})))}g.snapElements[v].snapping=false;continue}if(q.snapMode!="inner"){var c=Math.abs(m-e)<=y;var z=Math.abs(A-f)<=y;var j=Math.abs(s-w)<=y;var k=Math.abs(n-x)<=y;if(c){p.position.top=g._convertPositionTo("relative",{top:m-g.helperProportions.height,left:0}).top-g.margins.top}if(z){p.position.top=g._convertPositionTo("relative",{top:A,left:0}).top-g.margins.top}if(j){p.position.left=g._convertPositionTo("relative",{top:0,left:s-g.helperProportions.width}).left-g.margins.left}if(k){p.position.left=g._convertPositionTo("relative",{top:0,left:n}).left-g.margins.left}}var h=(c||z||j||k);if(q.snapMode!="outer"){var c=Math.abs(m-f)<=y;var z=Math.abs(A-e)<=y;var j=Math.abs(s-x)<=y;var k=Math.abs(n-w)<=y;if(c){p.position.top=g._convertPositionTo("relative",{top:m,left:0}).top-g.margins.top}if(z){p.position.top=g._convertPositionTo("relative",{top:A-g.helperProportions.height,left:0}).top-g.margins.top}if(j){p.position.left=g._convertPositionTo("relative",{top:0,left:s}).left-g.margins.left}if(k){p.position.left=g._convertPositionTo("relative",{top:0,left:n-g.helperProportions.width}).left-g.margins.left}}if(!g.snapElements[v].snapping&&(c||z||j||k||h)){(g.options.snap.snap&&g.options.snap.snap.call(g.element,u,a.extend(g._uiHash(),{snapItem:g.snapElements[v].item})))}g.snapElements[v].snapping=(c||z||j||k||h)}}});a.ui.plugin.add("draggable","stack",{start:function(b,c){var e=a(this).data("draggable").options;var d=a.makeArray(a(e.stack.group)).sort(function(g,f){return(parseInt(a(g).css("zIndex"),10)||e.stack.min)-(parseInt(a(f).css("zIndex"),10)||e.stack.min)});a(d).each(function(f){this.style.zIndex=e.stack.min+f});this[0].style.zIndex=e.stack.min+d.length}});a.ui.plugin.add("draggable","zIndex",{start:function(c,d){var b=a(d.helper),e=a(this).data("draggable").options;if(b.css("zIndex")){e._zIndex=b.css("zIndex")}b.css("zIndex",e.zIndex)},stop:function(b,c){var d=a(this).data("draggable").options;if(d._zIndex){a(c.helper).css("zIndex",d._zIndex)}}})})(jQuery);;/*
 * jQuery UI Resizable 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Resizables
 *
 * Depends:
 *	ui.core.js
 */
(function(c){c.widget("ui.resizable",c.extend({},c.ui.mouse,{_init:function(){var e=this,j=this.options;this.element.addClass("ui-resizable");c.extend(this,{_aspectRatio:!!(j.aspectRatio),aspectRatio:j.aspectRatio,originalElement:this.element,_proportionallyResizeElements:[],_helper:j.helper||j.ghost||j.animate?j.helper||"ui-resizable-helper":null});if(this.element[0].nodeName.match(/canvas|textarea|input|select|button|img/i)){if(/relative/.test(this.element.css("position"))&&c.browser.opera){this.element.css({position:"relative",top:"auto",left:"auto"})}this.element.wrap(c('<div class="ui-wrapper" style="overflow: hidden;"></div>').css({position:this.element.css("position"),width:this.element.outerWidth(),height:this.element.outerHeight(),top:this.element.css("top"),left:this.element.css("left")}));this.element=this.element.parent().data("resizable",this.element.data("resizable"));this.elementIsWrapper=true;this.element.css({marginLeft:this.originalElement.css("marginLeft"),marginTop:this.originalElement.css("marginTop"),marginRight:this.originalElement.css("marginRight"),marginBottom:this.originalElement.css("marginBottom")});this.originalElement.css({marginLeft:0,marginTop:0,marginRight:0,marginBottom:0});this.originalResizeStyle=this.originalElement.css("resize");this.originalElement.css("resize","none");this._proportionallyResizeElements.push(this.originalElement.css({position:"static",zoom:1,display:"block"}));this.originalElement.css({margin:this.originalElement.css("margin")});this._proportionallyResize()}this.handles=j.handles||(!c(".ui-resizable-handle",this.element).length?"e,s,se":{n:".ui-resizable-n",e:".ui-resizable-e",s:".ui-resizable-s",w:".ui-resizable-w",se:".ui-resizable-se",sw:".ui-resizable-sw",ne:".ui-resizable-ne",nw:".ui-resizable-nw"});if(this.handles.constructor==String){if(this.handles=="all"){this.handles="n,e,s,w,se,sw,ne,nw"}var k=this.handles.split(",");this.handles={};for(var f=0;f<k.length;f++){var h=c.trim(k[f]),d="ui-resizable-"+h;var g=c('<div class="ui-resizable-handle '+d+'"></div>');if(/sw|se|ne|nw/.test(h)){g.css({zIndex:++j.zIndex})}if("se"==h){g.addClass("ui-icon ui-icon-gripsmall-diagonal-se")}this.handles[h]=".ui-resizable-"+h;this.element.append(g)}}this._renderAxis=function(p){p=p||this.element;for(var m in this.handles){if(this.handles[m].constructor==String){this.handles[m]=c(this.handles[m],this.element).show()}if(this.elementIsWrapper&&this.originalElement[0].nodeName.match(/textarea|input|select|button/i)){var n=c(this.handles[m],this.element),o=0;o=/sw|ne|nw|se|n|s/.test(m)?n.outerHeight():n.outerWidth();var l=["padding",/ne|nw|n/.test(m)?"Top":/se|sw|s/.test(m)?"Bottom":/^e$/.test(m)?"Right":"Left"].join("");p.css(l,o);this._proportionallyResize()}if(!c(this.handles[m]).length){continue}}};this._renderAxis(this.element);this._handles=c(".ui-resizable-handle",this.element).disableSelection();this._handles.mouseover(function(){if(!e.resizing){if(this.className){var i=this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)}e.axis=i&&i[1]?i[1]:"se"}});if(j.autoHide){this._handles.hide();c(this.element).addClass("ui-resizable-autohide").hover(function(){c(this).removeClass("ui-resizable-autohide");e._handles.show()},function(){if(!e.resizing){c(this).addClass("ui-resizable-autohide");e._handles.hide()}})}this._mouseInit()},destroy:function(){this._mouseDestroy();var d=function(f){c(f).removeClass("ui-resizable ui-resizable-disabled ui-resizable-resizing").removeData("resizable").unbind(".resizable").find(".ui-resizable-handle").remove()};if(this.elementIsWrapper){d(this.element);var e=this.element;e.parent().append(this.originalElement.css({position:e.css("position"),width:e.outerWidth(),height:e.outerHeight(),top:e.css("top"),left:e.css("left")})).end().remove()}this.originalElement.css("resize",this.originalResizeStyle);d(this.originalElement)},_mouseCapture:function(e){var f=false;for(var d in this.handles){if(c(this.handles[d])[0]==e.target){f=true}}return this.options.disabled||!!f},_mouseStart:function(f){var i=this.options,e=this.element.position(),d=this.element;this.resizing=true;this.documentScroll={top:c(document).scrollTop(),left:c(document).scrollLeft()};if(d.is(".ui-draggable")||(/absolute/).test(d.css("position"))){d.css({position:"absolute",top:e.top,left:e.left})}if(c.browser.opera&&(/relative/).test(d.css("position"))){d.css({position:"relative",top:"auto",left:"auto"})}this._renderProxy();var j=b(this.helper.css("left")),g=b(this.helper.css("top"));if(i.containment){j+=c(i.containment).scrollLeft()||0;g+=c(i.containment).scrollTop()||0}this.offset=this.helper.offset();this.position={left:j,top:g};this.size=this._helper?{width:d.outerWidth(),height:d.outerHeight()}:{width:d.width(),height:d.height()};this.originalSize=this._helper?{width:d.outerWidth(),height:d.outerHeight()}:{width:d.width(),height:d.height()};this.originalPosition={left:j,top:g};this.sizeDiff={width:d.outerWidth()-d.width(),height:d.outerHeight()-d.height()};this.originalMousePosition={left:f.pageX,top:f.pageY};this.aspectRatio=(typeof i.aspectRatio=="number")?i.aspectRatio:((this.originalSize.width/this.originalSize.height)||1);var h=c(".ui-resizable-"+this.axis).css("cursor");c("body").css("cursor",h=="auto"?this.axis+"-resize":h);d.addClass("ui-resizable-resizing");this._propagate("start",f);return true},_mouseDrag:function(d){var g=this.helper,f=this.options,l={},p=this,i=this.originalMousePosition,m=this.axis;var q=(d.pageX-i.left)||0,n=(d.pageY-i.top)||0;var h=this._change[m];if(!h){return false}var k=h.apply(this,[d,q,n]),j=c.browser.msie&&c.browser.version<7,e=this.sizeDiff;if(this._aspectRatio||d.shiftKey){k=this._updateRatio(k,d)}k=this._respectSize(k,d);this._propagate("resize",d);g.css({top:this.position.top+"px",left:this.position.left+"px",width:this.size.width+"px",height:this.size.height+"px"});if(!this._helper&&this._proportionallyResizeElements.length){this._proportionallyResize()}this._updateCache(k);this._trigger("resize",d,this.ui());return false},_mouseStop:function(g){this.resizing=false;var h=this.options,l=this;if(this._helper){var f=this._proportionallyResizeElements,d=f.length&&(/textarea/i).test(f[0].nodeName),e=d&&c.ui.hasScroll(f[0],"left")?0:l.sizeDiff.height,j=d?0:l.sizeDiff.width;var m={width:(l.size.width-j),height:(l.size.height-e)},i=(parseInt(l.element.css("left"),10)+(l.position.left-l.originalPosition.left))||null,k=(parseInt(l.element.css("top"),10)+(l.position.top-l.originalPosition.top))||null;if(!h.animate){this.element.css(c.extend(m,{top:k,left:i}))}l.helper.height(l.size.height);l.helper.width(l.size.width);if(this._helper&&!h.animate){this._proportionallyResize()}}c("body").css("cursor","auto");this.element.removeClass("ui-resizable-resizing");this._propagate("stop",g);if(this._helper){this.helper.remove()}return false},_updateCache:function(d){var e=this.options;this.offset=this.helper.offset();if(a(d.left)){this.position.left=d.left}if(a(d.top)){this.position.top=d.top}if(a(d.height)){this.size.height=d.height}if(a(d.width)){this.size.width=d.width}},_updateRatio:function(g,f){var h=this.options,i=this.position,e=this.size,d=this.axis;if(g.height){g.width=(e.height*this.aspectRatio)}else{if(g.width){g.height=(e.width/this.aspectRatio)}}if(d=="sw"){g.left=i.left+(e.width-g.width);g.top=null}if(d=="nw"){g.top=i.top+(e.height-g.height);g.left=i.left+(e.width-g.width)}return g},_respectSize:function(k,f){var i=this.helper,h=this.options,q=this._aspectRatio||f.shiftKey,p=this.axis,s=a(k.width)&&h.maxWidth&&(h.maxWidth<k.width),l=a(k.height)&&h.maxHeight&&(h.maxHeight<k.height),g=a(k.width)&&h.minWidth&&(h.minWidth>k.width),r=a(k.height)&&h.minHeight&&(h.minHeight>k.height);if(g){k.width=h.minWidth}if(r){k.height=h.minHeight}if(s){k.width=h.maxWidth}if(l){k.height=h.maxHeight}var e=this.originalPosition.left+this.originalSize.width,n=this.position.top+this.size.height;var j=/sw|nw|w/.test(p),d=/nw|ne|n/.test(p);if(g&&j){k.left=e-h.minWidth}if(s&&j){k.left=e-h.maxWidth}if(r&&d){k.top=n-h.minHeight}if(l&&d){k.top=n-h.maxHeight}var m=!k.width&&!k.height;if(m&&!k.left&&k.top){k.top=null}else{if(m&&!k.top&&k.left){k.left=null}}return k},_proportionallyResize:function(){var j=this.options;if(!this._proportionallyResizeElements.length){return}var f=this.helper||this.element;for(var e=0;e<this._proportionallyResizeElements.length;e++){var g=this._proportionallyResizeElements[e];if(!this.borderDif){var d=[g.css("borderTopWidth"),g.css("borderRightWidth"),g.css("borderBottomWidth"),g.css("borderLeftWidth")],h=[g.css("paddingTop"),g.css("paddingRight"),g.css("paddingBottom"),g.css("paddingLeft")];this.borderDif=c.map(d,function(k,m){var l=parseInt(k,10)||0,n=parseInt(h[m],10)||0;return l+n})}if(c.browser.msie&&!(!(c(f).is(":hidden")||c(f).parents(":hidden").length))){continue}g.css({height:(f.height()-this.borderDif[0]-this.borderDif[2])||0,width:(f.width()-this.borderDif[1]-this.borderDif[3])||0})}},_renderProxy:function(){var e=this.element,h=this.options;this.elementOffset=e.offset();if(this._helper){this.helper=this.helper||c('<div style="overflow:hidden;"></div>');var d=c.browser.msie&&c.browser.version<7,f=(d?1:0),g=(d?2:-1);this.helper.addClass(this._helper).css({width:this.element.outerWidth()+g,height:this.element.outerHeight()+g,position:"absolute",left:this.elementOffset.left-f+"px",top:this.elementOffset.top-f+"px",zIndex:++h.zIndex});this.helper.appendTo("body").disableSelection()}else{this.helper=this.element}},_change:{e:function(f,e,d){return{width:this.originalSize.width+e}},w:function(g,e,d){var i=this.options,f=this.originalSize,h=this.originalPosition;return{left:h.left+e,width:f.width-e}},n:function(g,e,d){var i=this.options,f=this.originalSize,h=this.originalPosition;return{top:h.top+d,height:f.height-d}},s:function(f,e,d){return{height:this.originalSize.height+d}},se:function(f,e,d){return c.extend(this._change.s.apply(this,arguments),this._change.e.apply(this,[f,e,d]))},sw:function(f,e,d){return c.extend(this._change.s.apply(this,arguments),this._change.w.apply(this,[f,e,d]))},ne:function(f,e,d){return c.extend(this._change.n.apply(this,arguments),this._change.e.apply(this,[f,e,d]))},nw:function(f,e,d){return c.extend(this._change.n.apply(this,arguments),this._change.w.apply(this,[f,e,d]))}},_propagate:function(e,d){c.ui.plugin.call(this,e,[d,this.ui()]);(e!="resize"&&this._trigger(e,d,this.ui()))},plugins:{},ui:function(){return{originalElement:this.originalElement,element:this.element,helper:this.helper,position:this.position,size:this.size,originalSize:this.originalSize,originalPosition:this.originalPosition}}}));c.extend(c.ui.resizable,{version:"1.7.2",eventPrefix:"resize",defaults:{alsoResize:false,animate:false,animateDuration:"slow",animateEasing:"swing",aspectRatio:false,autoHide:false,cancel:":input,option",containment:false,delay:0,distance:1,ghost:false,grid:false,handles:"e,s,se",helper:false,maxHeight:null,maxWidth:null,minHeight:10,minWidth:10,zIndex:1000}});c.ui.plugin.add("resizable","alsoResize",{start:function(e,f){var d=c(this).data("resizable"),g=d.options;_store=function(h){c(h).each(function(){c(this).data("resizable-alsoresize",{width:parseInt(c(this).width(),10),height:parseInt(c(this).height(),10),left:parseInt(c(this).css("left"),10),top:parseInt(c(this).css("top"),10)})})};if(typeof(g.alsoResize)=="object"&&!g.alsoResize.parentNode){if(g.alsoResize.length){g.alsoResize=g.alsoResize[0];_store(g.alsoResize)}else{c.each(g.alsoResize,function(h,i){_store(h)})}}else{_store(g.alsoResize)}},resize:function(f,h){var e=c(this).data("resizable"),i=e.options,g=e.originalSize,k=e.originalPosition;var j={height:(e.size.height-g.height)||0,width:(e.size.width-g.width)||0,top:(e.position.top-k.top)||0,left:(e.position.left-k.left)||0},d=function(l,m){c(l).each(function(){var p=c(this),q=c(this).data("resizable-alsoresize"),o={},n=m&&m.length?m:["width","height","top","left"];c.each(n||["width","height","top","left"],function(r,t){var s=(q[t]||0)+(j[t]||0);if(s&&s>=0){o[t]=s||null}});if(/relative/.test(p.css("position"))&&c.browser.opera){e._revertToRelativePosition=true;p.css({position:"absolute",top:"auto",left:"auto"})}p.css(o)})};if(typeof(i.alsoResize)=="object"&&!i.alsoResize.nodeType){c.each(i.alsoResize,function(l,m){d(l,m)})}else{d(i.alsoResize)}},stop:function(e,f){var d=c(this).data("resizable");if(d._revertToRelativePosition&&c.browser.opera){d._revertToRelativePosition=false;el.css({position:"relative"})}c(this).removeData("resizable-alsoresize-start")}});c.ui.plugin.add("resizable","animate",{stop:function(h,m){var n=c(this).data("resizable"),i=n.options;var g=n._proportionallyResizeElements,d=g.length&&(/textarea/i).test(g[0].nodeName),e=d&&c.ui.hasScroll(g[0],"left")?0:n.sizeDiff.height,k=d?0:n.sizeDiff.width;var f={width:(n.size.width-k),height:(n.size.height-e)},j=(parseInt(n.element.css("left"),10)+(n.position.left-n.originalPosition.left))||null,l=(parseInt(n.element.css("top"),10)+(n.position.top-n.originalPosition.top))||null;n.element.animate(c.extend(f,l&&j?{top:l,left:j}:{}),{duration:i.animateDuration,easing:i.animateEasing,step:function(){var o={width:parseInt(n.element.css("width"),10),height:parseInt(n.element.css("height"),10),top:parseInt(n.element.css("top"),10),left:parseInt(n.element.css("left"),10)};if(g&&g.length){c(g[0]).css({width:o.width,height:o.height})}n._updateCache(o);n._propagate("resize",h)}})}});c.ui.plugin.add("resizable","containment",{start:function(e,q){var s=c(this).data("resizable"),i=s.options,k=s.element;var f=i.containment,j=(f instanceof c)?f.get(0):(/parent/.test(f))?k.parent().get(0):f;if(!j){return}s.containerElement=c(j);if(/document/.test(f)||f==document){s.containerOffset={left:0,top:0};s.containerPosition={left:0,top:0};s.parentData={element:c(document),left:0,top:0,width:c(document).width(),height:c(document).height()||document.body.parentNode.scrollHeight}}else{var m=c(j),h=[];c(["Top","Right","Left","Bottom"]).each(function(p,o){h[p]=b(m.css("padding"+o))});s.containerOffset=m.offset();s.containerPosition=m.position();s.containerSize={height:(m.innerHeight()-h[3]),width:(m.innerWidth()-h[1])};var n=s.containerOffset,d=s.containerSize.height,l=s.containerSize.width,g=(c.ui.hasScroll(j,"left")?j.scrollWidth:l),r=(c.ui.hasScroll(j)?j.scrollHeight:d);s.parentData={element:j,left:n.left,top:n.top,width:g,height:r}}},resize:function(f,p){var s=c(this).data("resizable"),h=s.options,e=s.containerSize,n=s.containerOffset,l=s.size,m=s.position,q=s._aspectRatio||f.shiftKey,d={top:0,left:0},g=s.containerElement;if(g[0]!=document&&(/static/).test(g.css("position"))){d=n}if(m.left<(s._helper?n.left:0)){s.size.width=s.size.width+(s._helper?(s.position.left-n.left):(s.position.left-d.left));if(q){s.size.height=s.size.width/h.aspectRatio}s.position.left=h.helper?n.left:0}if(m.top<(s._helper?n.top:0)){s.size.height=s.size.height+(s._helper?(s.position.top-n.top):s.position.top);if(q){s.size.width=s.size.height*h.aspectRatio}s.position.top=s._helper?n.top:0}s.offset.left=s.parentData.left+s.position.left;s.offset.top=s.parentData.top+s.position.top;var k=Math.abs((s._helper?s.offset.left-d.left:(s.offset.left-d.left))+s.sizeDiff.width),r=Math.abs((s._helper?s.offset.top-d.top:(s.offset.top-n.top))+s.sizeDiff.height);var j=s.containerElement.get(0)==s.element.parent().get(0),i=/relative|absolute/.test(s.containerElement.css("position"));if(j&&i){k-=s.parentData.left}if(k+s.size.width>=s.parentData.width){s.size.width=s.parentData.width-k;if(q){s.size.height=s.size.width/s.aspectRatio}}if(r+s.size.height>=s.parentData.height){s.size.height=s.parentData.height-r;if(q){s.size.width=s.size.height*s.aspectRatio}}},stop:function(e,m){var p=c(this).data("resizable"),f=p.options,k=p.position,l=p.containerOffset,d=p.containerPosition,g=p.containerElement;var i=c(p.helper),q=i.offset(),n=i.outerWidth()-p.sizeDiff.width,j=i.outerHeight()-p.sizeDiff.height;if(p._helper&&!f.animate&&(/relative/).test(g.css("position"))){c(this).css({left:q.left-d.left-l.left,width:n,height:j})}if(p._helper&&!f.animate&&(/static/).test(g.css("position"))){c(this).css({left:q.left-d.left-l.left,width:n,height:j})}}});c.ui.plugin.add("resizable","ghost",{start:function(f,g){var d=c(this).data("resizable"),h=d.options,e=d.size;d.ghost=d.originalElement.clone();d.ghost.css({opacity:0.25,display:"block",position:"relative",height:e.height,width:e.width,margin:0,left:0,top:0}).addClass("ui-resizable-ghost").addClass(typeof h.ghost=="string"?h.ghost:"");d.ghost.appendTo(d.helper)},resize:function(e,f){var d=c(this).data("resizable"),g=d.options;if(d.ghost){d.ghost.css({position:"relative",height:d.size.height,width:d.size.width})}},stop:function(e,f){var d=c(this).data("resizable"),g=d.options;if(d.ghost&&d.helper){d.helper.get(0).removeChild(d.ghost.get(0))}}});c.ui.plugin.add("resizable","grid",{resize:function(d,l){var n=c(this).data("resizable"),g=n.options,j=n.size,h=n.originalSize,i=n.originalPosition,m=n.axis,k=g._aspectRatio||d.shiftKey;g.grid=typeof g.grid=="number"?[g.grid,g.grid]:g.grid;var f=Math.round((j.width-h.width)/(g.grid[0]||1))*(g.grid[0]||1),e=Math.round((j.height-h.height)/(g.grid[1]||1))*(g.grid[1]||1);if(/^(se|s|e)$/.test(m)){n.size.width=h.width+f;n.size.height=h.height+e}else{if(/^(ne)$/.test(m)){n.size.width=h.width+f;n.size.height=h.height+e;n.position.top=i.top-e}else{if(/^(sw)$/.test(m)){n.size.width=h.width+f;n.size.height=h.height+e;n.position.left=i.left-f}else{n.size.width=h.width+f;n.size.height=h.height+e;n.position.top=i.top-e;n.position.left=i.left-f}}}}});var b=function(d){return parseInt(d,10)||0};var a=function(d){return !isNaN(parseInt(d,10))}})(jQuery);;/*
 * jQuery UI Dialog 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Dialog
 *
 * Depends:
 *	ui.core.js
 *	ui.draggable.js
 *	ui.resizable.js
 */
(function(c){var b={dragStart:"start.draggable",drag:"drag.draggable",dragStop:"stop.draggable",maxHeight:"maxHeight.resizable",minHeight:"minHeight.resizable",maxWidth:"maxWidth.resizable",minWidth:"minWidth.resizable",resizeStart:"start.resizable",resize:"drag.resizable",resizeStop:"stop.resizable"},a="ui-dialog ui-widget ui-widget-content ui-corner-all ";c.widget("ui.dialog",{_init:function(){this.originalTitle=this.element.attr("title");var l=this,m=this.options,j=m.title||this.originalTitle||"&nbsp;",e=c.ui.dialog.getTitleId(this.element),k=(this.uiDialog=c("<div/>")).appendTo(document.body).hide().addClass(a+m.dialogClass).css({position:"absolute",overflow:"hidden",zIndex:m.zIndex}).attr("tabIndex",-1).css("outline",0).keydown(function(n){(m.closeOnEscape&&n.keyCode&&n.keyCode==c.ui.keyCode.ESCAPE&&l.close(n))}).attr({role:"dialog","aria-labelledby":e}).mousedown(function(n){l.moveToTop(false,n)}),g=this.element.show().removeAttr("title").addClass("ui-dialog-content ui-widget-content").appendTo(k),f=(this.uiDialogTitlebar=c("<div></div>")).addClass("ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix").prependTo(k),i=c('<a href="#"/>').addClass("ui-dialog-titlebar-close ui-corner-all").attr("role","button").hover(function(){i.addClass("ui-state-hover")},function(){i.removeClass("ui-state-hover")}).focus(function(){i.addClass("ui-state-focus")}).blur(function(){i.removeClass("ui-state-focus")}).mousedown(function(n){n.stopPropagation()}).click(function(n){l.close(n);return false}).appendTo(f),h=(this.uiDialogTitlebarCloseText=c("<span/>")).addClass("ui-icon ui-icon-closethick").text(m.closeText).appendTo(i),d=c("<span/>").addClass("ui-dialog-title").attr("id",e).html(j).prependTo(f);f.find("*").add(f).disableSelection();(m.draggable&&c.fn.draggable&&this._makeDraggable());(m.resizable&&c.fn.resizable&&this._makeResizable());this._createButtons(m.buttons);this._isOpen=false;(m.bgiframe&&c.fn.bgiframe&&k.bgiframe());(m.autoOpen&&this.open())},destroy:function(){(this.overlay&&this.overlay.destroy());this.uiDialog.hide();this.element.unbind(".dialog").removeData("dialog").removeClass("ui-dialog-content ui-widget-content").hide().appendTo("body");this.uiDialog.remove();(this.originalTitle&&this.element.attr("title",this.originalTitle))},close:function(f){var d=this;if(false===d._trigger("beforeclose",f)){return}(d.overlay&&d.overlay.destroy());d.uiDialog.unbind("keypress.ui-dialog");(d.options.hide?d.uiDialog.hide(d.options.hide,function(){d._trigger("close",f)}):d.uiDialog.hide()&&d._trigger("close",f));c.ui.dialog.overlay.resize();d._isOpen=false;if(d.options.modal){var e=0;c(".ui-dialog").each(function(){if(this!=d.uiDialog[0]){e=Math.max(e,c(this).css("z-index"))}});c.ui.dialog.maxZ=e}},isOpen:function(){return this._isOpen},moveToTop:function(f,e){if((this.options.modal&&!f)||(!this.options.stack&&!this.options.modal)){return this._trigger("focus",e)}if(this.options.zIndex>c.ui.dialog.maxZ){c.ui.dialog.maxZ=this.options.zIndex}(this.overlay&&this.overlay.$el.css("z-index",c.ui.dialog.overlay.maxZ=++c.ui.dialog.maxZ));var d={scrollTop:this.element.attr("scrollTop"),scrollLeft:this.element.attr("scrollLeft")};this.uiDialog.css("z-index",++c.ui.dialog.maxZ);this.element.attr(d);this._trigger("focus",e)},open:function(){if(this._isOpen){return}var e=this.options,d=this.uiDialog;this.overlay=e.modal?new c.ui.dialog.overlay(this):null;(d.next().length&&d.appendTo("body"));this._size();this._position(e.position);d.show(e.show);this.moveToTop(true);(e.modal&&d.bind("keypress.ui-dialog",function(h){if(h.keyCode!=c.ui.keyCode.TAB){return}var g=c(":tabbable",this),i=g.filter(":first")[0],f=g.filter(":last")[0];if(h.target==f&&!h.shiftKey){setTimeout(function(){i.focus()},1)}else{if(h.target==i&&h.shiftKey){setTimeout(function(){f.focus()},1)}}}));c([]).add(d.find(".ui-dialog-content :tabbable:first")).add(d.find(".ui-dialog-buttonpane :tabbable:first")).add(d).filter(":first").focus();this._trigger("open");this._isOpen=true},_createButtons:function(g){var f=this,d=false,e=c("<div></div>").addClass("ui-dialog-buttonpane ui-widget-content ui-helper-clearfix");this.uiDialog.find(".ui-dialog-buttonpane").remove();(typeof g=="object"&&g!==null&&c.each(g,function(){return !(d=true)}));if(d){c.each(g,function(h,i){c('<button type="button"></button>').addClass("ui-state-default ui-corner-all").text(h).click(function(){i.apply(f.element[0],arguments)}).hover(function(){c(this).addClass("ui-state-hover")},function(){c(this).removeClass("ui-state-hover")}).focus(function(){c(this).addClass("ui-state-focus")}).blur(function(){c(this).removeClass("ui-state-focus")}).appendTo(e)});e.appendTo(this.uiDialog)}},_makeDraggable:function(){var d=this,f=this.options,e;this.uiDialog.draggable({cancel:".ui-dialog-content",handle:".ui-dialog-titlebar",containment:"document",start:function(){e=f.height;c(this).height(c(this).height()).addClass("ui-dialog-dragging");(f.dragStart&&f.dragStart.apply(d.element[0],arguments))},drag:function(){(f.drag&&f.drag.apply(d.element[0],arguments))},stop:function(){c(this).removeClass("ui-dialog-dragging").height(e);(f.dragStop&&f.dragStop.apply(d.element[0],arguments));c.ui.dialog.overlay.resize()}})},_makeResizable:function(g){g=(g===undefined?this.options.resizable:g);var d=this,f=this.options,e=typeof g=="string"?g:"n,e,s,w,se,sw,ne,nw";this.uiDialog.resizable({cancel:".ui-dialog-content",alsoResize:this.element,maxWidth:f.maxWidth,maxHeight:f.maxHeight,minWidth:f.minWidth,minHeight:f.minHeight,start:function(){c(this).addClass("ui-dialog-resizing");(f.resizeStart&&f.resizeStart.apply(d.element[0],arguments))},resize:function(){(f.resize&&f.resize.apply(d.element[0],arguments))},handles:e,stop:function(){c(this).removeClass("ui-dialog-resizing");f.height=c(this).height();f.width=c(this).width();(f.resizeStop&&f.resizeStop.apply(d.element[0],arguments));c.ui.dialog.overlay.resize()}}).find(".ui-resizable-se").addClass("ui-icon ui-icon-grip-diagonal-se")},_position:function(i){var e=c(window),f=c(document),g=f.scrollTop(),d=f.scrollLeft(),h=g;if(c.inArray(i,["center","top","right","bottom","left"])>=0){i=[i=="right"||i=="left"?i:"center",i=="top"||i=="bottom"?i:"middle"]}if(i.constructor!=Array){i=["center","middle"]}if(i[0].constructor==Number){d+=i[0]}else{switch(i[0]){case"left":d+=0;break;case"right":d+=e.width()-this.uiDialog.outerWidth();break;default:case"center":d+=(e.width()-this.uiDialog.outerWidth())/2}}if(i[1].constructor==Number){g+=i[1]}else{switch(i[1]){case"top":g+=0;break;case"bottom":g+=e.height()-this.uiDialog.outerHeight();break;default:case"middle":g+=(e.height()-this.uiDialog.outerHeight())/2}}g=Math.max(g,h);this.uiDialog.css({top:g,left:d})},_setData:function(e,f){(b[e]&&this.uiDialog.data(b[e],f));switch(e){case"buttons":this._createButtons(f);break;case"closeText":this.uiDialogTitlebarCloseText.text(f);break;case"dialogClass":this.uiDialog.removeClass(this.options.dialogClass).addClass(a+f);break;case"draggable":(f?this._makeDraggable():this.uiDialog.draggable("destroy"));break;case"height":this.uiDialog.height(f);break;case"position":this._position(f);break;case"resizable":var d=this.uiDialog,g=this.uiDialog.is(":data(resizable)");(g&&!f&&d.resizable("destroy"));(g&&typeof f=="string"&&d.resizable("option","handles",f));(g||this._makeResizable(f));break;case"title":c(".ui-dialog-title",this.uiDialogTitlebar).html(f||"&nbsp;");break;case"width":this.uiDialog.width(f);break}c.widget.prototype._setData.apply(this,arguments)},_size:function(){var e=this.options;this.element.css({height:0,minHeight:0,width:"auto"});var d=this.uiDialog.css({height:"auto",width:e.width}).height();this.element.css({minHeight:Math.max(e.minHeight-d,0),height:e.height=="auto"?"auto":Math.max(e.height-d,0)})}});c.extend(c.ui.dialog,{version:"1.7.2",defaults:{autoOpen:true,bgiframe:false,buttons:{},closeOnEscape:true,closeText:"close",dialogClass:"",draggable:true,hide:null,height:"auto",maxHeight:false,maxWidth:false,minHeight:150,minWidth:150,modal:false,position:"center",resizable:true,show:null,stack:true,title:"",width:300,zIndex:1000},getter:"isOpen",uuid:0,maxZ:0,getTitleId:function(d){return"ui-dialog-title-"+(d.attr("id")||++this.uuid)},overlay:function(d){this.$el=c.ui.dialog.overlay.create(d)}});c.extend(c.ui.dialog.overlay,{instances:[],maxZ:0,events:c.map("focus,mousedown,mouseup,keydown,keypress,click".split(","),function(d){return d+".dialog-overlay"}).join(" "),create:function(e){if(this.instances.length===0){setTimeout(function(){if(c.ui.dialog.overlay.instances.length){c(document).bind(c.ui.dialog.overlay.events,function(f){var g=c(f.target).parents(".ui-dialog").css("zIndex")||0;return(g>c.ui.dialog.overlay.maxZ)})}},1);c(document).bind("keydown.dialog-overlay",function(f){(e.options.closeOnEscape&&f.keyCode&&f.keyCode==c.ui.keyCode.ESCAPE&&e.close(f))});c(window).bind("resize.dialog-overlay",c.ui.dialog.overlay.resize)}var d=c("<div></div>").appendTo(document.body).addClass("ui-widget-overlay").css({width:this.width(),height:this.height()});(e.options.bgiframe&&c.fn.bgiframe&&d.bgiframe());this.instances.push(d);return d},destroy:function(d){this.instances.splice(c.inArray(this.instances,d),1);if(this.instances.length===0){c([document,window]).unbind(".dialog-overlay")}d.remove();var e=0;c.each(this.instances,function(){e=Math.max(e,this.css("z-index"))});this.maxZ=e},height:function(){if(c.browser.msie&&c.browser.version<7){var e=Math.max(document.documentElement.scrollHeight,document.body.scrollHeight);var d=Math.max(document.documentElement.offsetHeight,document.body.offsetHeight);if(e<d){return c(window).height()+"px"}else{return e+"px"}}else{return c(document).height()+"px"}},width:function(){if(c.browser.msie&&c.browser.version<7){var d=Math.max(document.documentElement.scrollWidth,document.body.scrollWidth);var e=Math.max(document.documentElement.offsetWidth,document.body.offsetWidth);if(d<e){return c(window).width()+"px"}else{return d+"px"}}else{return c(document).width()+"px"}},resize:function(){var d=c([]);c.each(c.ui.dialog.overlay.instances,function(){d=d.add(this)});d.css({width:0,height:0}).css({width:c.ui.dialog.overlay.width(),height:c.ui.dialog.overlay.height()})}});c.extend(c.ui.dialog.overlay.prototype,{destroy:function(){c.ui.dialog.overlay.destroy(this.$el)}})})(jQuery);;/*! Copyright (c) 2008 Brandon Aaron (http://brandonaaron.net)
* Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
* and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
* Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
* Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
*
* Version: 3.0.1-pre
*
* Requires: 1.2.2+
*/
 
(function($) {
 
$.event.special.mousewheel = {
  setup: function() {
    var handler = $.event.special.mousewheel.handler;
    
    // Fix pageX, pageY, clientX and clientY for mozilla
    if ( $.browser.mozilla )
      $(this).bind('mousemove.mousewheel', function(event) {
        $.data(this, 'mwcursorposdata', {
          pageX: event.pageX,
          pageY: event.pageY,
          clientX: event.clientX,
          clientY: event.clientY
        });
      });
  
    if ( this.addEventListener )
      this.addEventListener( ($.browser.mozilla ? 'DOMMouseScroll' : 'mousewheel'), handler, false);
    else
      this.onmousewheel = handler;
  },
  
  teardown: function() {
    var handler = $.event.special.mousewheel.handler;
    
    $(this).unbind('mousemove.mousewheel');
    
    if ( this.removeEventListener )
      this.removeEventListener( ($.browser.mozilla ? 'DOMMouseScroll' : 'mousewheel'), handler, false);
    else
      this.onmousewheel = function(){};
    
    $.removeData(this, 'mwcursorposdata');
  },
  
  handler: function(event) {
    var args = Array.prototype.slice.call( arguments, 1 );
    
    event = $.event.fix(event || window.event);
    // Get correct pageX, pageY, clientX and clientY for mozilla
    $.extend( event, $.data(this, 'mwcursorposdata') || {} );
    var delta = 0, returnValue = true;
    
    if ( event.wheelDelta ) delta = event.wheelDelta/120;
    if ( event.detail ) delta = -event.detail/3;
    if ( $.browser.opera ) delta = -event.wheelDelta;
    
    event.data = event.data || {};
    event.type = "mousewheel";
    
    // Add delta to the front of the arguments
    args.unshift(delta);
    // Add event to the front of the arguments
    args.unshift(event);
 
    return $.event.handle.apply(this, args);
  }
};
 
$.fn.extend({
  mousewheel: function(fn) {
    return fn ? this.bind("mousewheel", fn) : this.trigger("mousewheel");
  },
  
  unmousewheel: function(fn) {
    return this.unbind("mousewheel", fn);
  }
});
 
})(jQuery);
/** 
 * DbMAP JS - Version 1.8 	  			
 */
	  		/* This notice must be untouched at all times.

wz_jsgraphics.js    v. 3.05
The latest version is available at
http://www.walterzorn.com
or http://www.devira.com
or http://www.walterzorn.de

Copyright (c) 2002-2009 Walter Zorn. All rights reserved.
Created 3. 11. 2002 by Walter Zorn (Web: http://www.walterzorn.com )
Last modified: 2. 2. 2009

Performance optimizations for Internet Explorer
by Thomas Frank and John Holdsworth.
fillPolygon method implemented by Matthieu Haller.

High Performance JavaScript Graphics Library.
Provides methods
- to draw lines, rectangles, ellipses, polygons
	with specifiable line thickness,
- to fill rectangles, polygons, ellipses and arcs
- to draw text.
NOTE: Operations, functions and branching have rather been optimized
to efficiency and speed than to shortness of source code.

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/


var jg_ok, jg_ie, jg_fast, jg_dom, jg_moz, jg_zIndex;


function _chkDHTM(wnd, x, i)
// Under XUL, owner of 'document' must be specified explicitly
{
	x = wnd.document.body || null;
	jg_ie = x && typeof x.insertAdjacentHTML != "undefined" && wnd.document.createElement;
	jg_dom = (x && !jg_ie &&
		typeof x.appendChild != "undefined" &&
		typeof wnd.document.createRange != "undefined" &&
		typeof (i = wnd.document.createRange()).setStartBefore != "undefined" &&
		typeof i.createContextualFragment != "undefined");
	jg_fast = jg_ie && wnd.document.all && !wnd.opera;
	jg_moz = jg_dom && typeof x.style.MozOpacity != "undefined";
	jg_ok = !!(jg_ie || jg_dom);
}

function _pntCnvDom()
{
	var x = this.wnd.document.createRange();
	x.setStartBefore(this.cnv);
	x = x.createContextualFragment(jg_fast? this._htmRpc() : this.htm);
	if(this.cnv) this.cnv.appendChild(x);
	this.htm = "";
}

function _pntCnvIe()
{
	if(this.cnv) this.cnv.insertAdjacentHTML("BeforeEnd", jg_fast? this._htmRpc() : this.htm);
	this.htm = "";
}

function _pntDoc()
{
	this.wnd.document.write(jg_fast? this._htmRpc() : this.htm);
	this.htm = '';
}

function _pntN()
{
	;
}

function _mkDiv(x, y, w, h)
{
	this.htm += '<div style="position:absolute;'+
		'left:' + x + 'px;'+
		'top:' + y + 'px;'+
		'width:' + w + 'px;'+
		'height:' + h + 'px;'+
		'clip:rect(0,'+w+'px,'+h+'px,0);'+
		'background-color:' + this.color +
		(!jg_moz? ';overflow:hidden' : '')+
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '')+
		';"><\/div>';
}

function _mkDivIe(x, y, w, h)
{
	this.htm += '%%'+this.color+';'+x+';'+y+';'+w+';'+h+';';
}

function _mkDivPrt(x, y, w, h)
{
	this.htm += '<div style="position:absolute;'+
		'border-left:' + w + 'px solid ' + this.color + ';'+
		'left:' + x + 'px;'+
		'top:' + y + 'px;'+
		'width:0px;'+
		'height:' + h + 'px;'+
		'clip:rect(0,'+w+'px,'+h+'px,0);'+
		'background-color:' + this.color +
		(!jg_moz? ';overflow:hidden' : '')+
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';"><\/div>';
}

var _regex =  /%%([^;]+);([^;]+);([^;]+);([^;]+);([^;]+);/g;
function _htmRpc()
{
	return this.htm.replace(
		_regex,
		'<div style="overflow:hidden;position:absolute' + 
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';background-color:$1;left:$2px;top:$3px;width:$4px;height:$5px"></div>\n');
}

function _htmPrtRpc()
{
	return this.htm.replace(
		_regex,
		'<div style="overflow:hidden;position:absolute' + 
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';background-color:$1;left:$2px;top:$3px;width:$4px;height:$5px;border-left:$4px solid $1"></div>\n');
}

function _mkLin(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1;

	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx,
		ox = x;
		while(dx > 0)
		{--dx;
			++x;
			if(p > 0)
			{
				this._mkDiv(ox, y, x-ox, 1);
				y += yIncr;
				p += pru;
				ox = x;
			}
			else p += pr;
		}
		this._mkDiv(ox, y, x2-ox+1, 1);
	}

	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy,
		oy = y;
		if(y2 <= y1)
		{
			while(dy > 0)
			{--dy;
				if(p > 0)
				{
					this._mkDiv(x++, y, 1, oy-y+1);
					y += yIncr;
					p += pru;
					oy = y;
				}
				else
				{
					y += yIncr;
					p += pr;
				}
			}
			this._mkDiv(x2, y2, 1, oy-y2+1);
		}
		else
		{
			while(dy > 0)
			{--dy;
				y += yIncr;
				if(p > 0)
				{
					this._mkDiv(x++, oy, 1, y-oy);
					p += pru;
					oy = y;
				}
				else p += pr;
			}
			this._mkDiv(x2, oy, 1, y2-oy+1);
		}
	}
}

function _mkLin2D(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1;

	var s = this.stroke;
	if(dx >= dy)
	{
		if(dx > 0 && s-3 > 0)
		{
			var _s = (s*dx*Math.sqrt(1+dy*dy/(dx*dx))-dx-(s>>1)*dy) / dx;
			_s = (!(s-4)? Math.ceil(_s) : Math.round(_s)) + 1;
		}
		else var _s = s;
		var ad = Math.ceil(s/2);

		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx,
		ox = x;
		while(dx > 0)
		{--dx;
			++x;
			if(p > 0)
			{
				this._mkDiv(ox, y, x-ox+ad, _s);
				y += yIncr;
				p += pru;
				ox = x;
			}
			else p += pr;
		}
		this._mkDiv(ox, y, x2-ox+ad+1, _s);
	}

	else
	{
		if(s-3 > 0)
		{
			var _s = (s*dy*Math.sqrt(1+dx*dx/(dy*dy))-(s>>1)*dx-dy) / dy;
			_s = (!(s-4)? Math.ceil(_s) : Math.round(_s)) + 1;
		}
		else var _s = s;
		var ad = Math.round(s/2);

		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy,
		oy = y;
		if(y2 <= y1)
		{
			++ad;
			while(dy > 0)
			{--dy;
				if(p > 0)
				{
					this._mkDiv(x++, y, _s, oy-y+ad);
					y += yIncr;
					p += pru;
					oy = y;
				}
				else
				{
					y += yIncr;
					p += pr;
				}
			}
			this._mkDiv(x2, y2, _s, oy-y2+ad);
		}
		else
		{
			while(dy > 0)
			{--dy;
				y += yIncr;
				if(p > 0)
				{
					this._mkDiv(x++, oy, _s, y-oy+ad);
					p += pru;
					oy = y;
				}
				else p += pr;
			}
			this._mkDiv(x2, oy, _s, y2-oy+ad+1);
		}
	}
}

function _mkLinDott(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1,
	drw = true;
	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx;
		while(dx > 0)
		{--dx;
			if(drw) this._mkDiv(x, y, 1, 1);
			drw = !drw;
			if(p > 0)
			{
				y += yIncr;
				p += pru;
			}
			else p += pr;
			++x;
		}
	}
	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy;
		while(dy > 0)
		{--dy;
			if(drw) this._mkDiv(x, y, 1, 1);
			drw = !drw;
			y += yIncr;
			if(p > 0)
			{
				++x;
				p += pru;
			}
			else p += pr;
		}
	}
	if(drw) this._mkDiv(x, y, 1, 1);
}

function _mkOv(left, top, width, height)
{
	var a = (++width)>>1, b = (++height)>>1,
	wod = width&1, hod = height&1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	ox = 0, oy = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1),
	w, h;
	while(y > 0)
	{
		if(st < 0)
		{
			st += bb2*((x<<1)+3);
			tt += bb4*(++x);
		}
		else if(tt < 0)
		{
			st += bb2*((x<<1)+3) - aa4*(y-1);
			tt += bb4*(++x) - aa2*(((y--)<<1)-3);
			w = x-ox;
			h = oy-y;
			if((w&2) && (h&2))
			{
				this._mkOvQds(cx, cy, x-2, y+2, 1, 1, wod, hod);
				this._mkOvQds(cx, cy, x-1, y+1, 1, 1, wod, hod);
			}
			else this._mkOvQds(cx, cy, x-1, oy, w, h, wod, hod);
			ox = x;
			oy = y;
		}
		else
		{
			tt -= aa2*((y<<1)-3);
			st -= aa4*(--y);
		}
	}
	w = a-ox+1;
	h = (oy<<1)+hod;
	y = cy-oy;
	this._mkDiv(cx-a, y, w, h);
	this._mkDiv(cx+ox+wod-1, y, w, h);
}

function _mkOv2D(left, top, width, height)
{
	var s = this.stroke;
	width += s+1;
	height += s+1;
	var a = width>>1, b = height>>1,
	wod = width&1, hod = height&1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1);

	if(s-4 < 0 && (!(s-2) || width-51 > 0 && height-51 > 0))
	{
		var ox = 0, oy = b,
		w, h,
		pxw;
		while(y > 0)
		{
			if(st < 0)
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				w = x-ox;
				h = oy-y;

				if(w-1)
				{
					pxw = w+1+(s&1);
					h = s;
				}
				else if(h-1)
				{
					pxw = s;
					h += 1+(s&1);
				}
				else pxw = h = s;
				this._mkOvQds(cx, cy, x-1, oy, pxw, h, wod, hod);
				ox = x;
				oy = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}
		}
		this._mkDiv(cx-a, cy-oy, s, (oy<<1)+hod);
		this._mkDiv(cx+a+wod-s, cy-oy, s, (oy<<1)+hod);
	}

	else
	{
		var _a = (width-(s<<1))>>1,
		_b = (height-(s<<1))>>1,
		_x = 0, _y = _b,
		_aa2 = (_a*_a)<<1, _aa4 = _aa2<<1, _bb2 = (_b*_b)<<1, _bb4 = _bb2<<1,
		_st = (_aa2>>1)*(1-(_b<<1)) + _bb2,
		_tt = (_bb2>>1) - _aa2*((_b<<1)-1),

		pxl = new Array(),
		pxt = new Array(),
		_pxb = new Array();
		pxl[0] = 0;
		pxt[0] = b;
		_pxb[0] = _b-1;
		while(y > 0)
		{
			if(st < 0)
			{
				pxl[pxl.length] = x;
				pxt[pxt.length] = y;
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				pxl[pxl.length] = x;
				st += bb2*((x<<1)+3) - aa4*(y-1);
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				pxt[pxt.length] = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}

			if(_y > 0)
			{
				if(_st < 0)
				{
					_st += _bb2*((_x<<1)+3);
					_tt += _bb4*(++_x);
					_pxb[_pxb.length] = _y-1;
				}
				else if(_tt < 0)
				{
					_st += _bb2*((_x<<1)+3) - _aa4*(_y-1);
					_tt += _bb4*(++_x) - _aa2*(((_y--)<<1)-3);
					_pxb[_pxb.length] = _y-1;
				}
				else
				{
					_tt -= _aa2*((_y<<1)-3);
					_st -= _aa4*(--_y);
					_pxb[_pxb.length-1]--;
				}
			}
		}

		var ox = -wod, oy = b,
		_oy = _pxb[0],
		l = pxl.length,
		w, h;
		for(var i = 0; i < l; i++)
		{
			if(typeof _pxb[i] != "undefined")
			{
				if(_pxb[i] < _oy || pxt[i] < oy)
				{
					x = pxl[i];
					this._mkOvQds(cx, cy, x, oy, x-ox, oy-_oy, wod, hod);
					ox = x;
					oy = pxt[i];
					_oy = _pxb[i];
				}
			}
			else
			{
				x = pxl[i];
				this._mkDiv(cx-x, cy-oy, 1, (oy<<1)+hod);
				this._mkDiv(cx+ox+wod, cy-oy, 1, (oy<<1)+hod);
				ox = x;
				oy = pxt[i];
			}
		}
		this._mkDiv(cx-a, cy-oy, 1, (oy<<1)+hod);
		this._mkDiv(cx+ox+wod, cy-oy, 1, (oy<<1)+hod);
	}
}

function _mkOvDott(left, top, width, height)
{
	var a = (++width)>>1, b = (++height)>>1,
	wod = width&1, hod = height&1, hodu = hod^1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1),
	drw = true;
	while(y > 0)
	{
		if(st < 0)
		{
			st += bb2*((x<<1)+3);
			tt += bb4*(++x);
		}
		else if(tt < 0)
		{
			st += bb2*((x<<1)+3) - aa4*(y-1);
			tt += bb4*(++x) - aa2*(((y--)<<1)-3);
		}
		else
		{
			tt -= aa2*((y<<1)-3);
			st -= aa4*(--y);
		}
		if(drw && y >= hodu) this._mkOvQds(cx, cy, x, y, 1, 1, wod, hod);
		drw = !drw;
	}
}

function _mkRect(x, y, w, h)
{
	var s = this.stroke;
	this._mkDiv(x, y, w, s);
	this._mkDiv(x+w, y, s, h);
	this._mkDiv(x, y+h, w+s, s);
	this._mkDiv(x, y+s, s, h-s);
}

function _mkRectDott(x, y, w, h)
{
	this.drawLine(x, y, x+w, y);
	this.drawLine(x+w, y, x+w, y+h);
	this.drawLine(x, y+h, x+w, y+h);
	this.drawLine(x, y, x, y+h);
}

function jsgFont()
{
	this.PLAIN = 'font-weight:normal;';
	this.BOLD = 'font-weight:bold;';
	this.ITALIC = 'font-style:italic;';
	this.ITALIC_BOLD = this.ITALIC + this.BOLD;
	this.BOLD_ITALIC = this.ITALIC_BOLD;
}
var Font = new jsgFont();

function jsgStroke()
{
	this.DOTTED = -1;
}
var Stroke = new jsgStroke();

function jsGraphics(cnv, wnd)
{
	this.setColor = function(x)
	{
		this.color = x.toLowerCase();
	};

	this.setStroke = function(x)
	{
		this.stroke = x;
		if(!(x+1))
		{
			this.drawLine = _mkLinDott;
			this._mkOv = _mkOvDott;
			this.drawRect = _mkRectDott;
		}
		else if(x-1 > 0)
		{
			this.drawLine = _mkLin2D;
			this._mkOv = _mkOv2D;
			this.drawRect = _mkRect;
		}
		else
		{
			this.drawLine = _mkLin;
			this._mkOv = _mkOv;
			this.drawRect = _mkRect;
		}
	};

	this.setPrintable = function(arg)
	{
		this.printable = arg;
		if(jg_fast)
		{
			this._mkDiv = _mkDivIe;
			this._htmRpc = arg? _htmPrtRpc : _htmRpc;
		}
		else this._mkDiv = arg? _mkDivPrt : _mkDiv;
	};

	this.setFont = function(fam, sz, sty)
	{
		this.ftFam = fam;
		this.ftSz = sz;
		this.ftSty = sty || Font.PLAIN;
	};

	this.drawPolyline = this.drawPolyLine = function(x, y)
	{
		for (var i=x.length - 1; i;)
		{--i;
			this.drawLine(x[i], y[i], x[i+1], y[i+1]);
		}
	};

	this.fillRect = function(x, y, w, h)
	{
		this._mkDiv(x, y, w, h);
	};

	this.drawPolygon = function(x, y)
	{
		this.drawPolyline(x, y);
		this.drawLine(x[x.length-1], y[x.length-1], x[0], y[0]);
	};

	this.drawEllipse = this.drawOval = function(x, y, w, h)
	{
		this._mkOv(x, y, w, h);
	};

	this.fillEllipse = this.fillOval = function(left, top, w, h)
	{
		var a = w>>1, b = h>>1,
		wod = w&1, hod = h&1,
		cx = left+a, cy = top+b,
		x = 0, y = b, oy = b,
		aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
		st = (aa2>>1)*(1-(b<<1)) + bb2,
		tt = (bb2>>1) - aa2*((b<<1)-1),
		xl, dw, dh;
		if(w) while(y > 0)
		{
			if(st < 0)
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				xl = cx-x;
				dw = (x<<1)+wod;
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				dh = oy-y;
				this._mkDiv(xl, cy-oy, dw, dh);
				this._mkDiv(xl, cy+y+hod, dw, dh);
				oy = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}
		}
		this._mkDiv(cx-a, cy-oy, w, (oy<<1)+hod);
	};

	this.fillArc = function(iL, iT, iW, iH, fAngA, fAngZ)
	{
		var a = iW>>1, b = iH>>1,
		iOdds = (iW&1) | ((iH&1) << 16),
		cx = iL+a, cy = iT+b,
		x = 0, y = b, ox = x, oy = y,
		aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
		st = (aa2>>1)*(1-(b<<1)) + bb2,
		tt = (bb2>>1) - aa2*((b<<1)-1),
		// Vars for radial boundary lines
		xEndA, yEndA, xEndZ, yEndZ,
		iSects = (1 << (Math.floor((fAngA %= 360.0)/180.0) << 3))
				| (2 << (Math.floor((fAngZ %= 360.0)/180.0) << 3))
				| ((fAngA >= fAngZ) << 16),
		aBndA = new Array(b+1), aBndZ = new Array(b+1);
		
		// Set up radial boundary lines
		fAngA *= Math.PI/180.0;
		fAngZ *= Math.PI/180.0;
		xEndA = cx+Math.round(a*Math.cos(fAngA));
		yEndA = cy+Math.round(-b*Math.sin(fAngA));
		_mkLinVirt(aBndA, cx, cy, xEndA, yEndA);
		xEndZ = cx+Math.round(a*Math.cos(fAngZ));
		yEndZ = cy+Math.round(-b*Math.sin(fAngZ));
		_mkLinVirt(aBndZ, cx, cy, xEndZ, yEndZ);

		while(y > 0)
		{
			if(st < 0) // Advance x
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0) // Advance x and y
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				ox = x;
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				this._mkArcDiv(ox, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
				oy = y;
			}
			else // Advance y
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
				if(y && (aBndA[y] != aBndA[y-1] || aBndZ[y] != aBndZ[y-1]))
				{
					this._mkArcDiv(x, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
					ox = x;
					oy = y;
				}
			}
		}
		this._mkArcDiv(x, 0, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
		if(iOdds >> 16) // Odd height
		{
			if(iSects >> 16) // Start-angle > end-angle
			{
				var xl = (yEndA <= cy || yEndZ > cy)? (cx - x) : cx;
				this._mkDiv(xl, cy, x + cx - xl + (iOdds & 0xffff), 1);
			}
			else if((iSects & 0x01) && yEndZ > cy)
				this._mkDiv(cx - x, cy, x, 1);
		}
	};

/* fillPolygon method, implemented by Matthieu Haller.
This javascript function is an adaptation of the gdImageFilledPolygon for Walter Zorn lib.
C source of GD 1.8.4 found at http://www.boutell.com/gd/

THANKS to Kirsten Schulz for the polygon fixes!

The intersection finding technique of this code could be improved
by remembering the previous intertersection, and by using the slope.
That could help to adjust intersections to produce a nice
interior_extrema. */
	this.fillPolygon = function(array_x, array_y)
	{
		var i;
		var y;
		var miny, maxy;
		var x1, y1;
		var x2, y2;
		var ind1, ind2;
		var ints;

		var n = array_x.length;
		if(!n) return;

		miny = array_y[0];
		maxy = array_y[0];
		for(i = 1; i < n; i++)
		{
			if(array_y[i] < miny)
				miny = array_y[i];

			if(array_y[i] > maxy)
				maxy = array_y[i];
		}
		for(y = miny; y <= maxy; y++)
		{
			var polyInts = new Array();
			ints = 0;
			for(i = 0; i < n; i++)
			{
				if(!i)
				{
					ind1 = n-1;
					ind2 = 0;
				}
				else
				{
					ind1 = i-1;
					ind2 = i;
				}
				y1 = array_y[ind1];
				y2 = array_y[ind2];
				if(y1 < y2)
				{
					x1 = array_x[ind1];
					x2 = array_x[ind2];
				}
				else if(y1 > y2)
				{
					y2 = array_y[ind1];
					y1 = array_y[ind2];
					x2 = array_x[ind1];
					x1 = array_x[ind2];
				}
				else continue;

				 //  Modified 11. 2. 2004 Walter Zorn
				if((y >= y1) && (y < y2))
					polyInts[ints++] = Math.round((y-y1) * (x2-x1) / (y2-y1) + x1);

				else if((y == maxy) && (y > y1) && (y <= y2))
					polyInts[ints++] = Math.round((y-y1) * (x2-x1) / (y2-y1) + x1);
			}
			polyInts.sort(_CompInt);
			for(i = 0; i < ints; i+=2)
				this._mkDiv(polyInts[i], y, polyInts[i+1]-polyInts[i]+1, 1);
		}
	};

	this.drawString = function(txt, x, y)
	{
		this.htm += '<div style="position:absolute;white-space:nowrap;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			'font-family:' +  this.ftFam + ';'+
			'font-size:' + this.ftSz + ';'+
			'color:' + this.color + ';' + this.ftSty + '">'+
			txt +
			'<\/div>';
	};

/* drawStringRect() added by Rick Blommers.
Allows to specify the size of the text rectangle and to align the
text both horizontally (e.g. right) and vertically within that rectangle */
	this.drawStringRect = function(txt, x, y, width, halign)
	{
		this.htm += '<div style="position:absolute;overflow:hidden;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			'width:'+width +'px;'+
			'text-align:'+halign+';'+
			'font-family:' +  this.ftFam + ';'+
			'font-size:' + this.ftSz + ';'+
			'color:' + this.color + ';' + this.ftSty + '">'+
			txt +
			'<\/div>';
	};

	this.drawImage = function(imgSrc, x, y, w, h, a)
	{
		this.htm += '<div style="position:absolute;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			// w (width) and h (height) arguments are now optional.
			// Added by Mahmut Keygubatli, 14.1.2008
			(w? ('width:' +  w + 'px;') : '') +
			(h? ('height:' + h + 'px;'):'')+'">'+
			'<img src="' + imgSrc +'"'+ (w ? (' width="' + w + '"'):'')+ (h ? (' height="' + h + '"'):'') + (a? (' '+a) : '') + '>'+
			'<\/div>';
	};

	this.clear = function()
	{
		this.htm = "";
		if(this.cnv) this.cnv.innerHTML = "";
	};

	this._mkOvQds = function(cx, cy, x, y, w, h, wod, hod)
	{
		var xl = cx - x, xr = cx + x + wod - w, yt = cy - y, yb = cy + y + hod - h;
		if(xr > xl+w)
		{
			this._mkDiv(xr, yt, w, h);
			this._mkDiv(xr, yb, w, h);
		}
		else
			w = xr - xl + w;
		this._mkDiv(xl, yt, w, h);
		this._mkDiv(xl, yb, w, h);
	};
	
	this._mkArcDiv = function(x, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects)
	{
		var xrDef = cx + x + (iOdds & 0xffff), y2, h = oy - y, xl, xr, w;

		if(!h) h = 1;
		x = cx - x;

		if(iSects & 0xff0000) // Start-angle > end-angle
		{
			y2 = cy - y - h;
			if(iSects & 0x00ff)
			{
				if(iSects & 0x02)
				{
					xl = Math.max(x, aBndZ[y]);
					w = xrDef - xl;
					if(w > 0) this._mkDiv(xl, y2, w, h);
				}
				if(iSects & 0x01)
				{
					xr = Math.min(xrDef, aBndA[y]);
					w = xr - x;
					if(w > 0) this._mkDiv(x, y2, w, h);
				}
			}
			else
				this._mkDiv(x, y2, xrDef - x, h);
			y2 = cy + y + (iOdds >> 16);
			if(iSects & 0xff00)
			{
				if(iSects & 0x0100)
				{
					xl = Math.max(x, aBndA[y]);
					w = xrDef - xl;
					if(w > 0) this._mkDiv(xl, y2, w, h);
				}
				if(iSects & 0x0200)
				{
					xr = Math.min(xrDef, aBndZ[y]);
					w = xr - x;
					if(w > 0) this._mkDiv(x, y2, w, h);
				}
			}
			else
				this._mkDiv(x, y2, xrDef - x, h);
		}
		else
		{
			if(iSects & 0x00ff)
			{
				if(iSects & 0x02)
					xl = Math.max(x, aBndZ[y]);
				else
					xl = x;
				if(iSects & 0x01)
					xr = Math.min(xrDef, aBndA[y]);
				else
					xr = xrDef;
				y2 = cy - y - h;
				w = xr - xl;
				if(w > 0) this._mkDiv(xl, y2, w, h);
			}
			if(iSects & 0xff00)
			{
				if(iSects & 0x0100)
					xl = Math.max(x, aBndA[y]);
				else
					xl = x;
				if(iSects & 0x0200)
					xr = Math.min(xrDef, aBndZ[y]);
				else
					xr = xrDef;
				y2 = cy + y + (iOdds >> 16);
				w = xr - xl;
				if(w > 0) this._mkDiv(xl, y2, w, h);
			}
		}
	};

	this.setStroke(1);
	this.setFont("verdana,geneva,helvetica,sans-serif", "12px", Font.PLAIN);
	this.color = "#000000";
	this.htm = "";
	this.wnd = wnd || window;

	if(!jg_ok) _chkDHTM(this.wnd);
	if(jg_ok)
	{
		if(cnv)
		{
			if(typeof(cnv) == "string")
				this.cont = document.all? (this.wnd.document.all[cnv] || null)
					: document.getElementById? (this.wnd.document.getElementById(cnv) || null)
					: null;
			else if(cnv == window.document)
				this.cont = document.getElementsByTagName("body")[0];
			// If cnv is a direct reference to a canvas DOM node
			// (option suggested by Andreas Luleich)
			else this.cont = cnv;
			// Create new canvas inside container DIV. Thus the drawing and clearing
			// methods won't interfere with the container's inner html.
			// Solution suggested by Vladimir.
			this.cnv = this.wnd.document.createElement("div");
			this.cnv.style.fontSize=0;
			this.cont.appendChild(this.cnv);
			this.paint = jg_dom? _pntCnvDom : _pntCnvIe;
		}
		else
			this.paint = _pntDoc;
	}
	else
		this.paint = _pntN;

	this.setPrintable(false);
}

function _mkLinVirt(aLin, x1, y1, x2, y2)
{
	var dx = Math.abs(x2-x1), dy = Math.abs(y2-y1),
	x = x1, y = y1,
	xIncr = (x1 > x2)? -1 : 1,
	yIncr = (y1 > y2)? -1 : 1,
	p,
	i = 0;
	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1);
		p = pr-dx;
		while(dx > 0)
		{--dx;
			if(p > 0)    //  Increment y
			{
				aLin[i++] = x;
				y += yIncr;
				p += pru;
			}
			else p += pr;
			x += xIncr;
		}
	}
	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1);
		p = pr-dy;
		while(dy > 0)
		{--dy;
			y += yIncr;
			aLin[i++] = x;
			if(p > 0)    //  Increment x
			{
				x += xIncr;
				p += pru;
			}
			else p += pr;
		}
	}
	for(var len = aLin.length, i = len-i; i;)
		aLin[len-(i--)] = x;
};

function _CompInt(x, y)
{
	return(x - y);
}

/**
 * @class Bounding Box
 * 
 * @param mapCoordinates Bounding Box iniziale { xmin: ..., ymin: ..., xmax: ..., ymax: ... }
 */
function BBox(mapCoordinates) {
	this.xmin = null;
	this.ymin =	null;
	this.xmax =	null;
	this.ymax = null;
	
	if (mapCoordinates != null) {
		this.xmin = mapCoordinates.xmin;
		this.ymin =	mapCoordinates.ymin;
		this.xmax =	mapCoordinates.xmax;
		this.ymax = mapCoordinates.ymax;
	}
}

/**
 * Calcola se il punto passato &egrave; contenuto nel Bounding Box
 */
BBox.prototype.containsPoint = function(x, y) {
	return this.xmin <= x && this.xmax >= x && 
		this.ymin <= y && this.ymax >= y;
}

/**
 * Restituisce le coordinate del Bounding Box
 */
BBox.prototype.getCoordinates = function() {
	return { xmin: this.xmin, ymin: this.ymin, xmax: this.xmax, ymax: this.ymax };
}

/**
 * Controlla l'equivalenza con il Bounding Box passato 
 */
BBox.prototype.equals = function(otherBBox) {
	if (otherBBox == null) return false;
	
	return this.xmin == otherBBox.xmin &&
		this.xmax == otherBBox.xmax &&
		this.ymin == otherBBox.ymin &&
		this.ymax == otherBBox.ymax;
}
/**
 * @class Marker
 * 
 * @param node elemento da inserire
 * @param offsetTop offset da usare nella coordinata top
 * @param offsetLeft offset da usare nella coordinata left
 * @param id identificativo univoco
 * @param x coordinata x sulla mappa
 * @param y coordinata y sulla mappa
 */
function Marker(node, offsetTop, offsetLeft, id, x, y, insertEvenIfOffScreen) {
	this.node = $(node);
	this.offsetTop = offsetTop;
	this.offsetLeft = offsetLeft;
	this.id = id;	
	this.x = x;
	this.y = y;
	this.insertEvenIfOffScreen = insertEvenIfOffScreen;
}

/**
 *
 */
Marker.prototype.clone = function() {
	return new Marker(this.node, this.offsetTop, this.offsetLeft, this.id, this.x, this.y, this.insertEvenIfOffScreen);
}

function Tile(x, y, z, bbox, screenPosition) {
	this.x = x;
	this.y = y;
	this.z = z;
	this.bbox = bbox;
	this.screenPosition = screenPosition;
}

Tile.prototype.equals = function(otherTile) {
	if (otherTile == null) return false;
	
	return this.x == otherTile.x &&
		this.y == otherTile.y &&
		this.z == otherTile.z;
};

function MapGrid(tileSize, unitsPerPixelOnZoomZero, maxZ, offset) {
	this.unitsPerPixelOnZoomZero = unitsPerPixelOnZoomZero;
	this.unitsPerPixel = unitsPerPixelOnZoomZero;
	this.z = 0;
	this.maxZ = maxZ;
	
	this.referenceSystemIsLatLon = false;
	
	this.tileSizeOnScreen = tileSize;
	this.tileSizeOnMap = null;
	
	// deprecated
	this.pixelValue = null;
	
	this.currentView = null;
	
	this.gridStartPointOnMap = null;
	this.grid = null;
	this.xNumTiles = null;
	this.yNumTiles = null;
	
	this.screenHeight = null;
	this.screenWidth = null;
	
	this.dpi = null;
	// 1 inch = 2.54 centimeters
	this.cmInInch = 2.54;	
	
	this.offset = offset != null ? offset : { x: 0, y: 0 };
}

MapGrid.prototype.calculateDPI = function() {
	var node = document.getElementById('dbmap_dpi');
	
	if (node == null) {
		node = $('<div />')
			.attr('id', 'dbmap_dpi')
			.css({ height: '1in', width: '1in', position: 'absolute', left: '-100%', top: '-100%' });
  		$(document.body).append(node);
  		node = document.getElementById('dbmap_dpi');
	}
  
  	return node.offsetHeight;
}

MapGrid.prototype.getScale = function() {
	if (this.dpi == null) {
		this.dpi = this.calculateDPI();
	}
	
	var pixelPerCm = this.dpi / this.cmInInch;
	
	if (this.referenceSystemIsLatLon) {
		var degreeToMeter = 111319;
		var cmPerPixel = this.unitsPerPixel * degreeToMeter * 100 * pixelPerCm;
		return Math.round(cmPerPixel);
	} else {
		var cmPerPixel = this.unitsPerPixel * 100 * pixelPerCm;
		return Math.round(cmPerPixel);
	}
}

MapGrid.prototype.getZoomLevel = function() {
	return this.z;
}

MapGrid.prototype.zoomToLevel = function(newZ) {
	if (newZ < 0) newZ = 0;
	if (newZ > this.maxZ) newZ = this.maxZ;
	
	this.z = newZ;
	this.onZoomChanged();
	return true;
}

MapGrid.prototype.zoomIn = function() {
	if (this.maxZ > this.z) {
		this.z++;
		this.onZoomChanged();
		return true;
	} else {
		return false;
	}
}

MapGrid.prototype.zoomOut = function() {
	if (this.z > 0) {
		this.z--;
		this.onZoomChanged();
		return true;
	} else {
		return false;
	}
}

MapGrid.prototype.onZoomChanged = function() {
	this.unitsPerPixel = this.unitsPerPixelOnZoomZero / Math.pow(2, this.z);
	
	this.tileSizeOnMap = this.tileSizeOnScreen * this.unitsPerPixel;
	this.pixelValue = 1 / this.unitsPerPixel;
		
	this.gridStartPointOnMap = { x: 0, y: 0 };
	
	var newXmax = this.currentView.xmin + this.screenWidth * this.unitsPerPixel;
	var newYmax = this.currentView.ymin + this.screenHeight * this.unitsPerPixel;
	var xOffset = ((this.currentView.xmax - this.currentView.xmin) - (newXmax - this.currentView.xmin)) / 2;
	var yOffset = ((this.currentView.ymax - this.currentView.ymin) - (newYmax - this.currentView.ymin)) / 2;

	var bbox = { xmin: this.currentView.xmin + xOffset, ymin: this.currentView.ymin + yOffset,
		xmax: this.currentView.xmax - xOffset, ymax: this.currentView.ymax - yOffset }; 	

	this.currentView = new BBox(bbox);
	
	this.reloadGrid();
}

MapGrid.prototype.resize = function(newScreenWidth, newScreenHeight) {
	if (this.currentView != null) {
		this.init(this.currentView.getCoordinates(), newScreenWidth, newScreenHeight);
	}
}

MapGrid.prototype.zoomToWindow = function(view) {
	var xMapSize = view.xmax - view.xmin;
	var yMapSize = view.ymax - view.ymin;

	var xUnitsPerPixel = xMapSize / this.screenWidth;
	var yUnitsPerPixel = yMapSize / this.screenHeight;

	var xLevel = Math.log(this.unitsPerPixelOnZoomZero / xUnitsPerPixel) / Math.log(2);
	var yLevel = Math.log(this.unitsPerPixelOnZoomZero / yUnitsPerPixel) / Math.log(2);

	this.zoomToLevel(Math.floor(Math.min(xLevel, yLevel)));
	this.pan(view);
}

MapGrid.prototype.panToPoint = function(x, y) {
	var xOffset = this.screenWidth  * this.unitsPerPixel / 2;
	var yOffset = this.screenHeight * this.unitsPerPixel / 2;	
	
	var newBBox = new BBox({ 
		xmin: x - xOffset, ymin: y - yOffset,
		xmax: x + xOffset, ymax: y + yOffset });

	if (this.currentView == null || !this.currentView.equals(newBBox)) {
		this.currentView = newBBox;
		this.reloadGrid();
	}	
}

MapGrid.prototype.pan = function(newView) {
	this.panToPoint(
		newView.xmin + (newView.xmax - newView.xmin) / 2, 
		newView.ymin + (newView.ymax - newView.ymin) / 2);
}

MapGrid.prototype.init = function(newView, newScreenWidth, newScreenHeight) {
	this.unitsPerPixel = this.unitsPerPixelOnZoomZero / Math.pow(2, this.z);
	
	this.tileSizeOnMap = this.tileSizeOnScreen * this.unitsPerPixel;
	this.pixelValue = 1 / this.unitsPerPixel;
	
	this.gridStartPointOnMap = { x: 0, y: 0 };
	
	newView.xmax = newView.xmin + newScreenWidth * this.unitsPerPixel;
	newView.ymax = newView.ymin + newScreenHeight * this.unitsPerPixel;

	this.currentView = new BBox(newView);
	this.screenWidth = newScreenWidth;
	this.screenHeight = newScreenHeight;
	
	this.reloadGrid();
}

MapGrid.prototype.reloadGrid = function() {
	// find first tile xmin and ymin
	this.gridStartPointOnMap = { 
		x: this.findGridStartPointOnMap(this.gridStartPointOnMap.x, this.currentView.xmin, this.offset.x),
		y: this.findGridStartPointOnMap(this.gridStartPointOnMap.y, this.currentView.ymin, this.offset.y)
	};
	
	var gridStartPointOnScreen = { 
		top: this.screenHeight - this.tileSizeOnScreen + this.findGridOffsetOnScreen(this.gridStartPointOnMap.y, this.currentView.ymin, this.offset.y),
		left: 0 - this.findGridOffsetOnScreen(this.gridStartPointOnMap.x, this.currentView.xmin, this.offset.x)
	};

	// calculate number of tiles
	this.xNumTiles = this.findTilesNumber(this.gridStartPointOnMap.x, this.currentView.xmax, this.offset.x);
	this.yNumTiles = this.findTilesNumber(this.gridStartPointOnMap.y, this.currentView.ymax, this.offset.y);

	// create all tiles
	var newGrid = new Array();
	for (var i = 0; i < this.xNumTiles; i++) {
		var column = new Array();
		for (var j = 0; j < this.yNumTiles; j++) {
			var xmin = (this.gridStartPointOnMap.x + i) * this.tileSizeOnMap + this.offset.x;
			var ymin = (this.gridStartPointOnMap.y + j) * this.tileSizeOnMap + this.offset.y;
			var xmax = xmin + this.tileSizeOnMap;
			var ymax = ymin + this.tileSizeOnMap;
			var top = gridStartPointOnScreen.top - j * this.tileSizeOnScreen;
			var left = gridStartPointOnScreen.left + i * this.tileSizeOnScreen;
			
			column.push(new Tile(this.gridStartPointOnMap.x + i, this.gridStartPointOnMap.y + j, this.z, 
				new BBox({ xmin: xmin, ymin: ymin, xmax: xmax, ymax: ymax }), 
				{ top: top, left: left }));			
		}
		newGrid.push(column);
	}
	
	this.grid = newGrid;
}

MapGrid.prototype.findGridStartPointOnMap = function(actual, min, offset) {
	if (min > ((actual + 1) * this.tileSizeOnMap + offset)) {
		while (min > ((actual + 1) * this.tileSizeOnMap + offset)) actual++;
	} else if (min < (actual * this.tileSizeOnMap + offset)) {
		while (min < (actual * this.tileSizeOnMap + offset)) actual--;
	}

	return actual;
}

MapGrid.prototype.findGridOffsetOnScreen = function(gridPosition, mapPosition, offset) {
	var mapOffset = Math.abs(mapPosition - (gridPosition * this.tileSizeOnMap + offset));
	return mapOffset * this.pixelValue;
}

MapGrid.prototype.findTilesNumber = function(gridStart, mapEnd, offset) {
	var tilesNumber = 1;
	var gridPointer = gridStart;
	while ((gridPointer * this.tileSizeOnMap + offset) < mapEnd) {
		gridPointer++;
		tilesNumber++;
	}
	
	return tilesNumber;
}

MapGrid.prototype.mapToScreen = function(x, y, convertOffScreen) {
	if (convertOffScreen || this.currentView.containsPoint(x, y)) {
		var offsetX = Math.round((x - this.currentView.xmin) / this.unitsPerPixel);
		var offsetY = Math.round((y - this.currentView.ymin) / this.unitsPerPixel);
		
		var top = this.screenHeight - offsetY;
		var left = offsetX;
		
		return { top: top, left: left };
	} else {
		return null;
	}
}

MapGrid.prototype.screenToMap = function(screenX, screenY) {
	return { x: this.currentView.xmin + (screenX / this.pixelValue), 
		y: this.currentView.ymax - (screenY / this.pixelValue) };
}

function TaskCounter(dbmap) {
	this.dbmap = dbmap;
	this.counter = 0;
	this.listeners = [];
}

TaskCounter.prototype = {
	
	addListener: function(listener) {
		this.listeners.push(listener);
	},

	removeListeners: function() {
		this.listeners = [];
	},

	set: function(value) {
		if (value < 0) value = 0;
		this.counter = value;
		this.notifyListeners();
	},

	get: function() {
		return this.counter;
	},

	increment: function() {
		this.set(this.counter + 1);
	},
	
	decrement: function() {
		this.set(this.counter - 1);
	},
		
	clean: function() {
		this.set(0);
	},
	
	notifyListeners: function() {
		for (var i = 0; i < this.listeners.length; i++) {
			this.listeners[i](this.counter, this.dbmap);
		}
	}
};/**
 * Enumerazione di modalit&agrave; utilizzabili 
 * @class
 */
var DbMAPMode = {
	/** @public */
	PAN: "PAN",
	/** @public */
	PICK_POINT: "PICK_POINT",
	/** @public */
	EDIT: "EDIT",	
	/** @public */
	MEASURE: "MEASURE",
	/** @public */
	NO_OPERATION: "NO_OPERATION"
};

/**
 * @class
 */
var DbMAPEntity = {
	/** @public */
	POINT: 1,
	/** @public */
	LINE: 3,
	/** @public */
	POLYGON: 5
};

/**
 * @class
 * 
 * @param id (string) id del DIV contenente la mappa
 * @param tileSize (int) dimensioni del Tile
 * @param unitsPerPixelOnZoomZero (double) a quante unit&agrave; di misura corrisponde un pixel al livello minimo di zoom
 * @param maxZ (int) livello massimo di zoom
 * @param initialLayers (WMSLayer o TileLayer) layer da visualizzare inizialmente
 * @param initialView (BBox) bounding box iniziale
 * @param customImageDir (string) directory delle immagini
 */
function DbMAP(id, tileSize, unitsPerPixelOnZoomZero, maxZ, initialLayers, initialView, gridOffset, customImageDir) {
	this.imageDir = customImageDir == null ? './images' : customImageDir;
	
	this.rnd = Math.round(Math.random() * 100);

	jg_zIndex = 990;
	
	var topDiv = $("<div />")
		.attr("id", id + "_topDiv")
		.css({ position: "absolute", background: "#ffffff", opacity: 0, zIndex: 150, visibility: "hidden" });
	topDiv.css("-moz-user-select", "none");
	
	var tooltipDiv = $("<div />").css({ position: "absolute", border: "1px #FCC90D solid", background: "#FDFFB4", padding:"2 2 2 2", display: "none" });

	var clickDiv = $("<div />").css({ position: "absolute", width: 5, height: 5, background: "#BB0000" });
	clickDiv.append($("<img />").attr("src", this.emptyImg()));
	this.defaultPickedPointMarker = new Marker(clickDiv, 2, 2, 'pickedPointMarker', 0, 0);
	this.pickedPointMarker = this.defaultPickedPointMarker;
			
	var map = $("#" + id).css({ position: "absolute" });
	map.data("dbmap", this);
	
	this.map = map;
	this.panContainer = $("<div />")
		.attr("id", this.id("panContainer"))
		.css({ position: "absolute", overflow: "hidden", width: this.map.css("width"), height: this.map.css("height") });
	
	this.map.wrap(this.panContainer);
	
	$("#" + this.id("panContainer")).append(tooltipDiv);
	$("#" + this.id("panContainer")).append(topDiv);
	
	this.topDiv = topDiv; // per coprire tutte le immagini
	
	this.coordinateListener = [];
	this.viewChangedListener = [];
	this.pickedPointListener = [];
	this.editListener = [];
	this.measureListener = [];
	this.draggingListener = [];
	
	this.tooltipProvider = null;
	this.tooltipDiv = tooltipDiv;
	this.overlays = [];
	
	this.cursorPan = 'move';
	this.cursorPick = 'crosshair';
	this.cursorNoOperation = 'default';
	
	this.mode = DbMAPMode.PAN;
	map.css({ cursor: this.cursorPan });
	
	this.isWheelZoomCenteredOnMousePosition = false;
	this.wheelTimeoutId = null;
	this.tipTimeoutId = null;
	this.wheelDelta = 0;
		
	var theWb = new Whiteboard(this); 
	this.editListener.push(function(mapPoint) { 
		theWb.onClick(mapPoint) 
	});
	this.addViewChangedListener(
		function(new_bbox){
			theWb.repaint(new_bbox)
		}
	);
	this.wb = theWb;
	
	this.layers = [];
	
	this.w = map.width();
	this.h = map.height();
	this.jg = null;

	this.markers = {};

	var loadingImg = $("<img />")
		.css({ visibility: "hidden", position: "absolute", top: 0, left: 0, zIndex: 999 })
		.attr("src", this.loadingImg());
	$("#" + this.id("panContainer")).append(loadingImg);
	
	this.taskCounter = new TaskCounter(this);
	this.taskCounter.addListener(function(taskInProgress, dbmap) {
		if (taskInProgress > 0) {
			var top = Math.round(dbmap.h / 2)
			var left = Math.round(dbmap.w / 2);
			
			loadingImg.css({ visibility: "visible", top: top, left: left });
		} else {
			loadingImg.css({ visibility: "hidden" });			
		}
	});

	this.initialView = initialView;
	this.tileSize = tileSize;
	this.mapGrid = new MapGrid(tileSize, unitsPerPixelOnZoomZero, maxZ, gridOffset);
	this.mapGrid.init(initialView, this.w, this.h);
	
	// Eventi...
	
	$(window).resize(function() {
		var dbmap = map.data("dbmap");
		if (!__U.isUndef(dbmap) && dbmap.watchWindowResize && dbmap.mapGrid.currentView != null) {
			var changed = false;
			if (dbmap.w != map.width()) { 
				changed = true; 
				dbmap.w = map.width() 
			};
			
			if (dbmap.h != map.height()) { 
				changed = true; 
				dbmap.h = map.height() 
			};
			
			if (changed) {
				dbmap.setSize(dbmap.w, dbmap.h);
			}
		}
	});

	topDiv.mousedown(function(event) {
		var dbmap = map.data("dbmap");
		
		if (dbmap.mode == DbMAPMode.NO_OPERATION) return;
		
		if (dbmap.mode == DbMAPMode.PICK_POINT) {
			var pt = __U.point(event.pageX, event.pageY, map);
			if (dbmap.pickedPointMarker != null) {
				dbmap.pickedPointMarker.node.attr('id', dbmap.pickedPointMarker.id);
				dbmap.pickedPointMarker.node.css({ 
					top: pt.y - dbmap.pickedPointMarker.offsetTop, 
					left: pt.x - dbmap.pickedPointMarker.offsetLeft });
				$("#" + dbmap.id("panContainer")).append(dbmap.pickedPointMarker.node);
			}
			dbmap.notifyCoordinateListener(event.pageX, event.pageY, dbmap.pickedPointListener);
		} else if (dbmap.mode == DbMAPMode.EDIT) {
			dbmap.notifyCoordinateListener(event.pageX, event.pageY, dbmap.editListener);			
		} else if (dbmap.mode == DbMAPMode.MEASURE) {
			if (map.data("measure") == null) {
				map.data("measure", []);
			}
			
			var pt = __U.point(event.pageX, event.pageY, map);
			var points = map.data("measure");
			points.push(pt);
			
			dbmap.jg.fillRect(pt.x - 2, pt.y - 2, 5, 5);
			if (points.length > 1) {
				dbmap.jg.drawLine(points[points.length - 2].x, points[points.length - 2].y, pt.x, pt.y);
				
				var ptA, ptB;
				var curPt = dbmap.mapToWorld(pt.x, pt.y);
				var evt = { "map": dbmap, length: 0.0, area: 0.0, x: curPt.x, y: curPt.y };
				
				// perimetro
				
				for (var i = 1; i < points.length; i++) {
					ptA = dbmap.mapToWorld(points[i - 1].x, points[i - 1].y);
					ptB = dbmap.mapToWorld(points[i].x, points[i].y);
					evt.length += dbmap.getDistance(ptA, ptB);
				}
				
				// area 
				// http://alienryderflex.com/polygon_area/				
				if (points.length > 2) {
					var areaFunction;
					if (dbmap.mapGrid.referenceSystemIsLatLon) {
						areaFunction = function(ptA, ptB) { return 0; };
					} else {
						areaFunction = function(ptA, ptB) {	return (ptA.x * ptB.y) - (ptB.x * ptA.y); };
					}
					
					for (var i = 1; i < points.length; i++) {
						ptA = dbmap.mapToWorld(points[i - 1].x, points[i - 1].y);
						ptB = dbmap.mapToWorld(points[i].x, points[i].y);
						evt.area += areaFunction(ptA, ptB);
					}
					ptA = dbmap.mapToWorld(points[points.length - 1].x, points[points.length - 1].y);
					ptB = dbmap.mapToWorld(points[0].x, points[0].y);
					evt.area += areaFunction(ptA, ptB);
					evt.area = Math.abs(evt.area);
					if (!dbmap.mapGrid.referenceSystemIsLatLon) {
						evt.area = evt.area / 2.0;
					}
				}
				
				__U.notifyListeners(dbmap.measureListener, evt);
			}
			
			dbmap.jg.paint();
		}
	});
	
	topDiv.mousemove(function(event) {
		var dbmap = map.data("dbmap");
		if (dbmap.mode != DbMAPMode.MEASURE && !map.data("mousedown")) {
			dbmap.handleTooltip(event);
			dbmap.notifyCoordinateListener(event.pageX, event.pageY);
		}
	});

	map.mousemove(function(event) {
		var dbmap = map.data("dbmap");
		
		dbmap.handleTooltip(event);
		dbmap.notifyCoordinateListener(event.pageX, event.pageY);
	});
	
	map.mousewheel(function(event, delta) {
		var dbmap = map.data("dbmap");
		
		if (dbmap.mode == DbMAPMode.NO_OPERATION) return;
		
		if (dbmap.wheelTimeoutId != null) {
			clearTimeout(dbmap.wheelTimeoutId);
			dbmap.wheelTimeoutId = null;
		}
		
		dbmap.wheelDelta += delta;
		dbmap.lastMousePosX = event.pageX;
		dbmap.lastMousePosY = event.pageY;
		
		dbmap.wheelTimeoutId = setTimeout(function() { dbmap.wheelZoom(); }, 200);
		
		return false;
	});
	
	map.draggable({
		cursor: 'move',
		revert: true,
		revertDuration: 0,
		start: function(event, ui) {
			var dbmap = map.data("dbmap");
			dbmap.notifyDraggingListener();			
		},
		stop: function(event, ui) {
			var dbmap = map.data("dbmap");
			
			var deltaX = (ui.position.left / dbmap.mapGrid.pixelValue);
			var deltaY = (ui.position.top / dbmap.mapGrid.pixelValue);
			var bbox = {
				xmin: dbmap.mapGrid.currentView.xmin - deltaX,
				xmax: dbmap.mapGrid.currentView.xmax - deltaX,
				ymin: dbmap.mapGrid.currentView.ymin + deltaY,
				ymax: dbmap.mapGrid.currentView.ymax + deltaY
			};

			dbmap.hideImages();

			dbmap.pan(bbox);
		}
	});
	
	if (!__U.isUndef(initialLayers)) {
		if (!initialLayers.length) {
			this.addLayer(initialLayers, false);
		} else {
			for (var i = 0; i < initialLayers.length; i++) {
				this.addLayer(initialLayers[i], false);
			}
		}
	}	
}

DbMAP.prototype = {
	watchWindowResize: false,
	
	/**
	 * @private
	 */
	id: function(base) {
		return "_" + this.rnd + "_" + base;
	},
	
	/**
	 * Convert degrees to radians
	 * 
	 * @private
	 */
	toRad: function(degree) {
  		return degree * Math.PI / 180;
	},
	
	/**
	 * Calcola la distanza tra due punti
	 */
	getDistance: function(ptA, ptB) {
		if (this.mapGrid.referenceSystemIsLatLon) {
			var lon1 = this.toRad(ptA.x);
			var lat1 = this.toRad(ptA.y);
			var lon2 = this.toRad(ptB.x);
			var lat2 = this.toRad(ptB.y);
			
			// http://www.movable-type.co.uk/scripts/latlong.js
			var R = 6371000; // m
			return Math.acos(Math.sin(lat1) * Math.sin(lat2) 
				+ Math.cos(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1)) * R;
		} else {
			return Math.sqrt(Math.pow(ptA.x - ptB.x, 2) + Math.pow(ptA.y - ptB.y, 2));
		}
	},
	
	/**
	 * @private
	 */
	addImg: function(src) {		
		this.taskCounter.increment();

		var mapId = '#' + this.map.attr('id');

		var img = $('<img onLoad="$(\'' + mapId + '\').data(\'dbmap\').taskCounter.decrement()" />');
		img.css({ margin: "0px", padding: "0px", border: "0px none", width: this.tileSize, height: this.tileSize });
		img.css("-moz-user-select", "none");
	
		this.map.append(img);		
		
		img.attr('src', src);
		
		return img;
	},

	/**
	 * Aggiunge un DIV (Marker) sopra una determinata coordinata della mappa
	 * 
	 * @param marker (Marker) istanza di Marker
	 */
	addMarker: function(marker) {
		if (this.markers[marker.id] != null) {
			this.removeMarker(marker.id);
		}
		
		marker.node.attr('id', marker.id);

		var screenPosition = this.mapGrid.mapToScreen(marker.x, marker.y, marker.insertEvenIfOffScreen);
		if (screenPosition != null) {		
			marker.node.css({ display: "", position: "absolute", 
				top: screenPosition.top - marker.offsetTop, 
				left: screenPosition.left - marker.offsetLeft });
			marker.node.css("z-index", 159);			
		} else {
			marker.node.css({ display: "none" });			
		}

		this.map.append(marker.node);
		this.markers[marker.id] = marker;
	},

	/**
	 * Rimuove un Marker
	 * 
	 * @param uniqueId (string) id del DIV
	 */
	removeMarker: function(uniqueId) {
		$('#' + uniqueId).remove();
		delete this.markers[uniqueId];
	},

	/**
	 * Rimuove tutti i Markers
	 */
	removeMarkers: function() {
		for (var uniqueId in this.markers) {
  			this.removeMarker(uniqueId);
		}
	},

	/**
	 * Nasconde tutti i Marker
	 */
	hideMarkers: function() {
		for (var id in this.markers) {
			var marker = this.markers[id];
			marker.node.css("display", "none");			
		}
	},
	
	/**
	 * Mostra tutti i Marker
	 */
	showMarkers: function() {
		for (var id in this.markers) {
			var marker = this.markers[id];

			var screenPosition = this.mapGrid.mapToScreen(marker.x, marker.y, marker.insertEvenIfOffScreen);
			if (screenPosition != null) {		
				marker.node.css({ display: "", position: "absolute", 
					top: screenPosition.top - marker.offsetTop, 
					left: screenPosition.left - marker.offsetLeft });
				marker.node.css("z-index", 159);	
			} else {
				marker.node.css({ display: "none" });			
			}
		}
	},

	/**
	 * Aggiunge un Layer
	 * 
	 * @param layer (Layer) layer da aggiungere
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	addLayer: function(layer, repaint) {
		this.layers.push(layer);		
		if (repaint) this.repaint();
	},
	
	/**
	 * Rimuove un Layer
	 * 
	 * @param layer (Layer) layer da rimuovere
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	removeLayer: function(layer, repaint) {
		var index = -1;
		for (var i = 0; i < this.layers.length; i++) {
			if (this.layers[i] == layer) index = i;
		}
		
		if (index > -1) {
			var layer = this.layers[index];
			layer.setVisible(false);
			
			// remove layer images
			this.repaint();
			
			// splice: remove one element at the given index
			this.layers.splice(index, 1);
			
			this.repaint();
		} else {
			// TODO tmp
			alert('Layer NOT found');
		}
	},
	
	/**
	 * Imposta le dimensioni della mappa
	 * 
	 * @param w (int) width
	 * @param h (int) height
	 */
	setSize: function(w, h) {
		this.w = w;
		this.h = h;
		
		$("#" + this.id("panContainer")).css({ width: this.w, height: this.h });
		this.map.css({ width: this.w, height: this.h });
		
		if (this.mapGrid.currentView != null) {
			this.mapGrid.resize(this.w, this.h);
			this.notifyViewChangedListener(false);	
			this.repaint();
		}
	},
	
	/**
	 * Aggiunge componente alla mappa
	 * 
	 * @param obj (div html) un div da sovrapporre alla mappa
	 */
	addOverlay: function(obj) {
		this.overlays.push(obj);
		if (obj.getGUI) {
			var gui = obj.getGUI();
			if (gui != null) $("#" + this.id("panContainer")).append($(gui).css("zIndex", "160"));
		}
	},
	
	/**
	 * @private
	 */
	notifyDraggingListener: function() {
		__U.notifyListeners(this.draggingListener);
	},
	
	addDraggingListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.draggingListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'cambio di coordinata'. 
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x e y, coordinate della mappa.
	 * 
	 * Esempio: 
	 * dbmap.addCoordinateListener(function(evt) {
	 * 	alert('coordinate x=' + evt.x + ', y=' + evt.y);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addCoordinateListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.coordinateListener.push(listener);
		}
	},
	
	/**
	 * @private
	 */
	notifyCoordinateListener: function(screenX, screenY, listeners) {
		var wc = this.screenToWorld(screenX, screenY);
		wc["map"] = this;
		__U.notifyListeners(listeners || this.coordinateListener, wc);
	},
	
	/**
	 * @private
	 */
	screenToWorld: function(screenX, screenY) {
		var pos = $(this.map).offset();
		return this.mapToWorld(screenX - pos.left, screenY - pos.top);
	},
	
	/**
	 * @private
	 */
	mapToWorld: function(mapX, mapY) {
		return this.mapGrid.screenToMap(mapX, mapY);
	},

	/**
	 * Aggiunge un listener dell'evento 'vista modificata'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto BBox.
	 * 
	 * Esempio: 
	 * dbmap.addViewChangedListener(function(evt) {
	 * 	alert('bbox xmin=' + evt.xmin + ', ymin=' + evt.ymin + ', xmax=' + evt.xmax + ', ymax=' + evt.ymax);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addViewChangedListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.viewChangedListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'selezionato punto'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x e y.
	 * 
	 * Esempio: 
	 * dbmap.addPickedPointListener(function(evt) {
	 * 	alert('coordinate x=' + evt.x + ', y=' + evt.y);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addPickedPointListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.pickedPointListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'effettuata misurazione'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x, y, length e area.
	 * 
	 * Esempio: 
	 * dbmap.addMeasureListener(function(evt) {
	 * 	alert('measure x=' + evt.x + ', y=' + evt.y + ', length=' + evt.length + ', area = ' + evt.area);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addMeasureListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.measureListener.push(listener);
		}
	},
	
	/**
	 * Imposta il fornitore di suggerimenti
	 * 
	 * @param p (tooltip provider) instanza di TooltipProvider
	 */
	setTooltipProvider: function(p) {
		this.tooltipProvider = p;
	},
	
	/**
	 * Visualizza un tooltip alle coordinate specificate
	 * 
	 * @param html (div html) div contenente il tooltip
	 * @param x (int) coordinata x dello schermo
	 * @param y (int) coordinata y dello schermo
	 */
	showTooltip: function(html, x, y) {
		this.tooltipDiv.html(html).css({ left: x, top: y }).show();
	},
	
	/**
	 * @private
	 */
	handleTooltip: function(event) {
		if (this.tooltipProvider != null) {
			this.tooltipDiv.hide();
			if (this.tipTimeoutId != null) clearTimeout(this.tipTimeoutId);
			var dbmap = this;
			var callback = function() { dbmap.tooltipProvider(__U.point(event.pageX, event.pageY, dbmap.map), dbmap.screenToWorld(event.pageX, event.pageY)) };
			this.tipTimeoutId = setTimeout(callback, 200);
		}
	},
	
	/**
	 * @private
	 */
	removePickedPointMarker: function() {
		if (this.pickedPointMarker != null) {
			$('#' + this.pickedPointMarker.id).remove();
		}
	},
	
	/**
	 * @private
	 */
	notifyViewChangedListener: function(paintEnd) {
		this.removePickedPointMarker();
		
		if (this.jg != null && this.mode == DbMAPMode.MEASURE) {
			this.jg.clear();
			this.map.data("measure", []);
			__U.notifyListeners(this.measureListener, { x: 0, y: 0, length: 0, area: 0, "map": this });
		}		
		
		var bbox = this.mapGrid.currentView.getCoordinates();
		bbox.dbmap = this;
		bbox.paintEnd = paintEnd; 
		
		// Notifico prima gli overlay...
		for (var i = 0; i < this.overlays.length; i++) {
			if (this.overlays[i].viewChanged) this.overlays[i].viewChanged(bbox);
		}
		
		// poi i listeners
		__U.notifyListeners(this.viewChangedListener, bbox);
	},

	/**
	 * @private
	 */
	changeCursor: function(newCursor) {
		this.map.css({ cursor: newCursor });
	},

	/**
	 * Imposta lo strumento da usare, una delle costanti di DbMAPMode
	 * 
	 * @param newMode (string) una delle costanti di DbMAPMode
	 */
	setMode: function(newMode) {
		this.removePickedPointMarker();
		
		if (this.jg != null) this.jg.clear();
		this.map.data("mousedown", false);
		this.map.data("measure", null);
		
		this.mode = newMode;
		
		var topDivVisible = false;
		if (newMode == DbMAPMode.PICK_POINT || newMode == DbMAPMode.EDIT || newMode == DbMAPMode.MEASURE) {
			this.changeCursor(this.cursorPick);
			
			this.map.draggable('disable');
			
			topDivVisible = true;
			this.topDiv.css({ 
				visibility: "visible",
				top: 0, left: 0,
				width: this.w,
				height: this.h
			});
			
			if (newMode == DbMAPMode.MEASURE && this.jg == null) {
				this.jg = new jsGraphics($(this.map).get(0));
				this.jg.setColor("#ff0000");
				this.jg.setStroke(2);
			}
		} else if (newMode == DbMAPMode.PAN) {
			this.changeCursor(this.cursorPan);
			
			this.map.draggable('enable');
			
			this.topDiv.css({ visibility: "hidden", top: 0, left: 0, width: 0, height: 0 });
		} else if (newMode == DbMAPMode.NO_OPERATION) {
			this.changeCursor(this.cursorNoOperation);
			
			this.map.draggable('disable');
			
			this.topDiv.css({ visibility: "hidden", top: 0, left: 0, width: 0, height: 0 });
		}
	},

	/**
	 * Ricarica
	 * 
	 * @param zoomLevel (int) livello di zoom da cui partire
	 */
	reload: function(zoomLevel) {
		this.mapGrid.zoomToLevel(zoomLevel);
		this.mapGrid.init(this.initialView, this.w, this.h);
		
		this.notifyViewChangedListener(false);	
		this.repaint();
	},

	/**
	 * Sposta la mappa nel riquadro passato, mantenendo lo stesso livello di zoom
	 * 
	 * @param bbox (BBox) bounding box { xmin: ..., ymin: ..., xmax: ..., ymax: ... }
	 */
	pan: function(bbox) {
		this.mapGrid.pan(bbox);
		this.notifyViewChangedListener(false);	
		this.repaint();
	},
	
	/**
	 * Centra la mappa sul punto passato
	 * 
	 * @param x (double) coordinata x della mappa
	 * @param y (double) coordinata y della mappa
	 */
	panToPoint: function(x, y) {
		this.mapGrid.panToPoint(x, y);
		this.notifyViewChangedListener(false);
		this.repaint();
	},
	
	/**
	 * Aumenta il livello di zoom
	 */
	zoomIn: function() {
		if (this.mapGrid.zoomIn()) {
			this.notifyViewChangedListener(false);			
			this.repaint();
		}
	},
	
	/**
	 * Diminuisci il livello di zoom
	 */
	zoomOut: function() {
		if (this.mapGrid.zoomOut()) {
			this.notifyViewChangedListener(false);			
			this.repaint();
		}
	},
	
	/**
	 * Visualizza il bounding box passato al massimo livello di zoom possibile
	 * 
	 * @param view (BBox) area di zoom
	 */
	zoomToWindow: function(view) {
		this.mapGrid.zoomToWindow(view);
		this.notifyViewChangedListener(false);
		this.repaint();
	},
	
	/**
	 * Imposta un determinato livello di zoom
	 * 
	 * @param newZ (int) livello di zoom
	 * @param notify (boolean) notificare i listener?
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	zoomToLevel: function(newZ, notify, repaint) {
		this.mapGrid.zoomToLevel(newZ);
		
		if (notify) {
			this.notifyViewChangedListener(false);
		}
		
		if (repaint) {
			this.repaint();
		}
	},
	
	/**
	 * Ridisegna
	 */
	repaint: function() {
		this.hideMarkers();
		
		this.taskCounter.clean();
		
		for (var i = 0; i < this.layers.length; i++) {
			this.layers[i].repaint(this, i);
		}
		
		this.showMarkers();
	},

	/**
	 * @private
	 */
	hideImages: function() {
		for (var i = 0; i < this.layers.length; i++) {
			this.layers[i].hideImages(this);
		}
	},
	
	/**
	 * Imposta la directory delle immagini
	 */
	setImageDir: function(imageDir) {
		this.imageDir = imageDir;
	},
	
	/**
	 * Restituisce la directory delle immagini
	 */
	getImageDir: function() {
		return this.imageDir;
	},
	
	/**
	 * @private
	 */
	emptyImg: function() {
		return this.getImageDir() + '/dbmap/trasp.gif';
	},
	
	/**
	 * @private
	 */	
	loadingImg: function() {
		return this.getImageDir() + '/dbmap/loading.gif';
	},	
	
	/**
	 * Ritorna la scala
	 */
	getScale: function() {
		return this.mapGrid.getScale();
	},

	/*
	 * Ricarica il layer specificato
	 * 
	 * @param layerIndex (int) indice del Layer
	 */
	reloadLayer: function(layerIndex) {
		var layer = this.layers[layerIndex];
		if (layer != null) {
			layer.setVisible(false);
			this.repaint();
			
			var d = new Date();
			
			layer.addParam('refresh', 't' + d.getTime());
			layer.setVisible(true);
			this.repaint();
		}
	},

	/**
	 * Restituisce l'url per una richiesta GetFeatureInfo al server WMS
	 * 
	 * @param wmsLayer (Layer) server wms al quale collegarsi
	 * @param layerIndex (int) indice del layer
	 * @param format (string) formato in cui si vuole la risposta della GetFeatureInfo (esempio: 'text/html')
	 * @param point (object) punto di cui si vogliono visualizzare le informazioni { x: ..., y: ...}
	 */
	getFeatureInfoUrl: function(wmsLayer, layerIndex, format, point) {
		var view = this.mapGrid.currentView;
		
		var url = wmsLayer.props.url;
		url += (url.indexOf('?') > -1 ? '&' : '?');
		url += 'VERSION=1.1.1&REQUEST=GetFeatureInfo';
		url += '&SRS=' + escape(wmsLayer.props.srs);
		url += '&FORMAT=' + escape(format);
		url += '&WIDTH=' + this.w + '&HEIGHT=' + this.h + '&BBOX=' + view.xmin + ',' + view.ymin + ',' + view.xmax + ',' + view.ymax;
		url += '&X=' + point.x + '&Y=' + point.y;
		url += '&QUERY_LAYERS=' + wmsLayer.props.layers[layerIndex].name;
		url += '&LAYERS=' + wmsLayer.props.layers[layerIndex].name;
		
		return url;
	},

	/**
	 * Attiva la modalit&agrave; di disegno di una nuova entit&agrave;
	 * 
	 * @param entityType (string) il tipo di elemento che si vuole creare
	 */
	drawNew: function(entityType) {
		this.wb.add(entityType);	
		this.startDrawing();			
	},
	
	/**
	 * Attiva la modalit&agrave; di disegno di un'entit&agrave; esistente
	 * 
	 * @param entityType (string) il tipo di elemento che si vuole modificare
	 * @param entityId (int) il codice identificativo dell'elemento che si vuole modificare
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	draw: function(entityType, id, asjServlet, table, idField, geomField) {
		var callparams = "?function=select_sdastring";
		callparams += "&TableName=" + table;	
		callparams += "&IdentField=" + idField;
		callparams += "&ElemId=" + id;
		callparams += "&GeometryField=" + geomField;
				
		var error = false;
		var responseText = $.ajax({
			type: 'POST',
			url: asjServlet + callparams,
		  	async: false,
		  	error: function() {
		  		error = true;
		  		alert('Errore durante la chiamata al server');
		  	}
		}).responseText;
		 
		if (error) return;
		
		if (responseText.indexOf('SIT_RETCODE:-1000|NO RECORD FOUND') != -1) {
			alert('Elemento non trovato');
			return;
		} else if (responseText.indexOf('SIT_RETCODE:0|') == -1) {
			alert('Errore imprevisto: ' + responseText);
			return;
		}
		
		// strip header
		responseText = this.stripSdaTokens(responseText, 2);
		
		// strip bbox
		responseText = responseText.substring(responseText.indexOf('&'));

		// read type
		var type = this.readSdaInt(responseText);
		responseText = this.stripSdaToken(responseText);
		
		// check type validity
		
		if (type == 1 && entityType != DbMAPEntity.POINT) {
			alert('L\'elemento trovato non � un Punto');
			return;			
		} else if (type == 3 && entityType != DbMAPEntity.LINE) {
			alert('L\'elemento trovato non � una Linea');
			return;			
		} else if (type == 5 && entityType != DbMAPEntity.POLYGON) {
			alert('L\'elemento trovato non � un Poligono');
			return;			
		}
		
		// strip num of dims (must be 2)
		responseText = this.stripSdaToken(responseText);
		
		// read coordinates

		var points = new Array();
		
		if (entityType == DbMAPEntity.POINT) {
			points.push(this.readSdaPoint(responseText));
		} else if (entityType == DbMAPEntity.LINE || entityType == DbMAPEntity.POLYGON) {
			// strip num of parts (must be 1)
			responseText = this.stripSdaToken(responseText);
			
			// read num of points
			var numOfPoints = this.readSdaInt(responseText);
			responseText = this.stripSdaToken(responseText);

			// strip num of points per part (must be equal to num of points)
			responseText = this.stripSdaToken(responseText);
			
			for (var i = 0; i < numOfPoints; i++) {
				points.push(this.readSdaPoint(responseText));
				responseText = this.stripSdaTokens(responseText, 2);
			}
		}
					
		this.wb.edit(entityType, id, points);
		this.startDrawing();		
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, aggiungi un nuovo vertice a quelli esistenti
	 */
	appendVertex: function() {
		this.wb.appendVertex();
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, sposta il vertice pi� vicino al click del mouse
	 */	
	moveVertex: function() {
		this.wb.moveVertex();
	},

	/**
	 * Durante la modalit&agrave; di disegno, inserisci un nuovo vertice nel segmento pi� vicino al click del mouse
	 */	
	insertVertex: function() {
		this.wb.insertVertex();
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, elimina il vertice pi� vicino al click del mouse
	 */
	deleteVertex: function(){
		this.wb.deleteVertex();
	},
	
	/**
	 * Termina la modalit&agrave; "disegno"
	 */
	stopDrawing: function() {
		this.wb.stop();
		this.wb.clear();
		this.setMode(DbMAPMode.PAN);
	},

	/*
	 * Ritorna l'elenco dei punti dell'entit&agrave; disegnata
	 */
	getDrawnEntity: function() {
		return this.wb.getPoints();
	},

	/**
	 * Ritorna il codice identificativo dell'entit&agrave; disegnata
	 */
	getDrawnEntityId: function() {
		return this.wb.getId();
	},

	/**
	 * Ritorna il tipo dell'entit&agrave; disegnata
	 */
	getDrawnEntityType: function() {
		return this.wb.getType();
	},

	/**
	 * Inserisce l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param id (string) id univoco dell'elemento 
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	insertDrawnEntity: function(id, asjServlet, table, idField, geomField) {
		return this.saveEntity(this.getDrawnEntityType(), id, this.getDrawnEntity(), asjServlet, table, idField, geomField, true);
	},

	/**
	 * Aggiorna l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	updateDrawnEntity: function(asjServlet, table, idField, geomField) {
		return this.saveEntity(this.getDrawnEntityType(), this.getDrawnEntityId(), this.getDrawnEntity(), asjServlet, table, idField, geomField, false);
	},
		 
	/**
	 * Salva l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param entityType (string) una costante di DbMAPEntity
	 * @param id (string) id univoco dell'elemento 
	 * @param coords (array) lista di coordinate che definiscono l'entit&agrave;
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 * @param isNew (boolean) nuovo elemento?
	 */
	saveEntity: function(entityType, id, coords, asjServlet, table, idField, geomField, isNew) {
		if (this.mode != DbMAPMode.EDIT) return null;
		
		var callparams = "?function=updateext";
		callparams += "&TableName=" + table;
		
		if (isNew) callparams += "&EDITING=I";
		else callparams += "&EDITING=U";
		
		callparams += "&GeometryField=" + geomField;
		if (id != null) {
			if (isNew) {
				callparams += "&field_" + idField + "=" + id;
			} else {
				callparams += "&IdentField=" + idField + "&ElemId=" + id;
			}
		}

		callparams += "&SDAString=";
		
		var sdaString;
		if (entityType == DbMAPEntity.POINT) {
			sdaString = "#" + coords[0].x + "|#" + coords[0].y + "|#" + coords[0].x + "|#" + coords[0].y + 
				"|&1|&2|#" + coords[0].x + "|#" + coords[0].y;	
		} else if (entityType == DbMAPEntity.LINE) {
			var coordStr = "";
			var min_x = coords[0].x;
		 	var min_y = coords[0].y;
			var max_x = coords[0].x;
		 	var max_y = coords[0].y;
		 	
		 	for (var i = 0; i < coords.length; i++) {
		 		min_x = Math.min(coords[i].x, min_x);
		 		max_x = Math.max(coords[i].x, max_x);
		 		min_y = Math.min(coords[i].y, min_y);
		 		max_y = Math.max(coords[i].y, max_y);
		 		coordStr += "|#" + coords[i].x + "|#" + coords[i].y;
		 	}
			
			sdaString = "#" + min_x + "|#" + min_y + "|#" + max_x + "|#" + max_y + 
				"|&3|&2|&1|&" + coords.length + "|&" + coords.length + coordStr;
		} else if (entityType == DbMAPEntity.POLYGON) {
			var coordStr = "";
			var min_x = coords[0].x;
		 	var min_y = coords[0].y;
			var max_x = coords[0].x;
		 	var max_y = coords[0].y;
		 	
		 	for (var i = 0; i < coords.length; i++) {
		 		min_x = Math.min(coords[i].x, min_x);
		 		max_x = Math.max(coords[i].x, max_x);
		 		min_y = Math.min(coords[i].y, min_y);
		 		max_y = Math.max(coords[i].y, max_y);
		 			
	 			coordStr += "|#" + coords[i].x + "|#" + coords[i].y;
		 	}
			
			sdaString = "#" + min_x + "|#" + min_y + "|#" + max_x + "|#" + max_y + 
				"|&5|&2|&1|&" + coords.length + "|&" + coords.length + coordStr;
		}
		callparams += escape(sdaString);
		
		var esito = "";
				
		$.ajax({
			type: "POST",
			async: false,
			url: asjServlet + callparams,
			success: function(data) {
				esito = data;
			},
			error: function(data) {
				esito = data;
			}
		});
		
		this.stopDrawing();
		
		return esito;
	 },

	/**
	 * @private
	 */		 
	startDrawing: function() {
	    this.setMode(DbMAPMode.EDIT);
	},
	
	/**
	 * @private
	 */		 
	 readSdaPoint: function(text) {
	 	var x = this.readSdaDouble(text);
		text = this.stripSdaToken(text);
		var y = this.readSdaDouble(text);
		return { x: x, y: y };
	 },
		 
	/**
	 * @private
	 */		 
	readSdaInt: function(text) {
		if (text == null || text.indexOf('&') != 0) {
			alert('Not a INT:' + text);
			return null;
		}
		
		if (text.indexOf('|') != -1) {
			return text.substring(1, text.indexOf('|'));
		} else {
			// this is the last token
			return text.substring(1);
		}
	},

	/**
	 * @private
	 */		 
	readSdaDouble: function(text) {
		if (text == null || text.indexOf('#') != 0) {
			alert('Not a DOUBLE:' + text);
			return null;
		}
		
		if (text.indexOf('|') != -1) {
			return text.substring(1, text.indexOf('|'));
		} else {
			// this is the last token
			return text.substring(1);
		}
	},

	/**
	 * @private
	 */		 
	stripSdaToken: function(text) {
		return this.stripSdaTokens(text, 1);
	},
		
	/**
	 * @private
	 */		 
	stripSdaTokens: function(text, num) {
		if (text == null || text.length == 0) return text;
		
		for (var i = 0; i < num; i++) {
			text = text.substring(text.indexOf('|') + 1);
		}
		return text;
	},
	
	/**
	 * @private
	 */
	wheelZoom: function() {
		this.mapGrid.zoomToLevel(this.mapGrid.getZoomLevel() + this.wheelDelta);

		if (this.isWheelZoomCenteredOnMousePosition) {		
			var mapPoint = this.screenToWorld(this.lastMousePosX, this.lastMousePosY);
			this.mapGrid.panToPoint(mapPoint.x, mapPoint.y);
		}
		
		this.wheelDelta = 0;
		this.wheelTimeoutId = null;
		this.notifyViewChangedListener(false);			
		this.repaint();				
	}
}

/* *********************************************** */

var __U = function() {
	var rnd = Math.round(Math.random() * 100);
	return {
		isUndef: function(o) {
			return (typeof(o) == 'undefined');
		},
		
		clone: function(o) {
			function c(o) {
				for (i in o) this[i] = o[i];
			}
			return new c(o);
		},
		
		screenBbox: function(x1, y1, x2, y2, objForOffset) {
			var pos = typeof(objForOffset) == 'undefined' ? { top:0, left:0} : $(objForOffset).offset();
			
			x1 -= pos.left;
			x2 -= pos.left;
			y1 -= pos.top;
			y2 -= pos.top;
			
			return { xmin: Math.min(x1, x2), ymin: Math.min(y1, y2), xmax: Math.max(x1, x2), ymax: Math.max(y1, y2) };
		},
		
		point: function(px, py, objForOffset) {
			var pos = typeof(objForOffset) == 'undefined' ? { top:0, left:0} : $(objForOffset).offset();
			px -= pos.left;
			py -= pos.top;
			return { x: px, y: py };
		},
		
		notifyListeners: function(listeners, evt) {
			for ( var i = 0; i < listeners.length; i++) {
				listeners[i](evt);
			}
		}
	}
}();
function Layer(props) {
	this.usable = true;
	
	var p = props || {};
	
	if (__U.isUndef(p.transparent)) p.transparent = false;
	if (__U.isUndef(p.format)) p.format = p.transparent ? "image/png" : "image/jpeg";
	if (__U.isUndef(p.bgcolor)) p.bgcolor = "0xffffff";
	if (__U.isUndef(p.layers))  p.layers = null;
	if (__U.isUndef(p.srs))  p.srs = "none";
	if (__U.isUndef(p.visible))  p.visible = true;
	if (__U.isUndef(p.zoomMin))  p.zoomMin = -1;
	if (__U.isUndef(p.zoomMax))  p.zoomMax = -1;
	if (__U.isUndef(p.opacity))  p.opacity = null;
				
	var layers = [];
	if (p.layers != null) {
		var userLayers = p.layers;
		for (var i = 0; i < p.layers.length; i++) {
			if (typeof(p.layers[i]) == 'string') {
				layers[i] = { name: p.layers[i], visible: true, default_theme_name: '', themes: [] };
			} else {
				layers[i] = p.layers[i];
			}
		}
	}
	p.layers = layers;
	
	if (p.name) this.name = p.name;
	
	this.props = p;
	
	this.extraParams = [];
}

/**
 * @private
 */
Layer.prototype.isVisibleInZoom = function(zoom) {
	return (this.props.zoomMin < 0 || zoom >= this.props.zoomMin) &&
		(this.props.zoomMax < 0 || zoom <= this.props.zoomMax); 
}

/**
 * Imposta la visibilit&agrave; del layer
 */
Layer.prototype.setVisible = function(visible) {
    this.props.visible = visible;
}

Layer.prototype.setName = function(name) { 
	this.name = name;
}

/**
 * aggiunge un parametro al layer, il parametro viene inviato nella chiamata al server WMS
 */
Layer.prototype.addParam = function(n, v) {
	var ok = true;
	for (var i = 0; ok && i < this.extraParams.length; i++) {
		if (this.extraParams[i].name == name) {
			this.extraParams[i].value = value;
			ok = false;
		}
	}
	if (ok) this.extraParams.push({name: n, value: v});
}
	
/**
 * Rimuove tutti i parametri aggiunti
 */
Layer.prototype.clearParams = function() {
	this.extraParams = [];
}
	
Layer.prototype.repaint = function(dbmap, level) {
}

Layer.prototype.hideImages = function(dbmap) {
}
	
Layer.prototype.getLegend = function(dbmap, w) {
	var ret = $("<div/>").css({ "font-family": "Verdana, Arial", "font-weight": "bold", "font-size": "10px", "margin-bottom": 5 });
		
	var layer = this;
	var dummy = $("<input type='checkbox'/>");
	dummy.attr("checked", this.props.visible);
	dummy.click(function() {
		layer.setVisible($(this).attr("checked"));
		dbmap.repaint();
	});
	ret.append(dummy).append(this.name);
		
	if (this.props.layers.length > 1) {
		var div = $("<div/>").css({ position: "relative", top: 0, left: 10 });
		for (var i = 0; i < this.props.layers.length; i++) {
			dummy = $("<input type='checkbox'/>")
				.attr("checked", this.props.layers[i].visible)
				.data("layer", this.props.layers[i]);
			
			dummy.click(function() {
				$(this).data("layer").visible = $(this).attr("checked");
				dbmap.repaint();
			});
			
			if (i > 0) div.append($("<br/>"));
			div.append(dummy);
			div.append('<img src="' + this.props.urlLayerIcon + 'layerIndex=' + i + '"/>');
			div.append(this.props.layers[i].name);
			
			for (var j = 0; j < this.props.layers[i].themes.length; j++) {
				var theme = this.props.layers[i].themes[j];
				if (theme.name == this.props.layers[i].default_theme_name) {
					for (var k = 0; k < theme.entries.length; k++) {
						div.append('<br/>')
						div.append('<img style="margin-left:20px" src="' + this.props.urlLayerThemeIcon + 'layerIndex=' + i + '&themeIndex=' + j + '&themeEntryIndex=' + k + '"/>');
						div.append(theme.entries[k].description);
					}
				}
			}
		}
		ret.append(div);
	}
		
	return ret;
}
function GridLayer(props) {
	Layer.call(this, props);
	this.images = {};	
}

GridLayer.prototype = new Layer();

GridLayer.prototype.iterateTiles = function(dbmap, tileIterator) {
	for (var j = 0; j < dbmap.mapGrid.xNumTiles; j++) {
		for (var k = 0; k < dbmap.mapGrid.yNumTiles; k++) {
			tileIterator(j, k, dbmap.mapGrid.grid[j][k]);
		}
	}
}

GridLayer.prototype.iterateImages = function(dbmap, imageIterator) {
		var images = this.images;
		this.iterateTiles(dbmap, function(xTile, yTile, tile) {
			var image = images[xTile + 'x' + yTile];
			if (image != null) {
				imageIterator(image, xTile, yTile);
			}
		});
	},
	
GridLayer.prototype.hideImages = function(dbmap) {
	this.iterateImages(dbmap, function(image, xTile, yTile) {
		image.css("display", "none");
	});
},
	
GridLayer.prototype.src = function(tile, tileSize) {
	return '';
}
	
GridLayer.prototype.repaint = function(dbmap, level) {
	var layer = this;
		
	// index images by src
	var imageIndex = {};
	this.iterateImages(dbmap, function(image, xTile, yTile) {
		imageIndex[image.attr("src")] = { image: image, xTile: xTile, yTile: yTile };
	});

	var newImagesQueue = new Array();

	if (this.props.visible && this.isVisibleInZoom(dbmap.mapGrid.getZoomLevel())) {
		// move existing images in the grid or add new images data to a queue
		this.iterateTiles(dbmap, function(xTile, yTile, tile) {
			var src = layer.src(tile, dbmap.tileSize);
				
			if (imageIndex[src] != null) {
				var image = imageIndex[src].image;
				image.css({ position: "absolute", top: tile.screenPosition.top, left: tile.screenPosition.left, display: "", zIndex: level });
				layer.images[xTile + 'x' + yTile] = image;
				delete imageIndex[src];
			} else {
				newImagesQueue.push({ xTile: xTile, yTile: yTile, top: tile.screenPosition.top, left: tile.screenPosition.left, src: src });
			}
		});
	} else {
		this.images = {};
	}
	
	// clean grid		
	for (var src in imageIndex) { 
		if (imageIndex[src] != null) {
			imageIndex[src].image.remove();
		}
	}

	// create new images
	for (var i = 0; i < newImagesQueue.length; i++) {
		var imageData = newImagesQueue[i];
		
		var image = dbmap.addImg(imageData.src);
		image.css({ position: "absolute", top: imageData.top, left: imageData.left, zIndex: level });
		
		if (this.props.opacity != null) {
			image.css({ opacity: this.props.opacity / 100, filter: 'alpha(opacity=' + this.props.opacity + ')' });
		}
		
		layer.images[imageData.xTile + 'x' + imageData.yTile] = image;
	}
}/**
 * @class Layer WMS. Si collega ad un server WMS.
 */
function WMSLayer(props) {
	GridLayer.call(this, props);
}

WMSLayer.prototype = new GridLayer();

WMSLayer.prototype.src = function(tile, tileSize) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + tileSize + "&HEIGHT=" + tileSize;
	url += "&BBOX=" + tile.bbox.xmin + "," + tile.bbox.ymin + "," + tile.bbox.xmax + "," + tile.bbox.ymax;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}/**
 * @class Tile Layer. Si collega ad un server Abaco Tile Server.
 */
function TileLayer(props) {
	GridLayer.call(this, props);
}

TileLayer.prototype = new GridLayer();

TileLayer.prototype.src = function(tile, tileSize) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&project=" + escape(this.props.project);
	url += "&tileSize=" + tileSize;
	url += "&x=" + tile.x + "&y=" + tile.y + "&z=" + tile.z;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}
function SingleRequestWMSLayer(props) {
	Layer.call(this, props);
	this.image = null;
}

SingleRequestWMSLayer.prototype = new Layer();

SingleRequestWMSLayer.prototype.repaint = function(dbmap, level) {
	var src = this.src({ 
			xmin: dbmap.mapGrid.currentView.xmin, 
			ymin: dbmap.mapGrid.currentView.ymin, 
			xmax: dbmap.mapGrid.currentView.xmax, 
			ymax: dbmap.mapGrid.currentView.ymax 
		}, dbmap.w, dbmap.h);
				
	if (this.image != null) {
		this.image.remove();
	}
	
	this.image = dbmap.addImg(src);
	this.image.css({ width: dbmap.w, height: dbmap.h });
	this.image.css({ position: "absolute", top: 0, left: 0, zIndex: level });
	
	if (!this.props.visible)
		this.hideImages(dbmap);
}

SingleRequestWMSLayer.prototype.hideImages = function(dbmap) {
	if (this.image != null) {
		this.image.css("display", "none");
	}
}

SingleRequestWMSLayer.prototype.src = function(bbox, width, height) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + width + "&HEIGHT=" + height;
	url += "&BBOX=" + bbox.xmin + "," + bbox.ymin + "," + bbox.xmax + "," + bbox.ymax;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}
function SingleRequestOnGridWMSLayer(props) {
	SingleRequestWMSLayer.call(this, props);

	this.lastGridBox = null;
}

SingleRequestOnGridWMSLayer.prototype = new SingleRequestWMSLayer();

SingleRequestOnGridWMSLayer.prototype.repaint = function(dbmap, level) {
	var topLeftTile = dbmap.mapGrid.grid[0][dbmap.mapGrid.yNumTiles - 1];
	var bottomRightTile = dbmap.mapGrid.grid[dbmap.mapGrid.xNumTiles - 1][0];
	
	var top = topLeftTile.screenPosition.top;
	var left = topLeftTile.screenPosition.left;
	var width = dbmap.mapGrid.xNumTiles * dbmap.tileSize;
	var height = dbmap.mapGrid.yNumTiles * dbmap.tileSize;
	
	var gridBox = new BBox({ 
		xmin: topLeftTile.x, 
		ymin: bottomRightTile.y,
		xmax: bottomRightTile.x, 
		ymax: topLeftTile.y });
	
	if (this.lastGridBox == null || !this.lastGridBox.equals(gridBox)) {
		var src = this.src({ 
			xmin: topLeftTile.bbox.xmin, 
			ymin: bottomRightTile.bbox.ymin, 
			xmax: bottomRightTile.bbox.xmax, 
			ymax: topLeftTile.bbox.ymax 
		}, width, height);
				
		if (this.image != null) {
			this.image.remove();
		}
		this.image = dbmap.addImg(src);
		this.image.css({ width: width, height: height });
		this.lastGridBox = gridBox;
	} else {
		this.image.css("display", "");
	}
	
	this.image.css({ position: "absolute", top: top, left: left, zIndex: level });
}/**
 * @class Map Overview
 */
function MapOverview(dbmap, props) {
	this.props = props;
	this.gui = $('<div id="mapOverview"/>');

	var unitsPerPixel = (this.props.xmax - this.props.xmin) / this.props.width;
	this.unitsPerPixel = unitsPerPixel;
	
	this.props.width  = Math.round((this.props.xmax - this.props.xmin) / this.unitsPerPixel);
	this.props.height = Math.round((this.props.ymax - this.props.ymin) / this.unitsPerPixel);
	
	this.props.xmax = this.props.width  * this.unitsPerPixel + this.props.xmin;
	this.props.ymax = this.props.height * this.unitsPerPixel + this.props.ymin;
	
	this.gui.css({ position: "absolute", top: (dbmap.h - this.props.height), left: (dbmap.w - this.props.width) });
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(this.props.layers);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + this.props.width + "&HEIGHT=" + this.props.height;
	url += "&BBOX=" + this.props.xmin + "," + this.props.ymin + "," + this.props.xmax + "," + this.props.ymax;	
	
	this.map = $('<img src="' + url + '" width="' + this.props.width + '" height="' + this.props.height + '"/>');
	this.map.css({ margin: 0, padding: 0, border: 0 });

	var currentViewDiv = $('<img src="' + dbmap.emptyImg() + '"/>').css({ margin: 0, padding: 0, border: '1px solid #BB0000', 
		position: 'absolute', width: (this.props.width - 1), height: (this.props.height - 1), top: 0, left: 0 });
	
	currentViewDiv.draggable({
	  containment: 'parent',
	  stop: function(event, ui) {
	  	var position = currentViewDiv.position();
	  	var x = props.xmin + position.left * unitsPerPixel + parseInt(currentViewDiv.css('width')) * unitsPerPixel / 2;
	  	var y = props.ymax - position.top * unitsPerPixel - parseInt(currentViewDiv.css('height')) * unitsPerPixel / 2;
	  	
	  	dbmap.panToPoint(x, y);
	  }
	});
	
	this.gui.append(this.map);
	this.gui.append(currentViewDiv);
	this.currentViewDiv = currentViewDiv;
}

/**
 * Restituisce il DIV contenente la mappa
 */
MapOverview.prototype.getGUI = function() {
	return this.gui;
};

/**
 * Aggiorna il DIV che evidenzia la porzione di mappa visualizzata
 * 
 * @param dbmap un'istanza di DbMAP
 */
MapOverview.prototype.updateViewDiv = function(dbmap) {
	var xmin = dbmap.mapGrid.currentView.xmin;
	var ymin = dbmap.mapGrid.currentView.ymin;
	var xmax = dbmap.mapGrid.currentView.xmax;
	var ymax = dbmap.mapGrid.currentView.ymax;

	if (xmin < this.props.xmin) xmin = this.props.xmin;
	if (ymin < this.props.ymin) ymin = this.props.ymin;
	if (xmax > this.props.xmax) xmax = this.props.xmax;
	if (ymax > this.props.ymax) ymax = this.props.ymax;

	var visible = xmin <= xmax && ymin <= ymax;

	if (visible) {
		var width  = Math.round((xmax - xmin) / this.unitsPerPixel);
		var height = Math.round((ymax - ymin) / this.unitsPerPixel);
	
		if (width < 5) width = 5;
		if (height < 5) height = 5;
		
		var top = Math.round((this.props.ymax - ymax) / this.unitsPerPixel);
		var left = Math.round((xmin - this.props.xmin) / this.unitsPerPixel);
		
		this.currentViewDiv.css({ width: width, height: height, top: top, left: left, display: "" });
	} else {
		this.currentViewDiv.css({ display: "none" });
	}
};

/**
 * @private
 */
MapOverview.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;
	this.updateViewDiv(evt.dbmap);
	
	this.gui.css({ position: "absolute", top: (dbmap.h - this.props.height), left: (dbmap.w - this.props.width) });
};/**
 * @class Scalimetro
 * 
 * @param dbmap un'istanza di DbMAP
 * @param unitOfMeasure unit&agrave; di misura
 */
function Scalimeter(dbmap, unitOfMeasure) {
	this.gui = $("<div/>").css({ position: "absolute", top:-50, left:0 });
	this.labelDiv = $("<div/>").css({ position: "absolute", top: 0, left: 6, height:"12px", width: "100px", color: "#000000" });
	this.labelDiv.css("text-align", "center");
	this.labelDiv.css("font-size", "10px");
	this.labelDiv.css("font-weight", "bold");
	this.labelDiv.css("font-family", "Verdana, Arial");
	
	this.labelBoxDiv = $("<div/>").css({ position: "absolute", top: 0, left: 0, height:"12px", width: "100px", color: "#000000", background: "#ffffff", opacity: 0.8 });
	
	this.leftDiv = $("<div/>").css({ position:"absolute", top: 5, left: 2, height:"20px", width:"3px" });
	this.leftDiv.css("background-repeat", "repeat-y");
	this.leftDiv.css("background-position", "left");
	this.leftDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-vert.gif)");

	this.centerDiv = $("<div/>").css({ position:"absolute", top: 5, left:4, height:"20px", width:"3px" });
	this.centerDiv.css("background-repeat", "repeat-x");
	this.centerDiv.css("background-position", "center");
	this.centerDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-center.gif)");
	
	this.rightDiv = $("<div/>").css({ position:"absolute", top: 5, left:150, height:"20px", width:"3px" });
	this.rightDiv.css("background-repeat", "repeat-y");
	this.rightDiv.css("background-position", "left");
	this.rightDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-vert.gif)");
	
	this.unit = unitOfMeasure || "m";
	this.refLen = 100;
	
	this.gui.append(this.labelBoxDiv).append(this.labelDiv)
			.append(this.leftDiv).append(this.rightDiv).append(this.centerDiv);
}

Scalimeter.prototype.getGUI = function() {
	return this.gui;
};

Scalimeter.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;

	var dbmap = evt.dbmap;
	
	// Calcolo lunghezze in px e mt (a step di 1, 2, 5) 
	var val = this.refLen / dbmap.mapGrid.pixelValue;
	var exp = 0, mult = 1;
	while (val > (mult * Math.pow(10, exp))) {
		switch (mult) {
		case 1:
			mult = 2;
			break;
		case 2:
			mult = 5;
			break;
		case 5:
			mult = 1;
			exp++;
			break;
		}
	}
	
	var lenMt = mult * Math.pow(10, exp);
	var lenPx = Math.round(lenMt * this.refLen / val);
	
	var y = dbmap.h - 25;
	var x = 5;

	this.gui.css({ top: y - 5, left: x - 2, width: lenPx + 8, height: 28 });
	
	this.labelBoxDiv.css({ width: lenPx + 8, height: 28 });
	
	//this.leftDiv.css({ top: y, left: x });
	//this.centerDiv.css({ top: y, left: x + 2, width: lenPx });
	//this.rightDiv.css({ top: y, left: x + lenPx + 1 });
	//this.labelDiv.html(lenMt + " " + this.unit).css({ top: y - 5, left: x + 4, width: lenPx - 4 });
	
	this.centerDiv.css({ width: lenPx });
	this.rightDiv.css({ left: 2 + lenPx + 1 });
	this.labelDiv.html(lenMt + " " + this.unit).css({ width: lenPx - 4 });
	
};/**
 * @class Zoom Slider
 * 
 * @param dbmap un'istanza di DbMAP
 */
function ZoomSlider(dbmap) {
	this.gui = $('<div id="zoomSliderContainer"/>');
	this.gui.css({ position: "absolute", top: 0, left: 0 });	
	
	this.dbmap = dbmap;
	this.maxZ = dbmap.mapGrid.maxZ;
	this.z = dbmap.mapGrid.z;
	
	// orig
/*	
	this.offsetTop = 20;
	this.offsetLeft = 20;
	this.zoombarH = 11;
	this.zoombarW = 18;
	this.zoomButtonH = 18;
*/
	// changed
	this.offsetTop = 60;
	this.offsetLeft = 20;
	this.zoombarH = 19;
	this.zoombarW = 48;
	this.zoomButtonH = 48;
	
	
	// dimensioni: w 18, h 18
	this.zoomInButton = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoom-plus-mini.gif" style="margin:0; padding:0"/>').click(function() {
		dbmap.zoomIn();
	});
	this.zoomInButton.css({ position: "absolute", top: this.offsetTop, left: this.offsetLeft });
	this.gui.append(this.zoomInButton);
	
	for (var i = 0; i <= this.maxZ; i++) {
		// dimensioni: w 18, h 11
		var zoombar = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoombar.gif" style="margin:0; padding:0"/>');
		zoombar.css({ position: "absolute", top: (i * this.zoombarH + this.zoomButtonH + this.offsetTop), left: this.offsetLeft });
		
		if (this.z == i) {
			// dimensioni: w 20, h 9
			this.slider = $('<img src="' + dbmap.getImageDir() + '/dbmap/slider.gif" id="zoomSlider" style="margin:0; padding:0"/>');
			this.updateSliderPosition(this.slider, this.z);
			this.gui.append(this.slider);
		}
		
		this.gui.append(zoombar);
	}
	
	// dimensioni: w 18, h 18
	this.zoomOutButton = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoom-minus-mini.gif" style="margin:0; padding:0"/>').click(function() {
		dbmap.zoomOut();
	});
	this.zoomOutButton.css({ position: "absolute", top: ((this.maxZ + 1) * this.zoombarH + this.zoomButtonH + this.offsetTop), left: this.offsetLeft });
	this.gui.append(this.zoomOutButton);
}

ZoomSlider.prototype.initDraggingSupport = function() {
	var final_this = this;
	
	var sliderOffset = this.slider.offset();
	
	this.slider.draggable({ 
	  containment: [
		sliderOffset.left, 
		this.zoomInButton.offset().top + this.zoomButtonH - 1, 
		sliderOffset.left, 
		this.zoomOutButton.offset().top - this.zoombarH + 1],
	  grid: [ 1, this.zoombarH ],
	  stop: function(event, ui) {  
	  	var newZoom = Math.round((final_this.zoomOutButton.offset().top - final_this.slider.offset().top) / final_this.zoombarH) - 1;
	  	final_this.dbmap.zoomToLevel(newZoom, true, true);
	  }
	});
};

ZoomSlider.prototype.getGUI = function() {
	return this.gui;
};

ZoomSlider.prototype.updateSliderPosition = function(slider, zoom) {
	slider.css({ position: "absolute", top: ((this.maxZ - zoom) * this.zoombarH + this.zoomButtonH + this.offsetTop + 1), left: (this.offsetLeft - 1), zIndex: 1 });
};

ZoomSlider.prototype.updateViewDiv = function(dbmap) {
	if (this.z != dbmap.mapGrid.z) {	
		this.z = dbmap.mapGrid.z;
		this.updateSliderPosition(this.slider, this.z);
	}
};

ZoomSlider.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;
	this.updateViewDiv(evt.dbmap);
};
/**
 * 
 * @class Whiteboard
 */
function Whiteboard(dbmap) {
	this._dbmap = dbmap;
	
	this._listener = null;	
	
	this._jg = new jsGraphics($(dbmap.map).get(0));
	this._jg.setColor('#0000ff');
	this._jg.setStroke(2);

	this._MODE_APPEND = '_MODE_APPEND';	
	this._MODE_MOVE = '_MODE_MOVE';
	this._MODE_INSERT = '_MODE_INSERT';
	this._MODE_DELETE = '_MODE_DELETE';
	this._mode = '';
	
	this._type = null;
	
	this._id = null;
	this._points = new Array();	
}

Whiteboard.prototype.setColor = function(color) {
	this._jg.setColor(color);
}

Whiteboard.prototype.setStroke = function(stroke) {
	this._jg.setStroke(stroke);
}

Whiteboard.prototype.addListener = function(listener) {
	this._listener = listener;
}

Whiteboard.prototype.add = function(type) {
	this.clear();
	this._mode = this._MODE_APPEND;
	this._type = type;	
}

Whiteboard.prototype.edit = function(type, id, points) {
	this.clear();
	this._type = type;
	this._id = id;
	this._points = points;
	this._mode = this._MODE_MOVE;
	this.repaint();		
}

Whiteboard.prototype.appendVertex = function() {
	this._mode = this._MODE_APPEND;
}

Whiteboard.prototype.moveVertex = function() {
	this._mode = this._MODE_MOVE;
}

Whiteboard.prototype.insertVertex = function() {
	this._mode = this._MODE_INSERT;	
}

Whiteboard.prototype.deleteVertex = function() {
	this._mode = this._MODE_DELETE;	
}

Whiteboard.prototype.stop = function() {
	this._mode = '';
}

Whiteboard.prototype.getId = function() {
	return this._id;
}

Whiteboard.prototype.getType = function() {
	return this._type;
}

Whiteboard.prototype.getPoints = function() {
	if (this._points.length > 0) {
		return this._points;
	} else {
		return null;
	}
}

Whiteboard.prototype.onClick = function(mapPoint) {
	if (this._mode == this._MODE_APPEND || (this._mode == this._MODE_INSERT && this._points.length < 2)) {
		if (this._type == DbMAPEntity.POINT) {
			this._points[0] = mapPoint;
		} else {
			this._points[this._points.length] = mapPoint; 					
		}
 	} else if (this._mode == this._MODE_MOVE && this._points.length > 0) {
		var nearestPoint = this.findNearestPoint(mapPoint);
		this._points[nearestPoint.index] = mapPoint;
 	} else if (this._mode == this._MODE_INSERT) {
		if (this._type == DbMAPEntity.POINT) {
			this._points[0] = mapPoint;
		} else {
			var nearestMedianPoint = this.findNearestMedianPoint(mapPoint);
			this._points.splice(nearestMedianPoint.index, 0, mapPoint);
		}
 	} else if (this._mode == this._MODE_DELETE && this._points.length > 0) {
		var nearestPoint = this.findNearestPoint(mapPoint); 		
		this._points.splice(nearestPoint.index, 1);
 	}
 	
 	if (this._mode != '') {
		this.repaint();
		if (this._listener != null) this._listener.onClick(mapPoint);
 	}
}

Whiteboard.prototype.clear = function() {
	this._jg.clear();
	
	this._mode = '';
	this._type = '';
	this._id = null;
	this._points = new Array();
}

Whiteboard.prototype.repaint = function(new_bbox) {
	this._jg.clear();
	
	if (this._type == DbMAPEntity.POINT) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		}
	} else if (this._type == DbMAPEntity.LINE) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		} else if (this._points.length > 1) {
			this.drawMapPoint(this._points[0]);
			for (var i = 1; i < this._points.length; i++) {
				this.drawMapPoint(this._points[i]);
				this.drawMapLine(this._points[i - 1], this._points[i]);			
			}		
		}
	} else if (this._type == DbMAPEntity.POLYGON) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		} else if (this._points.length == 2) {
			this.drawMapPoint(this._points[0]);
			this.drawMapPoint(this._points[1]);
			this.drawMapLine(this._points[0], this._points[1]);			
		} else if (this._points.length > 2) {
			this.drawMapPolygon(this._points);			
		}
	}
	
	if (this._points.length > 0 && this._type != '') {
		this._jg.paint();
	}
}

/**
 * @private
 */
Whiteboard.prototype.findNearestPoint = function(mapPoint) {
	if (this._points.length == 1) {
		return { distance: -1, index: 0 };
	}
	
	var nearestPoint = null;
	for (var i = 0; i < this._points.length; i++) {	
		var distance = this._dbmap.getDistance(this._points[i], mapPoint);
		if (nearestPoint == null || distance < nearestPoint.distance) {
			nearestPoint = { distance: distance, index: i };
		}
	}
	return nearestPoint;
}

/**
 * @private
 */
Whiteboard.prototype.findNearestMedianPoint = function(mapPoint) {
	var nearestPoint = null;
	for (var i = 0; i < this._points.length; i++) {
		var start = i;
		var end = i+1;
		if (end == this._points.length) end = 0;
		
		var medianPoint = this.getMedianPoint(this._points[start], this._points[end]);
		var distance = this._dbmap.getDistance(medianPoint, mapPoint);
		if (nearestPoint == null || distance < nearestPoint.distance) {
			nearestPoint = { distance: distance, index: i+1 };
		}
	}
	return nearestPoint;
}

/**
 * @private
 */
Whiteboard.prototype.getMedianPoint = function(p1, p2) {
	var xm = (p1.x + p2.x) / 2;
	var ym = (p1.y + p2.y) / 2;
	return { x: xm, y: ym };
}

/**
 * @private
 */
Whiteboard.prototype.drawMapPoint = function(mapPoint) {
	var screenPoint = this._dbmap.mapGrid.mapToScreen(mapPoint.x, mapPoint.y, false);
	if (screenPoint != null) {
		this._jg.fillRect(screenPoint.left - 2, screenPoint.top - 2, 5, 5);
	}
}

/**
 * @private
 */
Whiteboard.prototype.drawMapLine = function(p_from, p_to) {
	var screenPoint_from = this._dbmap.mapGrid.mapToScreen(p_from.x, p_from.y, false);
	var screenPoint_to = this._dbmap.mapGrid.mapToScreen(p_to.x, p_to.y, false);
	if (screenPoint_from != null && screenPoint_to!= null) {
		this._jg.drawLine(screenPoint_from.left, screenPoint_from.top, screenPoint_to.left, screenPoint_to.top);			
	}
}

/**
 * @private
 */
Whiteboard.prototype.drawMapPolygon = function(points) {
	var screenPoints_x = new Array();
	var screenPoints_y = new Array();
	
	for (var i = 0; i < points.length; i++) {
		this.drawMapPoint(this._points[i]);
		
		var screenPoint = this._dbmap.mapGrid.mapToScreen(points[i].x, points[i].y, true);
		screenPoints_x[screenPoints_x.length]=screenPoint.left;
		screenPoints_y[screenPoints_y.length]=screenPoint.top;
	}
	
	this._jg.drawPolygon(screenPoints_x, screenPoints_y);
}
