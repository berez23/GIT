/**
 * filename : mapresponse.js
 * version : 1.0
 * create date : 2011-05-05
 * update date : 2011-07-08
 * description : script
 */

var
	// layer list
	// m_legendI = undefined
	m_commandbar = undefined
	
	, m_strPositionbarXYId = 'positionbarxy'	// id of position bar xy
	, m_positionBarXY = null
	, m_positionBarMeasure = null
	, m_menulayer = undefined	// widget to manager layer menu

	, m_strPositionbarMeasureId = 'positionbarmeasure'	// id of position bar measure
	;


/**
 * class that initialize page
 * 
 * @returns {CInitMap}
 */
function CInitMap()
{
	
	try
	{
		// dbmapjs object
		this.m_dbmapjs = undefined;
		this.setDbMAPJS = CInitMap_setDbMAPJS;
		this.getDbMAPJS = CInitMap_getDbMAPJS; 
		
		// id of html markup for dbmapjs
		this.m_strHtmlMapId = undefined;
		this.setHtmlMapId = CInitMap_setHtmlMapId;
		this.getHtmlMapId = CInitMap_getHtmlMapId;
	
		// reference to buttons
		this.m_buttonPan = undefined;
		this.m_buttonInfo = undefined;
		this.m_button3d = undefined;
		this.m_buttonPictometry = undefined;
		this.m_buttonMeasure = undefined;
		
		this.init = CInitMap_init;
		this.initLayer = CInitMap_initLayer;
		this.initMenu = CInitMap_initMenu;
		this.initOverlay = CInitMap_initOverlay;
		this.initMarker = CInitMap_initMarker;
		this.initOverlayCommandBar = CInitMap_initOverlayCommandBar; 
	}
	catch(e)
	{
		handleException("CInitMap", e);	
	}
	
}


var
	g_initMap = new CInitMap();


/**
 * Initialize map with data in datamodel
 */
function CInitMap_init()
{
	try
	{
		var iEC;
		
		if (!isOK(this.initLayer()))
			return -2;

		if (!isOK(this.initMenu()))
			return -3;
		
		if (!isOK(this.initOverlay()))
			return -4;
		
		if (!isOK(this.initOverlayCommandBar()))
			return -5;
		
		// add map listener
		this.getDbMAPJS().addCoordinateListener(eventCoordinate);
		this.getDbMAPJS().addPickedPointListener(eventPickedPoint);
		this.getDbMAPJS().addMeasureListener(eventMeasure);
	
	// show layer list
	// m_legendI = new Legend(5, 30, 100, 200, true);
	// this.getDbMAPJS().addOverlay(m_legendI);
	
		// zoom on default view, to redraw map
		this.getDbMAPJS().zoomToWindow(
				{ xmin: g_datamodelMap.getXMin()
					, ymin: g_datamodelMap.getYMin()
					, xmax: g_datamodelMap.getXMax()
					, ymax: g_datamodelMap.getYMax()
				}
		);
	
		
		if ((iEC = this.initMarker()) <= 0)
			return -5;
		
		setTimeout(afterInit, 100);
		return 1;
	}
	catch(e)
	{
		handleException("initMap", e);
		return -1;
	}
	
	return 0;
}	// initMap



/**
 * CInitMap_setDbMAPJS
 *
 * set DbMAP object
 */
function CInitMap_setDbMAPJS(pi_objValue)
{

	try
	{
		if ("undefined" == typeof(pi_objValue))
			return -2;
		
		this.m_dbmapjs = pi_objValue;
		return 1;
	}
	catch(e)
	{
		handleException("CInitMap_setDbMAPJS", e);
		return -2;
	}
	
}	// eof CInitMap_setDbMAPJS



function CInitMap_getDbMAPJS()
{
	return this.m_dbmapjs;
}


/*
 * set HtmlMapId
 */
function CInitMap_setHtmlMapId(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strHtmlMapId = pi_strValue;
	return 1;
}


function CInitMap_getHtmlMapId()
{
	return this.m_strHtmlMapId;
}



/**
 * initialize all layers in map
 *
 */
function CInitMap_initLayer()
{

	try
	{
		// scan all layers in data model and add layer to dbmapjs
		var iIterLayer
			, iIterLayerMax = g_datamodelMap.getLayerInfoCount();
		
		// scan all layers
		for (iIterLayer = 0; iIterLayer < iIterLayerMax; ++iIterLayer)
		{
			// get current layer to work with
			var layerInfoCurrent = g_datamodelMap.getLayerInfo(iIterLayer);
			

			//
			// create array with all layer item name
			//
			
			// hold all layer item
			var aDbMAPLayerItem = []
				, iIterItem
				, iIterItemMax = layerInfoCurrent.getItemCount();
			
			// scan all items
			for (iIterItem = 0; iIterItem < iIterItemMax; ++iIterItem)
			{
				var layerItemNew = { name: layerInfoCurrent.getItem(iIterItem)
					, visible: true // if set to false error on startup
					, default_theme_name: ''
					, themes: [] }; 
		
				// add to array
				aDbMAPLayerItem.push(layerItemNew);
			}	// for scan item
		
			//
			// create a dbmap layer
			//
			var strSRS = undefined;
			// is SRS (geo system reference) has been supplied set to layer
			if ("undefined" != typeof(layerInfoCurrent.getLayerSRS()))
				strSRS = layerInfoCurrent.getLayerSRS();
			
			var layerNew = new SingleRequestWMSLayer({
				// layer name in dbmapjs control
				name: layerInfoCurrent.getLayerName()
				// wms url
				, url: layerInfoCurrent.getLayerURL()
				// immagini trasparenti
				, transparent: true
				// image background color
				, bgcolor: '0xffffff'
				// level requested
				, layers: aDbMAPLayerItem
				// formato di immagine richiesto
				, format: layerInfoCurrent.getLayerFormat()
				, srs : strSRS
				, zoomMin: layerInfoCurrent.getLayerZoomIn()
				, zoomMax: layerInfoCurrent.getLayerZoomOut()
				});


			// if first layer been processed, create dbmap control
			if (0 == iIterLayer)
			{
				var dbmapjs = new DbMAP(this.getHtmlMapId()
					, 512
					, 128	// = layermulti.tileserver_unitsperpixelonzoomzero
					, 15	// <= layermulti.tileserver_maxzoom (meglio se uguale)
					, layerNew 
					, { xmin: g_datamodelMap.getXMin()
						, ymin: g_datamodelMap.getYMin()
						, xmax: g_datamodelMap.getXMax()
						, ymax: g_datamodelMap.getYMax()
					}
				);
				
				// set reference to new control
				if (this.setDbMAPJS(dbmapjs) <= 0)
					return -2;

				// initialize dimension control
				setDbMAPsize();
				
			}	// first layer
			else
			{
				// add layer to dbmapjs control
				this.getDbMAPJS().addLayer(layerNew);
			}
			
			// set index in dbmapjs in layer info 
			layerInfoCurrent.setDbMAPIndex(this.getDbMAPJS().layers.length -1);
		}	// for scan layer
		
		return 1;
	}
	catch(e)
	{
		handleException("initMapLayer", e);
		return -1;
	}
	
}	// eof initMapLayer



/**
 * CInitMap_initMenu
 *
 * initialize menu items from layer's info
 */
function CInitMap_initMenu()
{

	try
	{

		//
		// add menu for layer
		//
		var menulayerConfig = new CMenuLayerConfig();
		menulayerConfig.setHtmlMapId(g_initMap.getHtmlMapId());
		
		m_menulayer = new CMenuLayer(menulayerConfig);
		if ((iEC = m_menulayer.buildUI()) <= 0)
			return -3;
		
		// add listener for item click event
		m_menulayer.setEventItemClicked(menulayer_eventItemClicked);
		
		var iIterLayer
			, iIterLayerMax = g_datamodelMap.getLayerInfoCount();
		
		// scan layers
		for (iIterLayer = 0; iIterLayer < iIterLayerMax; ++iIterLayer)
		{
			var layerInfoCurrent = g_datamodelMap.getLayerInfo(iIterLayer);
			
			// add menu items
			var menuLayerItem = new CMenuLayerItem();
			menuLayerItem.ID = layerInfoCurrent.getDbMAPIndex();
			menuLayerItem.name = layerInfoCurrent.getMenuName();
			menuLayerItem.checked = layerInfoCurrent.getLayerVisible();
			
			if (m_menulayer.addItem(menuLayerItem) <= 0)
				return -2;
		}	// for scan layers
		
		g_datamodelMap.setEventLayerVisibleChanged(controllergis_eventLayerVisibleChanged);
		
		this.getDbMAPJS().addOverlay(m_menulayer);
		
		return 1;
	}
	catch(e)
	{
		handleException("CInitMap_initMenu", e);
		return -1;
	}
	
}	// eof CInitMap_initMenu


/**
 * CInitMap_initOverlay
 *
 * initialize all overlays
 */
function CInitMap_initOverlay()
{

	try
	{
		// slider
		var zoomSlider= new ZoomSlider(this.getDbMAPJS());
		this.getDbMAPJS().addOverlay(zoomSlider);
		zoomSlider.initDraggingSupport();
		// reposition Slider control
		zoomSlider.gui.css({ position: "relative", top: 25, left: -10 });
	
		
		// add position bar for current position
		m_positionBarXY = new CPositionBar(g_initMap.getHtmlMapId(), m_strPositionbarXYId, 300, 25);
		m_positionBarXY.setEventChangePosition(positionBarXY_eventChangePosition);
		m_positionBarXY.buildUI();
		this.getDbMAPJS().addOverlay(m_positionBarXY);
		

		// add position bar for measure
		m_positionBarMeasure = new CPositionBar(g_initMap.getHtmlMapId(), m_strPositionbarMeasureId, 300, 25, false);
		m_positionBarMeasure.buildUI();
		this.getDbMAPJS().addOverlay(m_positionBarMeasure);

		return 1;
	}
	catch(e)
	{
		handleException("CInitMap_initOverlay", e);
		return -1;
	}
	
}	// eof CInitMap_initOverlay



/**
 * CInitMap_initOverlayCommandBar
 *
 * intialize overlay of commanbar
 */
function CInitMap_initOverlayCommandBar()
{

	try
	{
		// command bar
		m_commandbar = new CCommandBar(this.getDbMAPJS());

		//
		// add single buttons
		//
		
		//
		// button pan
		//
		this.m_buttonPan = new CCommandBarButton();
		
		if (!isOK(this.m_buttonPan.setId("kbtnPan")))
			return -2;
		
		if (!isOK(this.m_buttonPan.setImageURL("../viewerjs/gis/images/pan.gif")))
			return -2;
		
		if (!isOK(this.m_buttonPan.setToolTip("Pan")))
			return -2;

		if (!isOK(m_commandbar.addButton(this.m_buttonPan)))
			return -3;
		
		
		//
		// button info
		//
		this.m_buttonInfo = new CCommandBarButton();
		
		if (!isOK(this.m_buttonInfo.setId("kbtnInfo")))
			return -2;
		
		if (!isOK(this.m_buttonInfo.setImageURL("../viewerjs/gis/images/info.gif")))
			return -2;
		
		if (!isOK(this.m_buttonInfo.setToolTip("Info")))
			return -2;
		
		if (!isOK(m_commandbar.addButton(this.m_buttonInfo)))
			return -3;

	
		//
		// threeDimensional 
		//
		
		// check if need to add threeDimensional button
		if ("string" == typeof(g_datamodelMap.getThreeDimensionalURL()))
		{
			// button measure
			this.m_button3d = new CCommandBarButton();
			
			if (!isOK(this.m_button3d.setId("kbtn3d")))
				return -2;
			
			if (!isOK(this.m_button3d.setImageURL("../viewerjs/gis/images/3d.gif")))
				return -2;
			
			if (!isOK(this.m_button3d.setToolTip("3d")))
				return -2;
			
			if (!isOK(m_commandbar.addButton(this.m_button3d)))
				return -3;
		}

		
		//
		// pictometry 
		//
		
		// check if need to add pictometry button
		if ("string" == typeof(g_datamodelMap.getPictometryURL()))
		{
			// button measure
			this.m_buttonPictometry = new CCommandBarButton();
			
			if (!isOK(this.m_buttonPictometry.setId("kbtnPictometry")))
				return -2;
			
			if (!isOK(this.m_buttonPictometry.setImageURL("../viewerjs/gis/images/picto.gif")))
				return -2;
			
			if (!isOK(this.m_buttonPictometry.setToolTip("Pictometry")))
				return -2;
			
			if (!isOK(m_commandbar.addButton(this.m_buttonPictometry)))
				return -3;
		}
		
		//
		// button measure
		//
		this.m_buttonMeasure = new CCommandBarButton();
		
		if (!isOK(this.m_buttonMeasure.setId("kbtnMeasure")))
			return -2;
		
		if (!isOK(this.m_buttonMeasure.setImageURL("../viewerjs/gis/images/ruler.gif")))
			return -2;
		
		if (!isOK(this.m_buttonMeasure.setToolTip("Measure")))
			return -2;
		
		if (!isOK(m_commandbar.addButton(this.m_buttonMeasure)))
			return -3;

		
		m_commandbar.setEventButtonClicked(notifyCommandBar_EventButtonClicked);

		// first create UI
		m_commandbar.buildUI();
		this.getDbMAPJS().addOverlay(m_commandbar);
		//m_commandbar.setVisible(true);
		
		return 1;
	}
	catch(e)
	{
		handleException("CInitMap_initOverlayCommandBar", e);
		return -1;
	}
	
}	// eof CInitMap_initOverlayCommandBar


/**
 * CInitMap_initMarker
 *
 * add a marker to central view
 */
function CInitMap_initMarker()
{

	try
	{
	
		// add marker to particella's centroid
		var markerImg = $("<DIV><img src='images/dbmap/marker.png'/></DIV>");
		markerImg.css({ margin: "0px", padding: "0px", border: "0px none"});
		markerImg.css("-moz-user-select", "none");
		
		var iMarkerId = 1;
		var markerI = new Marker(markerImg, 26, 12
				, "img_" + iMarkerId, g_datamodelMap.getXCenter(), g_datamodelMap.getYCenter());
		markerI.theId = iMarkerId;
		markerI.tooltipText = "Punto centrale";
		this.getDbMAPJS().addMarker(markerI);
		
		return 1;
	}
	catch(e)
	{
		handleException("CInitMap_initMarker", e);
		return -1;
	}
	
}	// eof CInitMap_initMarker


//
// function called when a click on map is done by user
// when user click on a point try to open window on that paritcella
//
var
	m_windowopen;


function eventPickedPoint(coord)
{
	var strURL = g_datamodelMap.getInfoURL()
		+ "&x=" + coord.x
		+ "&y=" + coord.y
		+ "&" + g_datamodelMap.getRequestPropValue();	// append request url parameter
	
	m_windowopen = window.open(strURL, "Info", g_utilProject.getWindowDefatulParam(800, 600));
	setTimeout(windowopenFocus, 100);
}	// eventPickedPoint


function windowopenFocus()
{
	if (undefined != m_windowopen)
		m_windowopen.focus();
}

//
//	fired when map's coordinates changes
//
function eventCoordinate(coord)
{
	var strHTML = 'x: ' + roundTo(coord.x,5) 
		+ '&nbsp;y: ' + roundTo(coord.y,5) 
		//+ '&nbsp;zoom: ' + g_initMap.getDbMAPJS().mapGrid.getZoomLevel()
		;  
		
	$("#" + m_strPositionbarXYId).html(strHTML);
}	// eventCoordinate


//
// display measure information
//
function eventMeasure(measure)
{
	var strHTML = "Perim.: " + (roundTo(measure.length, 2)) + "m" 
		+ "&nbsp;Area: " + (roundTo(measure.area, 2)) + "mq";
	
	$("#" + m_strPositionbarMeasureId).html(strHTML);
}


/**
 * notification of button clicked
 */
function notifyCommandBar_EventButtonClicked(pi_this)
{
	if ("undefined" == typeof(pi_this))
		return -2;
	
	var iIdxButtonCurrent = pi_this.getIndexButtonCurrent();
	var bWinMeasureVisible = false;

	switch (iIdxButtonCurrent)
	{
		case g_initMap.m_buttonPan.getIndex():
			g_initMap.getDbMAPJS().setMode(DbMAPMode.PAN);
			break;
		
			
		case g_initMap.m_buttonInfo.getIndex():
			g_initMap.getDbMAPJS().setMode(DbMAPMode.PICK_POINT);
			break;
			

		case g_initMap.m_button3d.getIndex():
			openWindow(g_datamodelMap.getThreeDimensionalURL());
			m_commandbar.setIndexButtonCurrent(g_initMap.m_buttonInfo.getIndex());
			break;

		
		case g_initMap.m_buttonPictometry.getIndex():
			openWindow(g_datamodelMap.getPictometryURL());
			m_commandbar.setIndexButtonCurrent(g_initMap.m_buttonInfo.getIndex());
			break;

		case g_initMap.m_buttonMeasure.getIndex():
			g_initMap.getDbMAPJS().setMode(DbMAPMode.MEASURE);
		
			$("#" + m_strPositionbarMeasureId).html('');	// reset content
			bWinMeasureVisible = true;
			break;

	}	// switch
	
	m_positionBarMeasure.setVisible(bWinMeasureVisible);
	return 1;
}	// notifyCommandBar_EventButtonClicked



function afterInit()
{
	try
	{
		m_positionBarMeasure.setVisible(false);// do not function in init
		
		// set current button
		if (!isOK(m_commandbar.setIndexButtonCurrent(g_initMap.m_buttonPan.getIndex())))
			alert("m_commandbar.setIndexButtonCurrent");
		
		g_initMap.getDbMAPJS().zoomToLevel(7, true, true);	// set zoom level
		
		// NOTE [...] set layer visibility on each layer
		// NOTE done here because if adding a layers with visible=false will cause error
		
		var iIterLayer
			, iIterLayerMax = g_datamodelMap.getLayerInfoCount();
		for (iIterLayer = 0; iIterLayer < iIterLayerMax; ++iIterLayer)
		{
			var layerInfo = g_datamodelMap.getLayerInfo(iIterLayer);
			g_controllerMap.setLayerVisible(iIterLayer, layerInfo.getLayerVisible());
		}	// scan layer
	}
	catch(e)
	{
		handleException("afterInit", e);
	}
}



/**
 * funzione richiamata ogni volta che la pagina che contiene la mappa viene ridimensionata
 */
function onDocResize()
{
	setDbMAPsize();
	//m_legendI.setVisible(true);
}



/**
 * funzione utilizzata per impostare le dimensioni del controllo "mappa" e degli oggetti che lo devono contenere
 */
function setDbMAPsize()
{
	var iDocWidth = document.body.clientWidth
		, iDocHeight = document.body.clientHeight;
	
	$("#" + g_initMap.getHtmlMapId()).css( { width : iDocWidth, height : iDocHeight } );
		
	if ("undefined" == typeof(g_initMap.getDbMAPJS()))
		return;
	
	g_initMap.getDbMAPJS().setSize(iDocWidth, iDocHeight);
}


/**
 * arrotonda un numero tenendo "decimalpositions" decimali
 * 
 * @param number
 * @param decimalpositions
 * @returns {Number}
 */
function roundTo(number, decimalpositions)
{
	var i = number * Math.pow(10,decimalpositions);
	i = Math.round(i);
	return i / Math.pow(10,decimalpositions);
}



//
// called when an item menu is clicked
//
function menulayer_eventItemClicked(pi_ID)
{
	try
	{
		// notify controller to change layer visibility
		g_controllerMap.toggleLayerVisible(pi_ID);
		return 1;
	}
	catch(e)
	{
		handleException('menulayer_eventItemClicked', e);
		return -1;
	}
	
	return 0;
}	// menulayer_eventItemClicked



//
// callback from controller that specified layer visible property has changed
//
function controllergis_eventLayerVisibleChanged(pi_ID)
{
	try
	{
		// change visibility in map
		var layerInfo = g_datamodelMap.getLayerInfo(pi_ID);
		
		g_initMap.getDbMAPJS().layers[layerInfo.getDbMAPIndex()].setVisible(layerInfo.getLayerVisible());
		g_initMap.getDbMAPJS().repaint();
		
		// change check state in menu
		m_menulayer.setItemCheck(pi_ID, layerInfo.getLayerVisible());
		return 1;
	}
	catch(e)
	{
		handleException('controllergis_eventLayerVisibleChanged', e);
		return -1;
	}
	
	return 0;
}	// controllergis_eventLayerVisibleChanged


//
// fired when control need to change it's position from default
//
function positionBarXY_eventChangePosition(pi_positionBarControl)
{
	try
	{
		// get map ui position
		var uiPosition = g_utilProject.getUIPosition(g_initMap.getHtmlMapId());
		if (undefined == uiPosition)
			return -2;
		
		pi_positionBarControl.setLeft(uiPosition.left +5);
		pi_positionBarControl.setTop(uiPosition.height - pi_positionBarControl.getHeight() -10);
		
		if (undefined == m_positionBarMeasure)
			return -3;
		
		// change also position of position measure, above this one
		m_positionBarMeasure.setLeft(uiPosition.left +5);
		m_positionBarMeasure.setTop(pi_positionBarControl.getTop() - m_positionBarMeasure.getHeight() - 10);
		m_positionBarMeasure.setWidth(pi_positionBarControl.getWidth());
		return 1;
	}
	catch(e)
	{
		handleException('positionBarXY_eventChangePosition', e);
		return -1;
	}
	
	return 0;
}	// positionBarXY_eventChangePosition



/**
 * open specified url with center coordinates and bounding box
 * 
 * @param pi_strURL
 */
function openWindow(pi_strURL)
{
	var strURL;

	var dX = (g_initMap.getDbMAPJS().mapGrid.currentView.xmin + g_initMap.getDbMAPJS().mapGrid.currentView.xmax) /2
		, dY = (g_initMap.getDbMAPJS().mapGrid.currentView.ymin + g_initMap.getDbMAPJS().mapGrid.currentView.ymax) /2
		;
	
	strURL = pi_strURL
		+ "&x=" + dX
		+ "&y=" + dY
		+ "&xmin=" + g_initMap.getDbMAPJS().mapGrid.currentView.xmin
		+ "&ymin=" + g_initMap.getDbMAPJS().mapGrid.currentView.ymin
		+ "&xmax=" + g_initMap.getDbMAPJS().mapGrid.currentView.xmax
		+ "&ymax=" + g_initMap.getDbMAPJS().mapGrid.currentView.ymax
		;

	window.open(strURL, "open");
}
