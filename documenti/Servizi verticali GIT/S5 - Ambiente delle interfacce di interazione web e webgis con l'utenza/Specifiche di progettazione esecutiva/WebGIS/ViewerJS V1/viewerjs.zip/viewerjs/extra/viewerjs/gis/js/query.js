/**
 * filename: query.js 
 * author: CALEFFI Andrea 
 * create : 2011-07-13
 * update version: 2011-07-13 
 * version: 1.0 
 * description: perform query to remote server
 * for document editing
 */


/**
 * Object that peform query
 */
function CQuery()
{
	// base url for query
	this.m_strBaseURL = undefined;
	this.setBaseURL = CQuery_setBaseURL;

	// event fired when query is completed
	this.m_eventQueryCompleted = undefined;
	this.setEventQueryCompleted = CQuery_setEventQueryCompleted;
	
	// set handler for QueryJSON
	this.queryJSON = handlerQueryJSON;
	

	this.query = CQuery_query;
	this.queryCompleted = CQuery_queryCompleted;
	
}


/**
 * Set base url for query
 */
function CQuery_setBaseURL(pi_strBaseURL)
{
	if ("string" != typeof(pi_strBaseURL))
		return -2;
	
	this.m_strBaseURL = pi_strBaseURL;
	return 1;
}



/**
 * Peform query using supplied parameters
 */
function CQuery_query(pi_strFieldShape, pi_strTableName, pi_strWhere)
{
	try
	{
		if ("string" != typeof(pi_strFieldShape))
			return -2;
		
		if ("string" != typeof(pi_strTableName))
			return -3;

		if ("string" != typeof(pi_strWhere))
			return -4;
		
		var strURL = this.m_strBaseURL
			+ "/extra/viewerjs/queryJson"
			+ "?id=mbr"	// query type
			+ "&fieldShape=" + escape(pi_strFieldShape)
			+ "&tableName=" + escape(pi_strTableName)
			+ "&where=" + escape(pi_strWhere); 
		
		return this.queryJSON(strURL, "queryCompleted");
	}
	catch(e)
	{
		handleException("CQuery_query", e);
		return -1;
	}
}



/**
 * Set event for client when query is completed
 */
function CQuery_setEventQueryCompleted(pi_event)
{
	this.m_eventQueryCompleted = pi_event;
	return 1;
}



/**
 * fired when query finish to read from server
 */
function CQuery_queryCompleted(pi_objI)
{
	
	try
	{
		if ("undefined" == typeof(this.m_eventQueryCompleted))
			return 1;
		
		return this.m_eventQueryCompleted(pi_objI);
	}
	catch(e)
	{
		handleException("CQuery_queryCompleted", e);
		return -1;
	}
	
}
