/**
 * filename : controllegis.js
 * version : 1.0
 * create date : 2011-05-05
 * update date : 2011-07-06
 * description : controller of application
 */

/**
 * Data model for application
 */
function CDataModelMap()
{

	// coordinate of view to be displayed
	this.m_dXMin = undefined;
	this.getXMin = CDataModelMap_getXMin;
	
	this.m_dYMin = undefined;
	this.getYMin = CDataModelMap_getYMin;
	
	this.m_dXMax = undefined;
	this.getXMax = CDataModelMap_getXMax;
	
	this.m_dYMax = undefined;
	this.getYMax = CDataModelMap_getYMax;
	
	this.setView = CDataModelMap_setView;

	// coordinate of central point where to put marker
	this.m_dXCenter = undefined;
	this.getXCenter = CDataModelMap_getXCenter;
	
	this.m_dYCenter = undefined;
	this.getYCenter = CDataModelMap_getYCenter;
	
	this.setCenter = CDataModelMap_setCenter;

	// infoURL to be used when clicking for information
	this.m_strInfoURL = undefined;
	this.setInfoURL = CDataModelMap_setInfoURL;
	this.getInfoURL = CDataModelMap_getInfoURL; 
	
	// threeDimensionalURL to be used
	this.m_strThreeDimensionalURL = undefined;
	this.setThreeDimensionalURL = CDataModelMap_setThreeDimensionalURL;
	this.getThreeDimensionalURL = CDataModelMap_getThreeDimensionalURL; 

	// pictometryURL to be used
	this.m_strPictometryURL = undefined;
	this.setPictometryURL = CDataModelMap_setPictometryURL;
	this.getPictometryURL = CDataModelMap_getPictometryURL; 
	
	// all layer info to be managed
	this.m_aLayerInfo = new Array();
	// index of next layer id
	this.m_iLayerIDNext = -1;

	this.addLayerInfo = CDataModelMap_addLayerInfo;
	this.getLayerInfoCount = CDataModelMap_getLayerInfoCount;
	this.getLayerInfo = CDataModelMap_getLayerInfo;
	
	this.setLayerVisible = CDataModelMap_setLayerVisible;

	// event notification when layer visible property is changed
	this.eventLayerVisibleChanged = undefined;
	this.setEventLayerVisibleChanged = CDataModelMap_setEventLayerVisibleChanged;
	this.fireEventLayerVisibleChanged = CDataModelMap_fireEventLayerVisibleChanged;
	this.toggleLayerVisible = CDataModelMap_toggleLayerVisible;
	
	// store prop/value key of request parameter like "key1=value1;key2=value2"
	this.m_strRequestPropValue = undefined;
	this.setRequestPropValue = CDataModelMap_setRequestPropValue;
	this.getRequestPropValue = CDataModelMap_getRequestPropValue;
}	// CDataModelMap



/**
 * CDataModelMap_setView
 *
 * set current view coordinates to be displayed
 */
function CDataModelMap_setView(pi_dXMin, pi_dYMin, pi_dXMax, pi_dYMax)
{

	try
	{
		// check values are supplied
		if ("undefined" == typeof(pi_dXMin))
			return -2;
		
		if ("undefined" == typeof(pi_dYMin))
			return -3;
	
		if ("undefined" == typeof(pi_dXMax))
			return -4;
		
		if ("undefined" == typeof(pi_dYMax))
			return -5;

		this.m_dXMin = pi_dXMin;
		this.m_dYMin = pi_dYMin;
		this.m_dXMax = pi_dXMax;
		this.m_dYMax = pi_dYMax;
		
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setView", e);
		return -1;
	}
	
}	// eof CDataModelMap_setView



/**
 * CDataModelMap_setCenter
 * 
 * set coordinates of central point
 */
function CDataModelMap_setCenter(pi_dXCenter, pi_dYCenter)
{

	try
	{
	
		if ("undefined" == typeof(pi_dXCenter))
			return -2;
		
		if ("undefined" == typeof(pi_dYCenter))
			return -3;

		this.m_dXCenter = pi_dXCenter;
		this.m_dYCenter = pi_dYCenter;
		
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setCenter", e);
		return -1;
	}
	
}	// eof CDataModelMap_setCenter



/**
 * Set infoURL
 */
function CDataModelMap_setInfoURL(pi_strValue)
{
	try
	{
		if ("undefined" == pi_strValue)
			return -2;
		
		this.m_strInfoURL = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setInfoURL", e);
		return -1;
	}
}



function CDataModelMap_getInfoURL()
{
	return this.m_strInfoURL;
}


/**
 * Set ThreeDimensionalURL
 */
function CDataModelMap_setThreeDimensionalURL(pi_strValue)
{
	try
	{
		if ("undefined" == pi_strValue)
			return -2;
		
		this.m_strThreeDimensionalURL = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setThreeDimensionalURL", e);
		return -1;
	}
}



function CDataModelMap_getThreeDimensionalURL()
{
	return this.m_strThreeDimensionalURL;
}


/**
 * Set pictometryURL
 */
function CDataModelMap_setPictometryURL(pi_strValue)
{
	try
	{
		if ("undefined" == pi_strValue)
			return -2;
		
		this.m_strPictometryURL = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setPictometryURL", e);
		return -1;
	}
}



function CDataModelMap_getPictometryURL()
{
	return this.m_strPictometryURL;
}


/**
 * Set RequestPropValue
 */
function CDataModelMap_setRequestPropValue(pi_strValue)
{
	try
	{
		if ("string" != typeof(pi_strValue))
			return -2;
		
		this.m_strRequestPropValue = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setRequestPropValue", e);
		return -1;
	}
}



function CDataModelMap_getRequestPropValue()
{
	return this.m_strRequestPropValue;
}



/**
 * add a layer to currently list of managed layers
 */
function CDataModelMap_addLayerInfo(pi_layerInfo)
{
	try
	{
		if (undefined == pi_layerInfo)
			return -2;
		
		pi_layerInfo.setId(++this.m_iLayerIDNext);	// set layer ID
		this.m_aLayerInfo[pi_layerInfo.getId()] = pi_layerInfo;	// store layer in array
		
		return 1;
	}
	catch(e)
	{
		handleException('CDataModelMap_addLayerInfo', e);
		return -1;
	}
	
	return 0;
}	// eof CDataModelMap_addLayerInfo


/**
 * return layer info for specified ID
 * @param pi_iID
 * @returns
 */
function CDataModelMap_getLayerInfo(pi_iID)
{
	try
	{
		if (undefined == pi_iID)
			return undefined;
		
		return this.m_aLayerInfo[pi_iID];
	}
	catch(e)
	{
		handleException('CDataModelMap_getLayerInfo', e);
		return undefined;
	}
	
	return undefined;
}	// eof CDataModelMap_getLayerInfo


/**
 * return layer info count
 * @param pi_iID
 * @returns
 */
function CDataModelMap_getLayerInfoCount()
{
	return this.m_aLayerInfo.length;
}	// eof CDataModelMap_getLayerInfoCount


/**
 * set layer visibility to specified value
 */
function CDataModelMap_setLayerVisible(pi_iIndex, pi_bVisible)
{
	try
	{
		if ("undefined" == typeof(pi_iIndex) || "undefined" == typeof(pi_bVisible))
			return -2;
		
		var layerInfo = this.m_aLayerInfo[pi_iIndex];
		
		if ("undefined" == typeof(layerInfo))
			return -3;
		
		layerInfo.setLayerVisible(pi_bVisible);
		this.fireEventLayerVisibleChanged(pi_iIndex);
		return 1;
	}
	catch(e)
	{
		handleException("CDataModelMap_setLayerVisible", e);
		return -1;
	}
	
}	// CDataModelMap_setLayerVisible



/**
 * set event notificatio handler when property visible of layer change
 */
function CDataModelMap_setEventLayerVisibleChanged(pi_eventValue)
{
	// allow undefined to reset notification assigning undefined
	this.eventLayerVisibleChanged = pi_eventValue;
	return 1;
}	// CDataModelMap_setEventLayerVisibleChanged


/**
 * fire event notification
 */
function CDataModelMap_fireEventLayerVisibleChanged(pi_iIndex)
{
	if ("undefined" == typeof(this.eventLayerVisibleChanged))
		return 1;
	
	return this.eventLayerVisibleChanged(pi_iIndex);
}	// CDataModelMap_fireEventLayerVisibleChanged



/**
 * toggle layer visible property of specified layer ID
 */
function CDataModelMap_toggleLayerVisible(pi_iIndex)
{
	try
	{
		if ("undefined" == typeof(pi_iIndex))
			return -2;
		
		var layerInfo = this.m_aLayerInfo[pi_iIndex];
		if ("undefined" == typeof(layerInfo))
			return -3;
		
		// toggler layer visiblity
		layerInfo.setLayerVisible(!layerInfo.getLayerVisible());
		this.fireEventLayerVisibleChanged(pi_iIndex);
	}
	catch(e)
	{
		handleException("CDataModelMap_toggleLayerVisible", e);
		return -1;
	}
	
}	// CDataModelMap_toggleLayerVisible



function CDataModelMap_getXMin()
{
	return this.m_dXMin;
}



function CDataModelMap_getYMin()
{
	return this.m_dYMin;
}



function CDataModelMap_getXMax()
{
	return this.m_dXMax;
}


function CDataModelMap_getYMax()
{
	return this.m_dYMax;
}


function CDataModelMap_getXCenter()
{
	return this.m_dXCenter;
}



function CDataModelMap_getYCenter()
{
	return this.m_dYCenter;
}


/**
 * controller of application
 */
function CControllerMap()
{
	this.setView = CControllerMap_setView;
	this.setCenter = CControllerMap_setCenter;
	this.addLayerInfo = CControllerMap_addLayerInfo;
	this.setInfoURL = CControllerMap_setInfoURL;
	this.setThreeDimensionalURL = CControllerMap_setThreeDimensionalURL;
	this.setPictometryURL = CControllerMap_setPictometryURL;
	this.setRequestPropValue = CControllerMap_setRequestPropValue;
	
	this.setLayerVisible = CControllerMap_setLayerVisible;
	this.addLayerInfo = CControllerMap_addLayerInfo;
	this.toggleLayerVisible = CControllerMap_toggleLayerVisible;
}


/**
 * set view
 */
function CControllerMap_setView(pi_dXMin, pi_dYMin, pi_dXMax, pi_dYMax)
{
	return g_datamodelMap.setView(pi_dXMin, pi_dYMin, pi_dXMax, pi_dYMax);
}


/**
 * set center of view
 */
function CControllerMap_setCenter(pi_dXCenter, pi_dYCenter)
{
	return g_datamodelMap.setCenter(pi_dXCenter, pi_dYCenter)
}


/**
 * add layer info to datamodel
 */
function CControllerMap_addLayerInfo(pi_layerInfo)
{
	return g_datamodelMap.addLayerInfo(pi_layerInfo);
}


/**
 * set infoURL
 */
function CControllerMap_setInfoURL(pi_strValue)
{
	return g_datamodelMap.setInfoURL(pi_strValue);
}


/**
 * set ThreeDimensionalURL
 */
function CControllerMap_setThreeDimensionalURL(pi_strValue)
{
	return g_datamodelMap.setThreeDimensionalURL(pi_strValue);
}


/**
 * set pictometryURL
 */
function CControllerMap_setPictometryURL(pi_strValue)
{
	return g_datamodelMap.setPictometryURL(pi_strValue);
}


/**
 * set RequestPropValue
 */
function CControllerMap_setRequestPropValue(pi_strValue)
{
	return g_datamodelMap.setRequestPropValue(pi_strValue);
}

/**
 * set layer visibility to specified value
 */
function CControllerMap_setLayerVisible(pi_iIndex, pi_bVisible)
{
	return g_datamodelMap.setLayerVisible(pi_iIndex, pi_bVisible);
}




/**
 * add layer to datamodel 
 */
function CControllerMap_addLayerInfo(pi_layerInfoI)
{
	return g_datamodelMap.addLayerInfo(pi_layerInfoI);
}



/**
 * Toggle menu check for specified item
 */
function CControllerMap_toggleLayerVisible(pi_iIndex)
{
	return g_datamodelMap.toggleLayerVisible(pi_iIndex);
}


//
// global variable declaration
//
var
	g_datamodelMap = new CDataModelMap()
	, g_controllerMap = new CControllerMap()
	;
