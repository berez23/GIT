//
// file: cutil.js
//
// create date: 2011-05-04
// update date: 2011-05-04
// version: 1.0
// description: general utilities
//


//
// constructor
//
function CUtil()
{
	//
	// functions
	//
	this.getStyleLeft = CUtil_getStyleLeft;
	this.getStyleTop = CUtil_getStyleTop;
	this.getStyleWidth = CUtil_getStyleWidth;
	this.getStyleHeight = CUtil_getStyleHeight;
	this.getStyleAsInt = CUtil_getStyleAsInt;
	this.getDigitFromString = CUtil_getDigitFromString;
	this.setStyleLeftTopWidhtHeight = CUtil_setStyleLeftTopWidhtHeight;
}


//
// given dom object return it's "css.left" value as integer value
//
function CUtil_getStyleLeft(pi_domObj)
{
	var iRV = 0;
	try
	{
		return this.getStyleAsInt(pi_domObj, 'left');
	}
	catch(e)
	{
		iRV = 0;
	}
	
	return iRV;
}	// CUtil_getStyleLeft


//
// given dom object return it's "css.top" value as integer value
//
function CUtil_getStyleTop(pi_domObj)
{
	var iRV = 0;
	try
	{
		return this.getStyleAsInt(pi_domObj, 'top');
	}
	catch(e)
	{
		iRV = 0;
	}
	
	return iRV;
}	// CUtil_getStyleTop


//
// given dom object return it's "css.width" value as integer value
//
function CUtil_getStyleWidth(pi_domObj)
{
	var iRV = 0;
	try
	{
		return this.getStyleAsInt(pi_domObj, 'width');
	}
	catch(e)
	{
		iRV = 0;
	}
	
	return iRV;
}	// CUtil_getStyleWidth


//
// given dom object return it's "css.height" value as integer value
//
function CUtil_getStyleHeight(pi_domObj)
{
	var iRV = 0;
	try
	{
		return this.getStyleAsInt(pi_domObj, 'height');
	}
	catch(e)
	{
		iRV = 0;
	}
	
	return iRV;
}	// CUtil_getStyleHeight

//
// return specified property as integer value
//
function CUtil_getStyleAsInt(pi_domObj, pi_strPropName)
{
	var iRV = 0;
	try
	{
		// check before accessing value
		if (undefined == pi_domObj)
			return 0;
	
		if (undefined == pi_strPropName)
			return 0;
		
		var styleI = pi_domObj.style;
		if (undefined == styleI)
			return 0;
		
		var strValue = styleI[pi_strPropName];
		if (undefined == strValue || '' == strValue)
			return 0;
	
		strValue = this.getDigitFromString(strValue);
		if (undefined == strValue || '' == strValue)
			iRV = 0;
		else
			iRV = eval(strValue);
	}
	catch(e)
	{
		iRV = 0;
	}
	
	return iRV;
}	// CUtil_getStyleAsInt




//
// extract all digit from string and stop after first non digit char
//
function CUtil_getDigitFromString(pi_strValue)
{
	var strRV = '';
	
	try
	{
		if (undefined == pi_strValue)
			return '';
		
		if ('string' != typeof(pi_strValue))
			return '';
		
		var iLen = pi_strValue.length
			, iIter
			, cCurrent;
		
		for (iIter = 0; iIter < iLen; ++iIter)
		{
			cCurrent = pi_strValue.charAt(iIter);
			
			if (cCurrent < '0' || cCurrent > '9')
				break;
			
			strRV += cCurrent;
		}
	}
	catch(e)
	{
		strRV = '';
	}
	
	return strRV;
}	// CUtil_getDigitFromString


//
// set all style properties at one for dom object
function CUtil_setStyleLeftTopWidhtHeight(pi_domObj, pi_position)
{	
	try
	{
		if (undefined == pi_domObj)
			return -2;
		
		if (undefined == pi_position)
			return -3;
		
		var styleI = pi_domObj.style;
		if (undefined == styleI)
			return -100;

		// set single property if defined
		if (undefined != pi_position.left)
			pi_domObj.left = pi_position.left;
		
		if (undefined != pi_position.top)
			pi_domObj.top = pi_position.top;

		if (undefined != pi_position.width)
			pi_domObj.width = pi_position.width;

		if (undefined != pi_position.height)
			pi_domObj.height = pi_position.height;
		return 1;
	}
	catch(e)
	{
		return -1;
	}
	
	return 0;
}	// CUtil_setStyleLeftTopWidhtHeight



/**
 * Manage exception
 */
function handleException(pi_strContext, pi_exception)
{
	try
	{
	var strMsg;
	
	strMsg = 'Eccezione generata.';
	
	if (undefined != pi_strContext)
		strMsg += '\nContesto: ' + pi_strContext;
	
	if (undefined != pi_exception)
	{
		strMsg += '\nEccezione: ' + pi_exception.toString();
		
		// for IE
		if (undefined != pi_exception.message)
			strMsg += '\nMesage: ' + pi_exception.message;
	}

	alert(strMsg);
	}
	catch(e)
	{
		alert('handleException\n' + e.toString());
	}
} // handleException



/**
 * check value is ok
 *  
 * @param pi_value
 */
function isOK(pi_value)
{
	// value must be a number and > 0
	if ("number" != typeof(pi_value)
			|| (pi_value <= 0))
		return false;
	
	return true;
}

var
	g_util = new CUtil();
