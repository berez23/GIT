
/** 
 * DbMAP JS - Version 1.8 	  			
 */
	  		/* This notice must be untouched at all times.

wz_jsgraphics.js    v. 3.05
The latest version is available at
http://www.walterzorn.com
or http://www.devira.com
or http://www.walterzorn.de

Copyright (c) 2002-2009 Walter Zorn. All rights reserved.
Created 3. 11. 2002 by Walter Zorn (Web: http://www.walterzorn.com )
Last modified: 2. 2. 2009

Performance optimizations for Internet Explorer
by Thomas Frank and John Holdsworth.
fillPolygon method implemented by Matthieu Haller.

High Performance JavaScript Graphics Library.
Provides methods
- to draw lines, rectangles, ellipses, polygons
	with specifiable line thickness,
- to fill rectangles, polygons, ellipses and arcs
- to draw text.
NOTE: Operations, functions and branching have rather been optimized
to efficiency and speed than to shortness of source code.

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/


var jg_ok, jg_ie, jg_fast, jg_dom, jg_moz, jg_zIndex;


function _chkDHTM(wnd, x, i)
// Under XUL, owner of 'document' must be specified explicitly
{
	x = wnd.document.body || null;
	jg_ie = x && typeof x.insertAdjacentHTML != "undefined" && wnd.document.createElement;
	jg_dom = (x && !jg_ie &&
		typeof x.appendChild != "undefined" &&
		typeof wnd.document.createRange != "undefined" &&
		typeof (i = wnd.document.createRange()).setStartBefore != "undefined" &&
		typeof i.createContextualFragment != "undefined");
	jg_fast = jg_ie && wnd.document.all && !wnd.opera;
	jg_moz = jg_dom && typeof x.style.MozOpacity != "undefined";
	jg_ok = !!(jg_ie || jg_dom);
}

function _pntCnvDom()
{
	var x = this.wnd.document.createRange();
	x.setStartBefore(this.cnv);
	x = x.createContextualFragment(jg_fast? this._htmRpc() : this.htm);
	if(this.cnv) this.cnv.appendChild(x);
	this.htm = "";
}

function _pntCnvIe()
{
	if(this.cnv) this.cnv.insertAdjacentHTML("BeforeEnd", jg_fast? this._htmRpc() : this.htm);
	this.htm = "";
}

function _pntDoc()
{
	this.wnd.document.write(jg_fast? this._htmRpc() : this.htm);
	this.htm = '';
}

function _pntN()
{
	;
}

function _mkDiv(x, y, w, h)
{
	this.htm += '<div style="position:absolute;'+
		'left:' + x + 'px;'+
		'top:' + y + 'px;'+
		'width:' + w + 'px;'+
		'height:' + h + 'px;'+
		'clip:rect(0,'+w+'px,'+h+'px,0);'+
		'background-color:' + this.color +
		(!jg_moz? ';overflow:hidden' : '')+
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '')+
		';"><\/div>';
}

function _mkDivIe(x, y, w, h)
{
	this.htm += '%%'+this.color+';'+x+';'+y+';'+w+';'+h+';';
}

function _mkDivPrt(x, y, w, h)
{
	this.htm += '<div style="position:absolute;'+
		'border-left:' + w + 'px solid ' + this.color + ';'+
		'left:' + x + 'px;'+
		'top:' + y + 'px;'+
		'width:0px;'+
		'height:' + h + 'px;'+
		'clip:rect(0,'+w+'px,'+h+'px,0);'+
		'background-color:' + this.color +
		(!jg_moz? ';overflow:hidden' : '')+
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';"><\/div>';
}

var _regex =  /%%([^;]+);([^;]+);([^;]+);([^;]+);([^;]+);/g;
function _htmRpc()
{
	return this.htm.replace(
		_regex,
		'<div style="overflow:hidden;position:absolute' + 
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';background-color:$1;left:$2px;top:$3px;width:$4px;height:$5px"></div>\n');
}

function _htmPrtRpc()
{
	return this.htm.replace(
		_regex,
		'<div style="overflow:hidden;position:absolute' + 
		(jg_zIndex!=null? ';z-index:'+jg_zIndex : '') +
		';background-color:$1;left:$2px;top:$3px;width:$4px;height:$5px;border-left:$4px solid $1"></div>\n');
}

function _mkLin(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1;

	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx,
		ox = x;
		while(dx > 0)
		{--dx;
			++x;
			if(p > 0)
			{
				this._mkDiv(ox, y, x-ox, 1);
				y += yIncr;
				p += pru;
				ox = x;
			}
			else p += pr;
		}
		this._mkDiv(ox, y, x2-ox+1, 1);
	}

	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy,
		oy = y;
		if(y2 <= y1)
		{
			while(dy > 0)
			{--dy;
				if(p > 0)
				{
					this._mkDiv(x++, y, 1, oy-y+1);
					y += yIncr;
					p += pru;
					oy = y;
				}
				else
				{
					y += yIncr;
					p += pr;
				}
			}
			this._mkDiv(x2, y2, 1, oy-y2+1);
		}
		else
		{
			while(dy > 0)
			{--dy;
				y += yIncr;
				if(p > 0)
				{
					this._mkDiv(x++, oy, 1, y-oy);
					p += pru;
					oy = y;
				}
				else p += pr;
			}
			this._mkDiv(x2, oy, 1, y2-oy+1);
		}
	}
}

function _mkLin2D(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1;

	var s = this.stroke;
	if(dx >= dy)
	{
		if(dx > 0 && s-3 > 0)
		{
			var _s = (s*dx*Math.sqrt(1+dy*dy/(dx*dx))-dx-(s>>1)*dy) / dx;
			_s = (!(s-4)? Math.ceil(_s) : Math.round(_s)) + 1;
		}
		else var _s = s;
		var ad = Math.ceil(s/2);

		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx,
		ox = x;
		while(dx > 0)
		{--dx;
			++x;
			if(p > 0)
			{
				this._mkDiv(ox, y, x-ox+ad, _s);
				y += yIncr;
				p += pru;
				ox = x;
			}
			else p += pr;
		}
		this._mkDiv(ox, y, x2-ox+ad+1, _s);
	}

	else
	{
		if(s-3 > 0)
		{
			var _s = (s*dy*Math.sqrt(1+dx*dx/(dy*dy))-(s>>1)*dx-dy) / dy;
			_s = (!(s-4)? Math.ceil(_s) : Math.round(_s)) + 1;
		}
		else var _s = s;
		var ad = Math.round(s/2);

		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy,
		oy = y;
		if(y2 <= y1)
		{
			++ad;
			while(dy > 0)
			{--dy;
				if(p > 0)
				{
					this._mkDiv(x++, y, _s, oy-y+ad);
					y += yIncr;
					p += pru;
					oy = y;
				}
				else
				{
					y += yIncr;
					p += pr;
				}
			}
			this._mkDiv(x2, y2, _s, oy-y2+ad);
		}
		else
		{
			while(dy > 0)
			{--dy;
				y += yIncr;
				if(p > 0)
				{
					this._mkDiv(x++, oy, _s, y-oy+ad);
					p += pru;
					oy = y;
				}
				else p += pr;
			}
			this._mkDiv(x2, oy, _s, y2-oy+ad+1);
		}
	}
}

function _mkLinDott(x1, y1, x2, y2)
{
	if(x1 > x2)
	{
		var _x2 = x2;
		var _y2 = y2;
		x2 = x1;
		y2 = y1;
		x1 = _x2;
		y1 = _y2;
	}
	var dx = x2-x1, dy = Math.abs(y2-y1),
	x = x1, y = y1,
	yIncr = (y1 > y2)? -1 : 1,
	drw = true;
	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1),
		p = pr-dx;
		while(dx > 0)
		{--dx;
			if(drw) this._mkDiv(x, y, 1, 1);
			drw = !drw;
			if(p > 0)
			{
				y += yIncr;
				p += pru;
			}
			else p += pr;
			++x;
		}
	}
	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1),
		p = pr-dy;
		while(dy > 0)
		{--dy;
			if(drw) this._mkDiv(x, y, 1, 1);
			drw = !drw;
			y += yIncr;
			if(p > 0)
			{
				++x;
				p += pru;
			}
			else p += pr;
		}
	}
	if(drw) this._mkDiv(x, y, 1, 1);
}

function _mkOv(left, top, width, height)
{
	var a = (++width)>>1, b = (++height)>>1,
	wod = width&1, hod = height&1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	ox = 0, oy = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1),
	w, h;
	while(y > 0)
	{
		if(st < 0)
		{
			st += bb2*((x<<1)+3);
			tt += bb4*(++x);
		}
		else if(tt < 0)
		{
			st += bb2*((x<<1)+3) - aa4*(y-1);
			tt += bb4*(++x) - aa2*(((y--)<<1)-3);
			w = x-ox;
			h = oy-y;
			if((w&2) && (h&2))
			{
				this._mkOvQds(cx, cy, x-2, y+2, 1, 1, wod, hod);
				this._mkOvQds(cx, cy, x-1, y+1, 1, 1, wod, hod);
			}
			else this._mkOvQds(cx, cy, x-1, oy, w, h, wod, hod);
			ox = x;
			oy = y;
		}
		else
		{
			tt -= aa2*((y<<1)-3);
			st -= aa4*(--y);
		}
	}
	w = a-ox+1;
	h = (oy<<1)+hod;
	y = cy-oy;
	this._mkDiv(cx-a, y, w, h);
	this._mkDiv(cx+ox+wod-1, y, w, h);
}

function _mkOv2D(left, top, width, height)
{
	var s = this.stroke;
	width += s+1;
	height += s+1;
	var a = width>>1, b = height>>1,
	wod = width&1, hod = height&1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1);

	if(s-4 < 0 && (!(s-2) || width-51 > 0 && height-51 > 0))
	{
		var ox = 0, oy = b,
		w, h,
		pxw;
		while(y > 0)
		{
			if(st < 0)
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				w = x-ox;
				h = oy-y;

				if(w-1)
				{
					pxw = w+1+(s&1);
					h = s;
				}
				else if(h-1)
				{
					pxw = s;
					h += 1+(s&1);
				}
				else pxw = h = s;
				this._mkOvQds(cx, cy, x-1, oy, pxw, h, wod, hod);
				ox = x;
				oy = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}
		}
		this._mkDiv(cx-a, cy-oy, s, (oy<<1)+hod);
		this._mkDiv(cx+a+wod-s, cy-oy, s, (oy<<1)+hod);
	}

	else
	{
		var _a = (width-(s<<1))>>1,
		_b = (height-(s<<1))>>1,
		_x = 0, _y = _b,
		_aa2 = (_a*_a)<<1, _aa4 = _aa2<<1, _bb2 = (_b*_b)<<1, _bb4 = _bb2<<1,
		_st = (_aa2>>1)*(1-(_b<<1)) + _bb2,
		_tt = (_bb2>>1) - _aa2*((_b<<1)-1),

		pxl = new Array(),
		pxt = new Array(),
		_pxb = new Array();
		pxl[0] = 0;
		pxt[0] = b;
		_pxb[0] = _b-1;
		while(y > 0)
		{
			if(st < 0)
			{
				pxl[pxl.length] = x;
				pxt[pxt.length] = y;
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				pxl[pxl.length] = x;
				st += bb2*((x<<1)+3) - aa4*(y-1);
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				pxt[pxt.length] = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}

			if(_y > 0)
			{
				if(_st < 0)
				{
					_st += _bb2*((_x<<1)+3);
					_tt += _bb4*(++_x);
					_pxb[_pxb.length] = _y-1;
				}
				else if(_tt < 0)
				{
					_st += _bb2*((_x<<1)+3) - _aa4*(_y-1);
					_tt += _bb4*(++_x) - _aa2*(((_y--)<<1)-3);
					_pxb[_pxb.length] = _y-1;
				}
				else
				{
					_tt -= _aa2*((_y<<1)-3);
					_st -= _aa4*(--_y);
					_pxb[_pxb.length-1]--;
				}
			}
		}

		var ox = -wod, oy = b,
		_oy = _pxb[0],
		l = pxl.length,
		w, h;
		for(var i = 0; i < l; i++)
		{
			if(typeof _pxb[i] != "undefined")
			{
				if(_pxb[i] < _oy || pxt[i] < oy)
				{
					x = pxl[i];
					this._mkOvQds(cx, cy, x, oy, x-ox, oy-_oy, wod, hod);
					ox = x;
					oy = pxt[i];
					_oy = _pxb[i];
				}
			}
			else
			{
				x = pxl[i];
				this._mkDiv(cx-x, cy-oy, 1, (oy<<1)+hod);
				this._mkDiv(cx+ox+wod, cy-oy, 1, (oy<<1)+hod);
				ox = x;
				oy = pxt[i];
			}
		}
		this._mkDiv(cx-a, cy-oy, 1, (oy<<1)+hod);
		this._mkDiv(cx+ox+wod, cy-oy, 1, (oy<<1)+hod);
	}
}

function _mkOvDott(left, top, width, height)
{
	var a = (++width)>>1, b = (++height)>>1,
	wod = width&1, hod = height&1, hodu = hod^1,
	cx = left+a, cy = top+b,
	x = 0, y = b,
	aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
	st = (aa2>>1)*(1-(b<<1)) + bb2,
	tt = (bb2>>1) - aa2*((b<<1)-1),
	drw = true;
	while(y > 0)
	{
		if(st < 0)
		{
			st += bb2*((x<<1)+3);
			tt += bb4*(++x);
		}
		else if(tt < 0)
		{
			st += bb2*((x<<1)+3) - aa4*(y-1);
			tt += bb4*(++x) - aa2*(((y--)<<1)-3);
		}
		else
		{
			tt -= aa2*((y<<1)-3);
			st -= aa4*(--y);
		}
		if(drw && y >= hodu) this._mkOvQds(cx, cy, x, y, 1, 1, wod, hod);
		drw = !drw;
	}
}

function _mkRect(x, y, w, h)
{
	var s = this.stroke;
	this._mkDiv(x, y, w, s);
	this._mkDiv(x+w, y, s, h);
	this._mkDiv(x, y+h, w+s, s);
	this._mkDiv(x, y+s, s, h-s);
}

function _mkRectDott(x, y, w, h)
{
	this.drawLine(x, y, x+w, y);
	this.drawLine(x+w, y, x+w, y+h);
	this.drawLine(x, y+h, x+w, y+h);
	this.drawLine(x, y, x, y+h);
}

function jsgFont()
{
	this.PLAIN = 'font-weight:normal;';
	this.BOLD = 'font-weight:bold;';
	this.ITALIC = 'font-style:italic;';
	this.ITALIC_BOLD = this.ITALIC + this.BOLD;
	this.BOLD_ITALIC = this.ITALIC_BOLD;
}
var Font = new jsgFont();

function jsgStroke()
{
	this.DOTTED = -1;
}
var Stroke = new jsgStroke();

function jsGraphics(cnv, wnd)
{
	this.setColor = function(x)
	{
		this.color = x.toLowerCase();
	};

	this.setStroke = function(x)
	{
		this.stroke = x;
		if(!(x+1))
		{
			this.drawLine = _mkLinDott;
			this._mkOv = _mkOvDott;
			this.drawRect = _mkRectDott;
		}
		else if(x-1 > 0)
		{
			this.drawLine = _mkLin2D;
			this._mkOv = _mkOv2D;
			this.drawRect = _mkRect;
		}
		else
		{
			this.drawLine = _mkLin;
			this._mkOv = _mkOv;
			this.drawRect = _mkRect;
		}
	};

	this.setPrintable = function(arg)
	{
		this.printable = arg;
		if(jg_fast)
		{
			this._mkDiv = _mkDivIe;
			this._htmRpc = arg? _htmPrtRpc : _htmRpc;
		}
		else this._mkDiv = arg? _mkDivPrt : _mkDiv;
	};

	this.setFont = function(fam, sz, sty)
	{
		this.ftFam = fam;
		this.ftSz = sz;
		this.ftSty = sty || Font.PLAIN;
	};

	this.drawPolyline = this.drawPolyLine = function(x, y)
	{
		for (var i=x.length - 1; i;)
		{--i;
			this.drawLine(x[i], y[i], x[i+1], y[i+1]);
		}
	};

	this.fillRect = function(x, y, w, h)
	{
		this._mkDiv(x, y, w, h);
	};

	this.drawPolygon = function(x, y)
	{
		this.drawPolyline(x, y);
		this.drawLine(x[x.length-1], y[x.length-1], x[0], y[0]);
	};

	this.drawEllipse = this.drawOval = function(x, y, w, h)
	{
		this._mkOv(x, y, w, h);
	};

	this.fillEllipse = this.fillOval = function(left, top, w, h)
	{
		var a = w>>1, b = h>>1,
		wod = w&1, hod = h&1,
		cx = left+a, cy = top+b,
		x = 0, y = b, oy = b,
		aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
		st = (aa2>>1)*(1-(b<<1)) + bb2,
		tt = (bb2>>1) - aa2*((b<<1)-1),
		xl, dw, dh;
		if(w) while(y > 0)
		{
			if(st < 0)
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0)
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				xl = cx-x;
				dw = (x<<1)+wod;
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				dh = oy-y;
				this._mkDiv(xl, cy-oy, dw, dh);
				this._mkDiv(xl, cy+y+hod, dw, dh);
				oy = y;
			}
			else
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
			}
		}
		this._mkDiv(cx-a, cy-oy, w, (oy<<1)+hod);
	};

	this.fillArc = function(iL, iT, iW, iH, fAngA, fAngZ)
	{
		var a = iW>>1, b = iH>>1,
		iOdds = (iW&1) | ((iH&1) << 16),
		cx = iL+a, cy = iT+b,
		x = 0, y = b, ox = x, oy = y,
		aa2 = (a*a)<<1, aa4 = aa2<<1, bb2 = (b*b)<<1, bb4 = bb2<<1,
		st = (aa2>>1)*(1-(b<<1)) + bb2,
		tt = (bb2>>1) - aa2*((b<<1)-1),
		// Vars for radial boundary lines
		xEndA, yEndA, xEndZ, yEndZ,
		iSects = (1 << (Math.floor((fAngA %= 360.0)/180.0) << 3))
				| (2 << (Math.floor((fAngZ %= 360.0)/180.0) << 3))
				| ((fAngA >= fAngZ) << 16),
		aBndA = new Array(b+1), aBndZ = new Array(b+1);
		
		// Set up radial boundary lines
		fAngA *= Math.PI/180.0;
		fAngZ *= Math.PI/180.0;
		xEndA = cx+Math.round(a*Math.cos(fAngA));
		yEndA = cy+Math.round(-b*Math.sin(fAngA));
		_mkLinVirt(aBndA, cx, cy, xEndA, yEndA);
		xEndZ = cx+Math.round(a*Math.cos(fAngZ));
		yEndZ = cy+Math.round(-b*Math.sin(fAngZ));
		_mkLinVirt(aBndZ, cx, cy, xEndZ, yEndZ);

		while(y > 0)
		{
			if(st < 0) // Advance x
			{
				st += bb2*((x<<1)+3);
				tt += bb4*(++x);
			}
			else if(tt < 0) // Advance x and y
			{
				st += bb2*((x<<1)+3) - aa4*(y-1);
				ox = x;
				tt += bb4*(++x) - aa2*(((y--)<<1)-3);
				this._mkArcDiv(ox, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
				oy = y;
			}
			else // Advance y
			{
				tt -= aa2*((y<<1)-3);
				st -= aa4*(--y);
				if(y && (aBndA[y] != aBndA[y-1] || aBndZ[y] != aBndZ[y-1]))
				{
					this._mkArcDiv(x, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
					ox = x;
					oy = y;
				}
			}
		}
		this._mkArcDiv(x, 0, oy, cx, cy, iOdds, aBndA, aBndZ, iSects);
		if(iOdds >> 16) // Odd height
		{
			if(iSects >> 16) // Start-angle > end-angle
			{
				var xl = (yEndA <= cy || yEndZ > cy)? (cx - x) : cx;
				this._mkDiv(xl, cy, x + cx - xl + (iOdds & 0xffff), 1);
			}
			else if((iSects & 0x01) && yEndZ > cy)
				this._mkDiv(cx - x, cy, x, 1);
		}
	};

/* fillPolygon method, implemented by Matthieu Haller.
This javascript function is an adaptation of the gdImageFilledPolygon for Walter Zorn lib.
C source of GD 1.8.4 found at http://www.boutell.com/gd/

THANKS to Kirsten Schulz for the polygon fixes!

The intersection finding technique of this code could be improved
by remembering the previous intertersection, and by using the slope.
That could help to adjust intersections to produce a nice
interior_extrema. */
	this.fillPolygon = function(array_x, array_y)
	{
		var i;
		var y;
		var miny, maxy;
		var x1, y1;
		var x2, y2;
		var ind1, ind2;
		var ints;

		var n = array_x.length;
		if(!n) return;

		miny = array_y[0];
		maxy = array_y[0];
		for(i = 1; i < n; i++)
		{
			if(array_y[i] < miny)
				miny = array_y[i];

			if(array_y[i] > maxy)
				maxy = array_y[i];
		}
		for(y = miny; y <= maxy; y++)
		{
			var polyInts = new Array();
			ints = 0;
			for(i = 0; i < n; i++)
			{
				if(!i)
				{
					ind1 = n-1;
					ind2 = 0;
				}
				else
				{
					ind1 = i-1;
					ind2 = i;
				}
				y1 = array_y[ind1];
				y2 = array_y[ind2];
				if(y1 < y2)
				{
					x1 = array_x[ind1];
					x2 = array_x[ind2];
				}
				else if(y1 > y2)
				{
					y2 = array_y[ind1];
					y1 = array_y[ind2];
					x2 = array_x[ind1];
					x1 = array_x[ind2];
				}
				else continue;

				 //  Modified 11. 2. 2004 Walter Zorn
				if((y >= y1) && (y < y2))
					polyInts[ints++] = Math.round((y-y1) * (x2-x1) / (y2-y1) + x1);

				else if((y == maxy) && (y > y1) && (y <= y2))
					polyInts[ints++] = Math.round((y-y1) * (x2-x1) / (y2-y1) + x1);
			}
			polyInts.sort(_CompInt);
			for(i = 0; i < ints; i+=2)
				this._mkDiv(polyInts[i], y, polyInts[i+1]-polyInts[i]+1, 1);
		}
	};

	this.drawString = function(txt, x, y)
	{
		this.htm += '<div style="position:absolute;white-space:nowrap;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			'font-family:' +  this.ftFam + ';'+
			'font-size:' + this.ftSz + ';'+
			'color:' + this.color + ';' + this.ftSty + '">'+
			txt +
			'<\/div>';
	};

/* drawStringRect() added by Rick Blommers.
Allows to specify the size of the text rectangle and to align the
text both horizontally (e.g. right) and vertically within that rectangle */
	this.drawStringRect = function(txt, x, y, width, halign)
	{
		this.htm += '<div style="position:absolute;overflow:hidden;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			'width:'+width +'px;'+
			'text-align:'+halign+';'+
			'font-family:' +  this.ftFam + ';'+
			'font-size:' + this.ftSz + ';'+
			'color:' + this.color + ';' + this.ftSty + '">'+
			txt +
			'<\/div>';
	};

	this.drawImage = function(imgSrc, x, y, w, h, a)
	{
		this.htm += '<div style="position:absolute;'+
			'left:' + x + 'px;'+
			'top:' + y + 'px;'+
			// w (width) and h (height) arguments are now optional.
			// Added by Mahmut Keygubatli, 14.1.2008
			(w? ('width:' +  w + 'px;') : '') +
			(h? ('height:' + h + 'px;'):'')+'">'+
			'<img src="' + imgSrc +'"'+ (w ? (' width="' + w + '"'):'')+ (h ? (' height="' + h + '"'):'') + (a? (' '+a) : '') + '>'+
			'<\/div>';
	};

	this.clear = function()
	{
		this.htm = "";
		if(this.cnv) this.cnv.innerHTML = "";
	};

	this._mkOvQds = function(cx, cy, x, y, w, h, wod, hod)
	{
		var xl = cx - x, xr = cx + x + wod - w, yt = cy - y, yb = cy + y + hod - h;
		if(xr > xl+w)
		{
			this._mkDiv(xr, yt, w, h);
			this._mkDiv(xr, yb, w, h);
		}
		else
			w = xr - xl + w;
		this._mkDiv(xl, yt, w, h);
		this._mkDiv(xl, yb, w, h);
	};
	
	this._mkArcDiv = function(x, y, oy, cx, cy, iOdds, aBndA, aBndZ, iSects)
	{
		var xrDef = cx + x + (iOdds & 0xffff), y2, h = oy - y, xl, xr, w;

		if(!h) h = 1;
		x = cx - x;

		if(iSects & 0xff0000) // Start-angle > end-angle
		{
			y2 = cy - y - h;
			if(iSects & 0x00ff)
			{
				if(iSects & 0x02)
				{
					xl = Math.max(x, aBndZ[y]);
					w = xrDef - xl;
					if(w > 0) this._mkDiv(xl, y2, w, h);
				}
				if(iSects & 0x01)
				{
					xr = Math.min(xrDef, aBndA[y]);
					w = xr - x;
					if(w > 0) this._mkDiv(x, y2, w, h);
				}
			}
			else
				this._mkDiv(x, y2, xrDef - x, h);
			y2 = cy + y + (iOdds >> 16);
			if(iSects & 0xff00)
			{
				if(iSects & 0x0100)
				{
					xl = Math.max(x, aBndA[y]);
					w = xrDef - xl;
					if(w > 0) this._mkDiv(xl, y2, w, h);
				}
				if(iSects & 0x0200)
				{
					xr = Math.min(xrDef, aBndZ[y]);
					w = xr - x;
					if(w > 0) this._mkDiv(x, y2, w, h);
				}
			}
			else
				this._mkDiv(x, y2, xrDef - x, h);
		}
		else
		{
			if(iSects & 0x00ff)
			{
				if(iSects & 0x02)
					xl = Math.max(x, aBndZ[y]);
				else
					xl = x;
				if(iSects & 0x01)
					xr = Math.min(xrDef, aBndA[y]);
				else
					xr = xrDef;
				y2 = cy - y - h;
				w = xr - xl;
				if(w > 0) this._mkDiv(xl, y2, w, h);
			}
			if(iSects & 0xff00)
			{
				if(iSects & 0x0100)
					xl = Math.max(x, aBndA[y]);
				else
					xl = x;
				if(iSects & 0x0200)
					xr = Math.min(xrDef, aBndZ[y]);
				else
					xr = xrDef;
				y2 = cy + y + (iOdds >> 16);
				w = xr - xl;
				if(w > 0) this._mkDiv(xl, y2, w, h);
			}
		}
	};

	this.setStroke(1);
	this.setFont("verdana,geneva,helvetica,sans-serif", "12px", Font.PLAIN);
	this.color = "#000000";
	this.htm = "";
	this.wnd = wnd || window;

	if(!jg_ok) _chkDHTM(this.wnd);
	if(jg_ok)
	{
		if(cnv)
		{
			if(typeof(cnv) == "string")
				this.cont = document.all? (this.wnd.document.all[cnv] || null)
					: document.getElementById? (this.wnd.document.getElementById(cnv) || null)
					: null;
			else if(cnv == window.document)
				this.cont = document.getElementsByTagName("body")[0];
			// If cnv is a direct reference to a canvas DOM node
			// (option suggested by Andreas Luleich)
			else this.cont = cnv;
			// Create new canvas inside container DIV. Thus the drawing and clearing
			// methods won't interfere with the container's inner html.
			// Solution suggested by Vladimir.
			this.cnv = this.wnd.document.createElement("div");
			this.cnv.style.fontSize=0;
			this.cont.appendChild(this.cnv);
			this.paint = jg_dom? _pntCnvDom : _pntCnvIe;
		}
		else
			this.paint = _pntDoc;
	}
	else
		this.paint = _pntN;

	this.setPrintable(false);
}

function _mkLinVirt(aLin, x1, y1, x2, y2)
{
	var dx = Math.abs(x2-x1), dy = Math.abs(y2-y1),
	x = x1, y = y1,
	xIncr = (x1 > x2)? -1 : 1,
	yIncr = (y1 > y2)? -1 : 1,
	p,
	i = 0;
	if(dx >= dy)
	{
		var pr = dy<<1,
		pru = pr - (dx<<1);
		p = pr-dx;
		while(dx > 0)
		{--dx;
			if(p > 0)    //  Increment y
			{
				aLin[i++] = x;
				y += yIncr;
				p += pru;
			}
			else p += pr;
			x += xIncr;
		}
	}
	else
	{
		var pr = dx<<1,
		pru = pr - (dy<<1);
		p = pr-dy;
		while(dy > 0)
		{--dy;
			y += yIncr;
			aLin[i++] = x;
			if(p > 0)    //  Increment x
			{
				x += xIncr;
				p += pru;
			}
			else p += pr;
		}
	}
	for(var len = aLin.length, i = len-i; i;)
		aLin[len-(i--)] = x;
};

function _CompInt(x, y)
{
	return(x - y);
}

/**
 * @class Bounding Box
 * 
 * @param mapCoordinates Bounding Box iniziale { xmin: ..., ymin: ..., xmax: ..., ymax: ... }
 */
function BBox(mapCoordinates) {
	this.xmin = null;
	this.ymin =	null;
	this.xmax =	null;
	this.ymax = null;
	
	if (mapCoordinates != null) {
		this.xmin = mapCoordinates.xmin;
		this.ymin =	mapCoordinates.ymin;
		this.xmax =	mapCoordinates.xmax;
		this.ymax = mapCoordinates.ymax;
	}
}

/**
 * Calcola se il punto passato &egrave; contenuto nel Bounding Box
 */
BBox.prototype.containsPoint = function(x, y) {
	return this.xmin <= x && this.xmax >= x && 
		this.ymin <= y && this.ymax >= y;
}

/**
 * Restituisce le coordinate del Bounding Box
 */
BBox.prototype.getCoordinates = function() {
	return { xmin: this.xmin, ymin: this.ymin, xmax: this.xmax, ymax: this.ymax };
}

/**
 * Controlla l'equivalenza con il Bounding Box passato 
 */
BBox.prototype.equals = function(otherBBox) {
	if (otherBBox == null) return false;
	
	return this.xmin == otherBBox.xmin &&
		this.xmax == otherBBox.xmax &&
		this.ymin == otherBBox.ymin &&
		this.ymax == otherBBox.ymax;
}
/**
 * @class Marker
 * 
 * @param node elemento da inserire
 * @param offsetTop offset da usare nella coordinata top
 * @param offsetLeft offset da usare nella coordinata left
 * @param id identificativo univoco
 * @param x coordinata x sulla mappa
 * @param y coordinata y sulla mappa
 */
function Marker(node, offsetTop, offsetLeft, id, x, y, insertEvenIfOffScreen) {
	this.node = $(node);
	this.offsetTop = offsetTop;
	this.offsetLeft = offsetLeft;
	this.id = id;	
	this.x = x;
	this.y = y;
	this.insertEvenIfOffScreen = insertEvenIfOffScreen;
}

/**
 *
 */
Marker.prototype.clone = function() {
	return new Marker(this.node, this.offsetTop, this.offsetLeft, this.id, this.x, this.y, this.insertEvenIfOffScreen);
}

function Tile(x, y, z, bbox, screenPosition) {
	this.x = x;
	this.y = y;
	this.z = z;
	this.bbox = bbox;
	this.screenPosition = screenPosition;
}

Tile.prototype.equals = function(otherTile) {
	if (otherTile == null) return false;
	
	return this.x == otherTile.x &&
		this.y == otherTile.y &&
		this.z == otherTile.z;
};

function MapGrid(tileSize, unitsPerPixelOnZoomZero, maxZ, offset) {
	this.unitsPerPixelOnZoomZero = unitsPerPixelOnZoomZero;
	this.unitsPerPixel = unitsPerPixelOnZoomZero;
	this.z = 0;
	this.maxZ = maxZ;
	
	this.referenceSystemIsLatLon = false;
	
	this.tileSizeOnScreen = tileSize;
	this.tileSizeOnMap = null;
	
	// deprecated
	this.pixelValue = null;
	
	this.currentView = null;
	
	this.gridStartPointOnMap = null;
	this.grid = null;
	this.xNumTiles = null;
	this.yNumTiles = null;
	
	this.screenHeight = null;
	this.screenWidth = null;
	
	this.dpi = null;
	// 1 inch = 2.54 centimeters
	this.cmInInch = 2.54;	
	
	this.offset = offset != null ? offset : { x: 0, y: 0 };
}

MapGrid.prototype.calculateDPI = function() {
	var node = document.getElementById('dbmap_dpi');
	
	if (node == null) {
		node = $('<div />')
			.attr('id', 'dbmap_dpi')
			.css({ height: '1in', width: '1in', position: 'absolute', left: '-100%', top: '-100%' });
  		$(document.body).append(node);
  		node = document.getElementById('dbmap_dpi');
	}
  
  	return node.offsetHeight;
}

MapGrid.prototype.getScale = function() {
	if (this.dpi == null) {
		this.dpi = this.calculateDPI();
	}
	
	var pixelPerCm = this.dpi / this.cmInInch;
	
	if (this.referenceSystemIsLatLon) {
		var degreeToMeter = 111319;
		var cmPerPixel = this.unitsPerPixel * degreeToMeter * 100 * pixelPerCm;
		return Math.round(cmPerPixel);
	} else {
		var cmPerPixel = this.unitsPerPixel * 100 * pixelPerCm;
		return Math.round(cmPerPixel);
	}
}

MapGrid.prototype.getZoomLevel = function() {
	return this.z;
}

MapGrid.prototype.zoomToLevel = function(newZ) {
	if (newZ < 0) newZ = 0;
	if (newZ > this.maxZ) newZ = this.maxZ;
	
	this.z = newZ;
	this.onZoomChanged();
	return true;
}

MapGrid.prototype.zoomIn = function() {
	if (this.maxZ > this.z) {
		this.z++;
		this.onZoomChanged();
		return true;
	} else {
		return false;
	}
}

MapGrid.prototype.zoomOut = function() {
	if (this.z > 0) {
		this.z--;
		this.onZoomChanged();
		return true;
	} else {
		return false;
	}
}

MapGrid.prototype.onZoomChanged = function() {
	this.unitsPerPixel = this.unitsPerPixelOnZoomZero / Math.pow(2, this.z);
	
	this.tileSizeOnMap = this.tileSizeOnScreen * this.unitsPerPixel;
	this.pixelValue = 1 / this.unitsPerPixel;
		
	this.gridStartPointOnMap = { x: 0, y: 0 };
	
	var newXmax = this.currentView.xmin + this.screenWidth * this.unitsPerPixel;
	var newYmax = this.currentView.ymin + this.screenHeight * this.unitsPerPixel;
	var xOffset = ((this.currentView.xmax - this.currentView.xmin) - (newXmax - this.currentView.xmin)) / 2;
	var yOffset = ((this.currentView.ymax - this.currentView.ymin) - (newYmax - this.currentView.ymin)) / 2;

	var bbox = { xmin: this.currentView.xmin + xOffset, ymin: this.currentView.ymin + yOffset,
		xmax: this.currentView.xmax - xOffset, ymax: this.currentView.ymax - yOffset }; 	

	this.currentView = new BBox(bbox);
	
	this.reloadGrid();
}

MapGrid.prototype.resize = function(newScreenWidth, newScreenHeight) {
	if (this.currentView != null) {
		this.init(this.currentView.getCoordinates(), newScreenWidth, newScreenHeight);
	}
}

MapGrid.prototype.zoomToWindow = function(view) {
	var xMapSize = view.xmax - view.xmin;
	var yMapSize = view.ymax - view.ymin;

	var xUnitsPerPixel = xMapSize / this.screenWidth;
	var yUnitsPerPixel = yMapSize / this.screenHeight;

	var xLevel = Math.log(this.unitsPerPixelOnZoomZero / xUnitsPerPixel) / Math.log(2);
	var yLevel = Math.log(this.unitsPerPixelOnZoomZero / yUnitsPerPixel) / Math.log(2);

	this.zoomToLevel(Math.floor(Math.min(xLevel, yLevel)));
	this.pan(view);
}

MapGrid.prototype.panToPoint = function(x, y) {
	var xOffset = this.screenWidth  * this.unitsPerPixel / 2;
	var yOffset = this.screenHeight * this.unitsPerPixel / 2;	
	
	var newBBox = new BBox({ 
		xmin: x - xOffset, ymin: y - yOffset,
		xmax: x + xOffset, ymax: y + yOffset });

	if (this.currentView == null || !this.currentView.equals(newBBox)) {
		this.currentView = newBBox;
		this.reloadGrid();
	}	
}

MapGrid.prototype.pan = function(newView) {
	this.panToPoint(
		newView.xmin + (newView.xmax - newView.xmin) / 2, 
		newView.ymin + (newView.ymax - newView.ymin) / 2);
}

MapGrid.prototype.init = function(newView, newScreenWidth, newScreenHeight) {
	this.unitsPerPixel = this.unitsPerPixelOnZoomZero / Math.pow(2, this.z);
	
	this.tileSizeOnMap = this.tileSizeOnScreen * this.unitsPerPixel;
	this.pixelValue = 1 / this.unitsPerPixel;
	
	this.gridStartPointOnMap = { x: 0, y: 0 };
	
	newView.xmax = newView.xmin + newScreenWidth * this.unitsPerPixel;
	newView.ymax = newView.ymin + newScreenHeight * this.unitsPerPixel;

	this.currentView = new BBox(newView);
	this.screenWidth = newScreenWidth;
	this.screenHeight = newScreenHeight;
	
	this.reloadGrid();
}

MapGrid.prototype.reloadGrid = function() {
	// find first tile xmin and ymin
	this.gridStartPointOnMap = { 
		x: this.findGridStartPointOnMap(this.gridStartPointOnMap.x, this.currentView.xmin, this.offset.x),
		y: this.findGridStartPointOnMap(this.gridStartPointOnMap.y, this.currentView.ymin, this.offset.y)
	};
	
	var gridStartPointOnScreen = { 
		top: this.screenHeight - this.tileSizeOnScreen + this.findGridOffsetOnScreen(this.gridStartPointOnMap.y, this.currentView.ymin, this.offset.y),
		left: 0 - this.findGridOffsetOnScreen(this.gridStartPointOnMap.x, this.currentView.xmin, this.offset.x)
	};

	// calculate number of tiles
	this.xNumTiles = this.findTilesNumber(this.gridStartPointOnMap.x, this.currentView.xmax, this.offset.x);
	this.yNumTiles = this.findTilesNumber(this.gridStartPointOnMap.y, this.currentView.ymax, this.offset.y);

	// create all tiles
	var newGrid = new Array();
	for (var i = 0; i < this.xNumTiles; i++) {
		var column = new Array();
		for (var j = 0; j < this.yNumTiles; j++) {
			var xmin = (this.gridStartPointOnMap.x + i) * this.tileSizeOnMap + this.offset.x;
			var ymin = (this.gridStartPointOnMap.y + j) * this.tileSizeOnMap + this.offset.y;
			var xmax = xmin + this.tileSizeOnMap;
			var ymax = ymin + this.tileSizeOnMap;
			var top = gridStartPointOnScreen.top - j * this.tileSizeOnScreen;
			var left = gridStartPointOnScreen.left + i * this.tileSizeOnScreen;
			
			column.push(new Tile(this.gridStartPointOnMap.x + i, this.gridStartPointOnMap.y + j, this.z, 
				new BBox({ xmin: xmin, ymin: ymin, xmax: xmax, ymax: ymax }), 
				{ top: top, left: left }));			
		}
		newGrid.push(column);
	}
	
	this.grid = newGrid;
}

MapGrid.prototype.findGridStartPointOnMap = function(actual, min, offset) {
	if (min > ((actual + 1) * this.tileSizeOnMap + offset)) {
		while (min > ((actual + 1) * this.tileSizeOnMap + offset)) actual++;
	} else if (min < (actual * this.tileSizeOnMap + offset)) {
		while (min < (actual * this.tileSizeOnMap + offset)) actual--;
	}

	return actual;
}

MapGrid.prototype.findGridOffsetOnScreen = function(gridPosition, mapPosition, offset) {
	var mapOffset = Math.abs(mapPosition - (gridPosition * this.tileSizeOnMap + offset));
	return mapOffset * this.pixelValue;
}

MapGrid.prototype.findTilesNumber = function(gridStart, mapEnd, offset) {
	var tilesNumber = 1;
	var gridPointer = gridStart;
	while ((gridPointer * this.tileSizeOnMap + offset) < mapEnd) {
		gridPointer++;
		tilesNumber++;
	}
	
	return tilesNumber;
}

MapGrid.prototype.mapToScreen = function(x, y, convertOffScreen) {
	if (convertOffScreen || this.currentView.containsPoint(x, y)) {
		var offsetX = Math.round((x - this.currentView.xmin) / this.unitsPerPixel);
		var offsetY = Math.round((y - this.currentView.ymin) / this.unitsPerPixel);
		
		var top = this.screenHeight - offsetY;
		var left = offsetX;
		
		return { top: top, left: left };
	} else {
		return null;
	}
}

MapGrid.prototype.screenToMap = function(screenX, screenY) {
	return { x: this.currentView.xmin + (screenX / this.pixelValue), 
		y: this.currentView.ymax - (screenY / this.pixelValue) };
}

function TaskCounter(dbmap) {
	this.dbmap = dbmap;
	this.counter = 0;
	this.listeners = [];
}

TaskCounter.prototype = {
	
	addListener: function(listener) {
		this.listeners.push(listener);
	},

	removeListeners: function() {
		this.listeners = [];
	},

	set: function(value) {
		if (value < 0) value = 0;
		this.counter = value;
		this.notifyListeners();
	},

	get: function() {
		return this.counter;
	},

	increment: function() {
		this.set(this.counter + 1);
	},
	
	decrement: function() {
		this.set(this.counter - 1);
	},
		
	clean: function() {
		this.set(0);
	},
	
	notifyListeners: function() {
		for (var i = 0; i < this.listeners.length; i++) {
			this.listeners[i](this.counter, this.dbmap);
		}
	}
};/**
 * Enumerazione di modalit&agrave; utilizzabili 
 * @class
 */
var DbMAPMode = {
	/** @public */
	PAN: "PAN",
	/** @public */
	PICK_POINT: "PICK_POINT",
	/** @public */
	EDIT: "EDIT",	
	/** @public */
	MEASURE: "MEASURE",
	/** @public */
	NO_OPERATION: "NO_OPERATION"
};

/**
 * @class
 */
var DbMAPEntity = {
	/** @public */
	POINT: 1,
	/** @public */
	LINE: 3,
	/** @public */
	POLYGON: 5
};

/**
 * @class
 * 
 * @param id (string) id del DIV contenente la mappa
 * @param tileSize (int) dimensioni del Tile
 * @param unitsPerPixelOnZoomZero (double) a quante unit&agrave; di misura corrisponde un pixel al livello minimo di zoom
 * @param maxZ (int) livello massimo di zoom
 * @param initialLayers (WMSLayer o TileLayer) layer da visualizzare inizialmente
 * @param initialView (BBox) bounding box iniziale
 * @param customImageDir (string) directory delle immagini
 */
function DbMAP(id, tileSize, unitsPerPixelOnZoomZero, maxZ, initialLayers, initialView, gridOffset, customImageDir) {
	this.imageDir = customImageDir == null ? './images' : customImageDir;
	
	this.rnd = Math.round(Math.random() * 100);

	jg_zIndex = 990;
	
	var topDiv = $("<div />")
		.attr("id", id + "_topDiv")
		.css({ position: "absolute", background: "#ffffff", opacity: 0, zIndex: 150, visibility: "hidden" });
	topDiv.css("-moz-user-select", "none");
	
	var tooltipDiv = $("<div />").css({ position: "absolute", border: "1px #FCC90D solid", background: "#FDFFB4", padding:"2 2 2 2", display: "none" });

	var clickDiv = $("<div />").css({ position: "absolute", width: 5, height: 5, background: "#BB0000" });
	clickDiv.append($("<img />").attr("src", this.emptyImg()));
	this.defaultPickedPointMarker = new Marker(clickDiv, 2, 2, 'pickedPointMarker', 0, 0);
	this.pickedPointMarker = this.defaultPickedPointMarker;
			
	var map = $("#" + id).css({ position: "absolute" });
	map.data("dbmap", this);
	
	this.map = map;
	this.panContainer = $("<div />")
		.attr("id", this.id("panContainer"))
		.css({ position: "absolute", overflow: "hidden", width: this.map.css("width"), height: this.map.css("height") });
	
	this.map.wrap(this.panContainer);
	
	$("#" + this.id("panContainer")).append(tooltipDiv);
	$("#" + this.id("panContainer")).append(topDiv);
	
	this.topDiv = topDiv; // per coprire tutte le immagini
	
	this.coordinateListener = [];
	this.viewChangedListener = [];
	this.pickedPointListener = [];
	this.editListener = [];
	this.measureListener = [];
	this.draggingListener = [];
	
	this.tooltipProvider = null;
	this.tooltipDiv = tooltipDiv;
	this.overlays = [];
	
	this.cursorPan = 'move';
	this.cursorPick = 'crosshair';
	this.cursorNoOperation = 'default';
	
	this.mode = DbMAPMode.PAN;
	map.css({ cursor: this.cursorPan });
	
	this.isWheelZoomCenteredOnMousePosition = false;
	this.wheelTimeoutId = null;
	this.tipTimeoutId = null;
	this.wheelDelta = 0;
		
	var theWb = new Whiteboard(this); 
	this.editListener.push(function(mapPoint) { 
		theWb.onClick(mapPoint) 
	});
	this.addViewChangedListener(
		function(new_bbox){
			theWb.repaint(new_bbox)
		}
	);
	this.wb = theWb;
	
	this.layers = [];
	
	this.w = map.width();
	this.h = map.height();
	this.jg = null;

	this.markers = {};

	var loadingImg = $("<img />")
		.css({ visibility: "hidden", position: "absolute", top: 0, left: 0, zIndex: 999 })
		.attr("src", this.loadingImg());
	$("#" + this.id("panContainer")).append(loadingImg);
	
	this.taskCounter = new TaskCounter(this);
	this.taskCounter.addListener(function(taskInProgress, dbmap) {
		if (taskInProgress > 0) {
			var top = Math.round(dbmap.h / 2)
			var left = Math.round(dbmap.w / 2);
			
			loadingImg.css({ visibility: "visible", top: top, left: left });
		} else {
			loadingImg.css({ visibility: "hidden" });			
		}
	});

	this.initialView = initialView;
	this.tileSize = tileSize;
	this.mapGrid = new MapGrid(tileSize, unitsPerPixelOnZoomZero, maxZ, gridOffset);
	this.mapGrid.init(initialView, this.w, this.h);
	
	// Eventi...
	
	$(window).resize(function() {
		var dbmap = map.data("dbmap");
		if (!__U.isUndef(dbmap) && dbmap.watchWindowResize && dbmap.mapGrid.currentView != null) {
			var changed = false;
			if (dbmap.w != map.width()) { 
				changed = true; 
				dbmap.w = map.width() 
			};
			
			if (dbmap.h != map.height()) { 
				changed = true; 
				dbmap.h = map.height() 
			};
			
			if (changed) {
				dbmap.setSize(dbmap.w, dbmap.h);
			}
		}
	});

	topDiv.mousedown(function(event) {
		var dbmap = map.data("dbmap");
		
		if (dbmap.mode == DbMAPMode.NO_OPERATION) return;
		
		if (dbmap.mode == DbMAPMode.PICK_POINT) {
			var pt = __U.point(event.pageX, event.pageY, map);
			if (dbmap.pickedPointMarker != null) {
				dbmap.pickedPointMarker.node.attr('id', dbmap.pickedPointMarker.id);
				dbmap.pickedPointMarker.node.css({ 
					top: pt.y - dbmap.pickedPointMarker.offsetTop, 
					left: pt.x - dbmap.pickedPointMarker.offsetLeft });
				$("#" + dbmap.id("panContainer")).append(dbmap.pickedPointMarker.node);
			}
			dbmap.notifyCoordinateListener(event.pageX, event.pageY, dbmap.pickedPointListener);
		} else if (dbmap.mode == DbMAPMode.EDIT) {
			dbmap.notifyCoordinateListener(event.pageX, event.pageY, dbmap.editListener);			
		} else if (dbmap.mode == DbMAPMode.MEASURE) {
			if (map.data("measure") == null) {
				map.data("measure", []);
			}
			
			var pt = __U.point(event.pageX, event.pageY, map);
			var points = map.data("measure");
			points.push(pt);
			
			dbmap.jg.fillRect(pt.x - 2, pt.y - 2, 5, 5);
			if (points.length > 1) {
				dbmap.jg.drawLine(points[points.length - 2].x, points[points.length - 2].y, pt.x, pt.y);
				
				var ptA, ptB;
				var curPt = dbmap.mapToWorld(pt.x, pt.y);
				var evt = { "map": dbmap, length: 0.0, area: 0.0, x: curPt.x, y: curPt.y };
				
				// perimetro
				
				for (var i = 1; i < points.length; i++) {
					ptA = dbmap.mapToWorld(points[i - 1].x, points[i - 1].y);
					ptB = dbmap.mapToWorld(points[i].x, points[i].y);
					evt.length += dbmap.getDistance(ptA, ptB);
				}
				
				// area 
				// http://alienryderflex.com/polygon_area/				
				if (points.length > 2) {
					var areaFunction;
					if (dbmap.mapGrid.referenceSystemIsLatLon) {
						areaFunction = function(ptA, ptB) { return 0; };
					} else {
						areaFunction = function(ptA, ptB) {	return (ptA.x * ptB.y) - (ptB.x * ptA.y); };
					}
					
					for (var i = 1; i < points.length; i++) {
						ptA = dbmap.mapToWorld(points[i - 1].x, points[i - 1].y);
						ptB = dbmap.mapToWorld(points[i].x, points[i].y);
						evt.area += areaFunction(ptA, ptB);
					}
					ptA = dbmap.mapToWorld(points[points.length - 1].x, points[points.length - 1].y);
					ptB = dbmap.mapToWorld(points[0].x, points[0].y);
					evt.area += areaFunction(ptA, ptB);
					evt.area = Math.abs(evt.area);
					if (!dbmap.mapGrid.referenceSystemIsLatLon) {
						evt.area = evt.area / 2.0;
					}
				}
				
				__U.notifyListeners(dbmap.measureListener, evt);
			}
			
			dbmap.jg.paint();
		}
	});
	
	topDiv.mousemove(function(event) {
		var dbmap = map.data("dbmap");
		if (dbmap.mode != DbMAPMode.MEASURE && !map.data("mousedown")) {
			dbmap.handleTooltip(event);
			dbmap.notifyCoordinateListener(event.pageX, event.pageY);
		}
	});

	map.mousemove(function(event) {
		var dbmap = map.data("dbmap");
		
		dbmap.handleTooltip(event);
		dbmap.notifyCoordinateListener(event.pageX, event.pageY);
	});
	
	map.mousewheel(function(event, delta) {
		var dbmap = map.data("dbmap");
		
		if (dbmap.mode == DbMAPMode.NO_OPERATION) return;
		
		if (dbmap.wheelTimeoutId != null) {
			clearTimeout(dbmap.wheelTimeoutId);
			dbmap.wheelTimeoutId = null;
		}
		
		dbmap.wheelDelta += delta;
		dbmap.lastMousePosX = event.pageX;
		dbmap.lastMousePosY = event.pageY;
		
		dbmap.wheelTimeoutId = setTimeout(function() { dbmap.wheelZoom(); }, 200);
		
		return false;
	});
	
	map.draggable({
		cursor: 'move',
		revert: true,
		revertDuration: 0,
		start: function(event, ui) {
			var dbmap = map.data("dbmap");
			dbmap.notifyDraggingListener();			
		},
		stop: function(event, ui) {
			var dbmap = map.data("dbmap");
			
			var deltaX = (ui.position.left / dbmap.mapGrid.pixelValue);
			var deltaY = (ui.position.top / dbmap.mapGrid.pixelValue);
			var bbox = {
				xmin: dbmap.mapGrid.currentView.xmin - deltaX,
				xmax: dbmap.mapGrid.currentView.xmax - deltaX,
				ymin: dbmap.mapGrid.currentView.ymin + deltaY,
				ymax: dbmap.mapGrid.currentView.ymax + deltaY
			};

			dbmap.hideImages();

			dbmap.pan(bbox);
		}
	});
	
	if (!__U.isUndef(initialLayers)) {
		if (!initialLayers.length) {
			this.addLayer(initialLayers, false);
		} else {
			for (var i = 0; i < initialLayers.length; i++) {
				this.addLayer(initialLayers[i], false);
			}
		}
	}	
}

DbMAP.prototype = {
	watchWindowResize: false,
	
	/**
	 * @private
	 */
	id: function(base) {
		return "_" + this.rnd + "_" + base;
	},
	
	/**
	 * Convert degrees to radians
	 * 
	 * @private
	 */
	toRad: function(degree) {
  		return degree * Math.PI / 180;
	},
	
	/**
	 * Calcola la distanza tra due punti
	 */
	getDistance: function(ptA, ptB) {
		if (this.mapGrid.referenceSystemIsLatLon) {
			var lon1 = this.toRad(ptA.x);
			var lat1 = this.toRad(ptA.y);
			var lon2 = this.toRad(ptB.x);
			var lat2 = this.toRad(ptB.y);
			
			// http://www.movable-type.co.uk/scripts/latlong.js
			var R = 6371000; // m
			return Math.acos(Math.sin(lat1) * Math.sin(lat2) 
				+ Math.cos(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1)) * R;
		} else {
			return Math.sqrt(Math.pow(ptA.x - ptB.x, 2) + Math.pow(ptA.y - ptB.y, 2));
		}
	},
	
	/**
	 * @private
	 */
	addImg: function(src) {		
		this.taskCounter.increment();

		var mapId = '#' + this.map.attr('id');

		var img = $('<img onLoad="$(\'' + mapId + '\').data(\'dbmap\').taskCounter.decrement()" />');
		img.css({ margin: "0px", padding: "0px", border: "0px none", width: this.tileSize, height: this.tileSize });
		img.css("-moz-user-select", "none");
	
		this.map.append(img);		
		
		img.attr('src', src);
		
		return img;
	},

	/**
	 * Aggiunge un DIV (Marker) sopra una determinata coordinata della mappa
	 * 
	 * @param marker (Marker) istanza di Marker
	 */
	addMarker: function(marker) {
		if (this.markers[marker.id] != null) {
			this.removeMarker(marker.id);
		}
		
		marker.node.attr('id', marker.id);

		var screenPosition = this.mapGrid.mapToScreen(marker.x, marker.y, marker.insertEvenIfOffScreen);
		if (screenPosition != null) {		
			marker.node.css({ display: "", position: "absolute", 
				top: screenPosition.top - marker.offsetTop, 
				left: screenPosition.left - marker.offsetLeft });
			marker.node.css("z-index", 159);			
		} else {
			marker.node.css({ display: "none" });			
		}

		this.map.append(marker.node);
		this.markers[marker.id] = marker;
	},

	/**
	 * Rimuove un Marker
	 * 
	 * @param uniqueId (string) id del DIV
	 */
	removeMarker: function(uniqueId) {
		$('#' + uniqueId).remove();
		delete this.markers[uniqueId];
	},

	/**
	 * Rimuove tutti i Markers
	 */
	removeMarkers: function() {
		for (var uniqueId in this.markers) {
  			this.removeMarker(uniqueId);
		}
	},

	/**
	 * Nasconde tutti i Marker
	 */
	hideMarkers: function() {
		for (var id in this.markers) {
			var marker = this.markers[id];
			marker.node.css("display", "none");			
		}
	},
	
	/**
	 * Mostra tutti i Marker
	 */
	showMarkers: function() {
		for (var id in this.markers) {
			var marker = this.markers[id];

			var screenPosition = this.mapGrid.mapToScreen(marker.x, marker.y, marker.insertEvenIfOffScreen);
			if (screenPosition != null) {		
				marker.node.css({ display: "", position: "absolute", 
					top: screenPosition.top - marker.offsetTop, 
					left: screenPosition.left - marker.offsetLeft });
				marker.node.css("z-index", 159);	
			} else {
				marker.node.css({ display: "none" });			
			}
		}
	},

	/**
	 * Aggiunge un Layer
	 * 
	 * @param layer (Layer) layer da aggiungere
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	addLayer: function(layer, repaint) {
		this.layers.push(layer);		
		if (repaint) this.repaint();
	},
	
	/**
	 * Rimuove un Layer
	 * 
	 * @param layer (Layer) layer da rimuovere
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	removeLayer: function(layer, repaint) {
		var index = -1;
		for (var i = 0; i < this.layers.length; i++) {
			if (this.layers[i] == layer) index = i;
		}
		
		if (index > -1) {
			var layer = this.layers[index];
			layer.setVisible(false);
			
			// remove layer images
			this.repaint();
			
			// splice: remove one element at the given index
			this.layers.splice(index, 1);
			
			this.repaint();
		} else {
			// TODO tmp
			alert('Layer NOT found');
		}
	},
	
	/**
	 * Imposta le dimensioni della mappa
	 * 
	 * @param w (int) width
	 * @param h (int) height
	 */
	setSize: function(w, h) {
		this.w = w;
		this.h = h;
		
		$("#" + this.id("panContainer")).css({ width: this.w, height: this.h });
		this.map.css({ width: this.w, height: this.h });
		
		if (this.mapGrid.currentView != null) {
			this.mapGrid.resize(this.w, this.h);
			this.notifyViewChangedListener(false);	
			this.repaint();
		}
	},
	
	/**
	 * Aggiunge componente alla mappa
	 * 
	 * @param obj (div html) un div da sovrapporre alla mappa
	 */
	addOverlay: function(obj) {
		this.overlays.push(obj);
		if (obj.getGUI) {
			var gui = obj.getGUI();
			if (gui != null) $("#" + this.id("panContainer")).append($(gui).css("zIndex", "160"));
		}
	},
	
	/**
	 * @private
	 */
	notifyDraggingListener: function() {
		__U.notifyListeners(this.draggingListener);
	},
	
	addDraggingListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.draggingListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'cambio di coordinata'. 
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x e y, coordinate della mappa.
	 * 
	 * Esempio: 
	 * dbmap.addCoordinateListener(function(evt) {
	 * 	alert('coordinate x=' + evt.x + ', y=' + evt.y);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addCoordinateListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.coordinateListener.push(listener);
		}
	},
	
	/**
	 * @private
	 */
	notifyCoordinateListener: function(screenX, screenY, listeners) {
		var wc = this.screenToWorld(screenX, screenY);
		wc["map"] = this;
		__U.notifyListeners(listeners || this.coordinateListener, wc);
	},
	
	/**
	 * @private
	 */
	screenToWorld: function(screenX, screenY) {
		var pos = $(this.map).offset();
		return this.mapToWorld(screenX - pos.left, screenY - pos.top);
	},
	
	/**
	 * @private
	 */
	mapToWorld: function(mapX, mapY) {
		return this.mapGrid.screenToMap(mapX, mapY);
	},

	/**
	 * Aggiunge un listener dell'evento 'vista modificata'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto BBox.
	 * 
	 * Esempio: 
	 * dbmap.addViewChangedListener(function(evt) {
	 * 	alert('bbox xmin=' + evt.xmin + ', ymin=' + evt.ymin + ', xmax=' + evt.xmax + ', ymax=' + evt.ymax);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addViewChangedListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.viewChangedListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'selezionato punto'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x e y.
	 * 
	 * Esempio: 
	 * dbmap.addPickedPointListener(function(evt) {
	 * 	alert('coordinate x=' + evt.x + ', y=' + evt.y);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addPickedPointListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.pickedPointListener.push(listener);
		}
	},
	
	/**
	 * Aggiunge un listener dell'evento 'effettuata misurazione'.
	 * Il listener deve essere una funzione che prende come parametro un oggetto 
	 * con le propriet&agrave; x, y, length e area.
	 * 
	 * Esempio: 
	 * dbmap.addMeasureListener(function(evt) {
	 * 	alert('measure x=' + evt.x + ', y=' + evt.y + ', length=' + evt.length + ', area = ' + evt.area);
	 * });
	 * 
	 * @param listener (funzione) funzione da invocare
	 */
	addMeasureListener: function(listener) {
		if (typeof(listener) == 'function') {
			this.measureListener.push(listener);
		}
	},
	
	/**
	 * Imposta il fornitore di suggerimenti
	 * 
	 * @param p (tooltip provider) instanza di TooltipProvider
	 */
	setTooltipProvider: function(p) {
		this.tooltipProvider = p;
	},
	
	/**
	 * Visualizza un tooltip alle coordinate specificate
	 * 
	 * @param html (div html) div contenente il tooltip
	 * @param x (int) coordinata x dello schermo
	 * @param y (int) coordinata y dello schermo
	 */
	showTooltip: function(html, x, y) {
		this.tooltipDiv.html(html).css({ left: x, top: y }).show();
	},
	
	/**
	 * @private
	 */
	handleTooltip: function(event) {
		if (this.tooltipProvider != null) {
			this.tooltipDiv.hide();
			if (this.tipTimeoutId != null) clearTimeout(this.tipTimeoutId);
			var dbmap = this;
			var callback = function() { dbmap.tooltipProvider(__U.point(event.pageX, event.pageY, dbmap.map), dbmap.screenToWorld(event.pageX, event.pageY)) };
			this.tipTimeoutId = setTimeout(callback, 200);
		}
	},
	
	/**
	 * @private
	 */
	removePickedPointMarker: function() {
		if (this.pickedPointMarker != null) {
			$('#' + this.pickedPointMarker.id).remove();
		}
	},
	
	/**
	 * @private
	 */
	notifyViewChangedListener: function(paintEnd) {
		this.removePickedPointMarker();
		
		if (this.jg != null && this.mode == DbMAPMode.MEASURE) {
			this.jg.clear();
			this.map.data("measure", []);
			__U.notifyListeners(this.measureListener, { x: 0, y: 0, length: 0, area: 0, "map": this });
		}		
		
		var bbox = this.mapGrid.currentView.getCoordinates();
		bbox.dbmap = this;
		bbox.paintEnd = paintEnd; 
		
		// Notifico prima gli overlay...
		for (var i = 0; i < this.overlays.length; i++) {
			if (this.overlays[i].viewChanged) this.overlays[i].viewChanged(bbox);
		}
		
		// poi i listeners
		__U.notifyListeners(this.viewChangedListener, bbox);
	},

	/**
	 * @private
	 */
	changeCursor: function(newCursor) {
		this.map.css({ cursor: newCursor });
	},

	/**
	 * Imposta lo strumento da usare, una delle costanti di DbMAPMode
	 * 
	 * @param newMode (string) una delle costanti di DbMAPMode
	 */
	setMode: function(newMode) {
		this.removePickedPointMarker();
		
		if (this.jg != null) this.jg.clear();
		this.map.data("mousedown", false);
		this.map.data("measure", null);
		
		this.mode = newMode;
		
		var topDivVisible = false;
		if (newMode == DbMAPMode.PICK_POINT || newMode == DbMAPMode.EDIT || newMode == DbMAPMode.MEASURE) {
			this.changeCursor(this.cursorPick);
			
			this.map.draggable('disable');
			
			topDivVisible = true;
			this.topDiv.css({ 
				visibility: "visible",
				top: 0, left: 0,
				width: this.w,
				height: this.h
			});
			
			if (newMode == DbMAPMode.MEASURE && this.jg == null) {
				this.jg = new jsGraphics($(this.map).get(0));
				this.jg.setColor("#ff0000");
				this.jg.setStroke(2);
			}
		} else if (newMode == DbMAPMode.PAN) {
			this.changeCursor(this.cursorPan);
			
			this.map.draggable('enable');
			
			this.topDiv.css({ visibility: "hidden", top: 0, left: 0, width: 0, height: 0 });
		} else if (newMode == DbMAPMode.NO_OPERATION) {
			this.changeCursor(this.cursorNoOperation);
			
			this.map.draggable('disable');
			
			this.topDiv.css({ visibility: "hidden", top: 0, left: 0, width: 0, height: 0 });
		}
	},

	/**
	 * Ricarica
	 * 
	 * @param zoomLevel (int) livello di zoom da cui partire
	 */
	reload: function(zoomLevel) {
		this.mapGrid.zoomToLevel(zoomLevel);
		this.mapGrid.init(this.initialView, this.w, this.h);
		
		this.notifyViewChangedListener(false);	
		this.repaint();
	},

	/**
	 * Sposta la mappa nel riquadro passato, mantenendo lo stesso livello di zoom
	 * 
	 * @param bbox (BBox) bounding box { xmin: ..., ymin: ..., xmax: ..., ymax: ... }
	 */
	pan: function(bbox) {
		this.mapGrid.pan(bbox);
		this.notifyViewChangedListener(false);	
		this.repaint();
	},
	
	/**
	 * Centra la mappa sul punto passato
	 * 
	 * @param x (double) coordinata x della mappa
	 * @param y (double) coordinata y della mappa
	 */
	panToPoint: function(x, y) {
		this.mapGrid.panToPoint(x, y);
		this.notifyViewChangedListener(false);
		this.repaint();
	},
	
	/**
	 * Aumenta il livello di zoom
	 */
	zoomIn: function() {
		if (this.mapGrid.zoomIn()) {
			this.notifyViewChangedListener(false);			
			this.repaint();
		}
	},
	
	/**
	 * Diminuisci il livello di zoom
	 */
	zoomOut: function() {
		if (this.mapGrid.zoomOut()) {
			this.notifyViewChangedListener(false);			
			this.repaint();
		}
	},
	
	/**
	 * Visualizza il bounding box passato al massimo livello di zoom possibile
	 * 
	 * @param view (BBox) area di zoom
	 */
	zoomToWindow: function(view) {
		this.mapGrid.zoomToWindow(view);
		this.notifyViewChangedListener(false);
		this.repaint();
	},
	
	/**
	 * Imposta un determinato livello di zoom
	 * 
	 * @param newZ (int) livello di zoom
	 * @param notify (boolean) notificare i listener?
	 * @param repaint (boolean) ridisegnare la mappa?
	 */
	zoomToLevel: function(newZ, notify, repaint) {
		this.mapGrid.zoomToLevel(newZ);
		
		if (notify) {
			this.notifyViewChangedListener(false);
		}
		
		if (repaint) {
			this.repaint();
		}
	},
	
	/**
	 * Ridisegna
	 */
	repaint: function() {
		this.hideMarkers();
		
		this.taskCounter.clean();
		
		for (var i = 0; i < this.layers.length; i++) {
			this.layers[i].repaint(this, i);
		}
		
		this.showMarkers();
	},

	/**
	 * @private
	 */
	hideImages: function() {
		for (var i = 0; i < this.layers.length; i++) {
			this.layers[i].hideImages(this);
		}
	},
	
	/**
	 * Imposta la directory delle immagini
	 */
	setImageDir: function(imageDir) {
		this.imageDir = imageDir;
	},
	
	/**
	 * Restituisce la directory delle immagini
	 */
	getImageDir: function() {
		return this.imageDir;
	},
	
	/**
	 * @private
	 */
	emptyImg: function() {
		return this.getImageDir() + '/dbmap/trasp.gif';
	},
	
	/**
	 * @private
	 */	
	loadingImg: function() {
		return this.getImageDir() + '/dbmap/loading.gif';
	},	
	
	/**
	 * Ritorna la scala
	 */
	getScale: function() {
		return this.mapGrid.getScale();
	},

	/*
	 * Ricarica il layer specificato
	 * 
	 * @param layerIndex (int) indice del Layer
	 */
	reloadLayer: function(layerIndex) {
		var layer = this.layers[layerIndex];
		if (layer != null) {
			layer.setVisible(false);
			this.repaint();
			
			var d = new Date();
			
			layer.addParam('refresh', 't' + d.getTime());
			layer.setVisible(true);
			this.repaint();
		}
	},

	/**
	 * Restituisce l'url per una richiesta GetFeatureInfo al server WMS
	 * 
	 * @param wmsLayer (Layer) server wms al quale collegarsi
	 * @param layerIndex (int) indice del layer
	 * @param format (string) formato in cui si vuole la risposta della GetFeatureInfo (esempio: 'text/html')
	 * @param point (object) punto di cui si vogliono visualizzare le informazioni { x: ..., y: ...}
	 */
	getFeatureInfoUrl: function(wmsLayer, layerIndex, format, point) {
		var view = this.mapGrid.currentView;
		
		var url = wmsLayer.props.url;
		url += (url.indexOf('?') > -1 ? '&' : '?');
		url += 'VERSION=1.1.1&REQUEST=GetFeatureInfo';
		url += '&SRS=' + escape(wmsLayer.props.srs);
		url += '&FORMAT=' + escape(format);
		url += '&WIDTH=' + this.w + '&HEIGHT=' + this.h + '&BBOX=' + view.xmin + ',' + view.ymin + ',' + view.xmax + ',' + view.ymax;
		url += '&X=' + point.x + '&Y=' + point.y;
		url += '&QUERY_LAYERS=' + wmsLayer.props.layers[layerIndex].name;
		url += '&LAYERS=' + wmsLayer.props.layers[layerIndex].name;
		
		return url;
	},

	/**
	 * Attiva la modalit&agrave; di disegno di una nuova entit&agrave;
	 * 
	 * @param entityType (string) il tipo di elemento che si vuole creare
	 */
	drawNew: function(entityType) {
		this.wb.add(entityType);	
		this.startDrawing();			
	},
	
	/**
	 * Attiva la modalit&agrave; di disegno di un'entit&agrave; esistente
	 * 
	 * @param entityType (string) il tipo di elemento che si vuole modificare
	 * @param entityId (int) il codice identificativo dell'elemento che si vuole modificare
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	draw: function(entityType, id, asjServlet, table, idField, geomField) {
		var callparams = "?function=select_sdastring";
		callparams += "&TableName=" + table;	
		callparams += "&IdentField=" + idField;
		callparams += "&ElemId=" + id;
		callparams += "&GeometryField=" + geomField;
				
		var error = false;
		var responseText = $.ajax({
			type: 'POST',
			url: asjServlet + callparams,
		  	async: false,
		  	error: function() {
		  		error = true;
		  		alert('Errore durante la chiamata al server');
		  	}
		}).responseText;
		 
		if (error) return;
		
		if (responseText.indexOf('SIT_RETCODE:-1000|NO RECORD FOUND') != -1) {
			alert('Elemento non trovato');
			return;
		} else if (responseText.indexOf('SIT_RETCODE:0|') == -1) {
			alert('Errore imprevisto: ' + responseText);
			return;
		}
		
		// strip header
		responseText = this.stripSdaTokens(responseText, 2);
		
		// strip bbox
		responseText = responseText.substring(responseText.indexOf('&'));

		// read type
		var type = this.readSdaInt(responseText);
		responseText = this.stripSdaToken(responseText);
		
		// check type validity
		
		if (type == 1 && entityType != DbMAPEntity.POINT) {
			alert('L\'elemento trovato non � un Punto');
			return;			
		} else if (type == 3 && entityType != DbMAPEntity.LINE) {
			alert('L\'elemento trovato non � una Linea');
			return;			
		} else if (type == 5 && entityType != DbMAPEntity.POLYGON) {
			alert('L\'elemento trovato non � un Poligono');
			return;			
		}
		
		// strip num of dims (must be 2)
		responseText = this.stripSdaToken(responseText);
		
		// read coordinates

		var points = new Array();
		
		if (entityType == DbMAPEntity.POINT) {
			points.push(this.readSdaPoint(responseText));
		} else if (entityType == DbMAPEntity.LINE || entityType == DbMAPEntity.POLYGON) {
			// strip num of parts (must be 1)
			responseText = this.stripSdaToken(responseText);
			
			// read num of points
			var numOfPoints = this.readSdaInt(responseText);
			responseText = this.stripSdaToken(responseText);

			// strip num of points per part (must be equal to num of points)
			responseText = this.stripSdaToken(responseText);
			
			for (var i = 0; i < numOfPoints; i++) {
				points.push(this.readSdaPoint(responseText));
				responseText = this.stripSdaTokens(responseText, 2);
			}
		}
					
		this.wb.edit(entityType, id, points);
		this.startDrawing();		
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, aggiungi un nuovo vertice a quelli esistenti
	 */
	appendVertex: function() {
		this.wb.appendVertex();
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, sposta il vertice pi� vicino al click del mouse
	 */	
	moveVertex: function() {
		this.wb.moveVertex();
	},

	/**
	 * Durante la modalit&agrave; di disegno, inserisci un nuovo vertice nel segmento pi� vicino al click del mouse
	 */	
	insertVertex: function() {
		this.wb.insertVertex();
	},
	
	/**
	 * Durante la modalit&agrave; di disegno, elimina il vertice pi� vicino al click del mouse
	 */
	deleteVertex: function(){
		this.wb.deleteVertex();
	},
	
	/**
	 * Termina la modalit&agrave; "disegno"
	 */
	stopDrawing: function() {
		this.wb.stop();
		this.wb.clear();
		this.setMode(DbMAPMode.PAN);
	},

	/*
	 * Ritorna l'elenco dei punti dell'entit&agrave; disegnata
	 */
	getDrawnEntity: function() {
		return this.wb.getPoints();
	},

	/**
	 * Ritorna il codice identificativo dell'entit&agrave; disegnata
	 */
	getDrawnEntityId: function() {
		return this.wb.getId();
	},

	/**
	 * Ritorna il tipo dell'entit&agrave; disegnata
	 */
	getDrawnEntityType: function() {
		return this.wb.getType();
	},

	/**
	 * Inserisce l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param id (string) id univoco dell'elemento 
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	insertDrawnEntity: function(id, asjServlet, table, idField, geomField) {
		return this.saveEntity(this.getDrawnEntityType(), id, this.getDrawnEntity(), asjServlet, table, idField, geomField, true);
	},

	/**
	 * Aggiorna l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 */
	updateDrawnEntity: function(asjServlet, table, idField, geomField) {
		return this.saveEntity(this.getDrawnEntityType(), this.getDrawnEntityId(), this.getDrawnEntity(), asjServlet, table, idField, geomField, false);
	},
		 
	/**
	 * Salva l'entit&agrave; attraverso ASJ Servlet
	 * 
	 * @param entityType (string) una costante di DbMAPEntity
	 * @param id (string) id univoco dell'elemento 
	 * @param coords (array) lista di coordinate che definiscono l'entit&agrave;
	 * @param asjServlet (string) indirizzo del servizio ASJ
	 * @param table (string) tabella di destinazione
	 * @param idField (string) campo identificativo
	 * @param geomField (string) campo geometria
	 * @param isNew (boolean) nuovo elemento?
	 */
	saveEntity: function(entityType, id, coords, asjServlet, table, idField, geomField, isNew) {
		if (this.mode != DbMAPMode.EDIT) return null;
		
		var callparams = "?function=updateext";
		callparams += "&TableName=" + table;
		
		if (isNew) callparams += "&EDITING=I";
		else callparams += "&EDITING=U";
		
		callparams += "&GeometryField=" + geomField;
		if (id != null) {
			if (isNew) {
				callparams += "&field_" + idField + "=" + id;
			} else {
				callparams += "&IdentField=" + idField + "&ElemId=" + id;
			}
		}

		callparams += "&SDAString=";
		
		var sdaString;
		if (entityType == DbMAPEntity.POINT) {
			sdaString = "#" + coords[0].x + "|#" + coords[0].y + "|#" + coords[0].x + "|#" + coords[0].y + 
				"|&1|&2|#" + coords[0].x + "|#" + coords[0].y;	
		} else if (entityType == DbMAPEntity.LINE) {
			var coordStr = "";
			var min_x = coords[0].x;
		 	var min_y = coords[0].y;
			var max_x = coords[0].x;
		 	var max_y = coords[0].y;
		 	
		 	for (var i = 0; i < coords.length; i++) {
		 		min_x = Math.min(coords[i].x, min_x);
		 		max_x = Math.max(coords[i].x, max_x);
		 		min_y = Math.min(coords[i].y, min_y);
		 		max_y = Math.max(coords[i].y, max_y);
		 		coordStr += "|#" + coords[i].x + "|#" + coords[i].y;
		 	}
			
			sdaString = "#" + min_x + "|#" + min_y + "|#" + max_x + "|#" + max_y + 
				"|&3|&2|&1|&" + coords.length + "|&" + coords.length + coordStr;
		} else if (entityType == DbMAPEntity.POLYGON) {
			var coordStr = "";
			var min_x = coords[0].x;
		 	var min_y = coords[0].y;
			var max_x = coords[0].x;
		 	var max_y = coords[0].y;
		 	
		 	for (var i = 0; i < coords.length; i++) {
		 		min_x = Math.min(coords[i].x, min_x);
		 		max_x = Math.max(coords[i].x, max_x);
		 		min_y = Math.min(coords[i].y, min_y);
		 		max_y = Math.max(coords[i].y, max_y);
		 			
	 			coordStr += "|#" + coords[i].x + "|#" + coords[i].y;
		 	}
			
			sdaString = "#" + min_x + "|#" + min_y + "|#" + max_x + "|#" + max_y + 
				"|&5|&2|&1|&" + coords.length + "|&" + coords.length + coordStr;
		}
		callparams += escape(sdaString);
		
		var esito = "";
				
		$.ajax({
			type: "POST",
			async: false,
			url: asjServlet + callparams,
			success: function(data) {
				esito = data;
			},
			error: function(data) {
				esito = data;
			}
		});
		
		this.stopDrawing();
		
		return esito;
	 },

	/**
	 * @private
	 */		 
	startDrawing: function() {
	    this.setMode(DbMAPMode.EDIT);
	},
	
	/**
	 * @private
	 */		 
	 readSdaPoint: function(text) {
	 	var x = this.readSdaDouble(text);
		text = this.stripSdaToken(text);
		var y = this.readSdaDouble(text);
		return { x: x, y: y };
	 },
		 
	/**
	 * @private
	 */		 
	readSdaInt: function(text) {
		if (text == null || text.indexOf('&') != 0) {
			alert('Not a INT:' + text);
			return null;
		}
		
		if (text.indexOf('|') != -1) {
			return text.substring(1, text.indexOf('|'));
		} else {
			// this is the last token
			return text.substring(1);
		}
	},

	/**
	 * @private
	 */		 
	readSdaDouble: function(text) {
		if (text == null || text.indexOf('#') != 0) {
			alert('Not a DOUBLE:' + text);
			return null;
		}
		
		if (text.indexOf('|') != -1) {
			return text.substring(1, text.indexOf('|'));
		} else {
			// this is the last token
			return text.substring(1);
		}
	},

	/**
	 * @private
	 */		 
	stripSdaToken: function(text) {
		return this.stripSdaTokens(text, 1);
	},
		
	/**
	 * @private
	 */		 
	stripSdaTokens: function(text, num) {
		if (text == null || text.length == 0) return text;
		
		for (var i = 0; i < num; i++) {
			text = text.substring(text.indexOf('|') + 1);
		}
		return text;
	},
	
	/**
	 * @private
	 */
	wheelZoom: function() {
		this.mapGrid.zoomToLevel(this.mapGrid.getZoomLevel() + this.wheelDelta);

		if (this.isWheelZoomCenteredOnMousePosition) {		
			var mapPoint = this.screenToWorld(this.lastMousePosX, this.lastMousePosY);
			this.mapGrid.panToPoint(mapPoint.x, mapPoint.y);
		}
		
		this.wheelDelta = 0;
		this.wheelTimeoutId = null;
		this.notifyViewChangedListener(false);			
		this.repaint();				
	}
}

/* *********************************************** */

var __U = function() {
	var rnd = Math.round(Math.random() * 100);
	return {
		isUndef: function(o) {
			return (typeof(o) == 'undefined');
		},
		
		clone: function(o) {
			function c(o) {
				for (i in o) this[i] = o[i];
			}
			return new c(o);
		},
		
		screenBbox: function(x1, y1, x2, y2, objForOffset) {
			var pos = typeof(objForOffset) == 'undefined' ? { top:0, left:0} : $(objForOffset).offset();
			
			x1 -= pos.left;
			x2 -= pos.left;
			y1 -= pos.top;
			y2 -= pos.top;
			
			return { xmin: Math.min(x1, x2), ymin: Math.min(y1, y2), xmax: Math.max(x1, x2), ymax: Math.max(y1, y2) };
		},
		
		point: function(px, py, objForOffset) {
			var pos = typeof(objForOffset) == 'undefined' ? { top:0, left:0} : $(objForOffset).offset();
			px -= pos.left;
			py -= pos.top;
			return { x: px, y: py };
		},
		
		notifyListeners: function(listeners, evt) {
			for ( var i = 0; i < listeners.length; i++) {
				listeners[i](evt);
			}
		}
	}
}();
function Layer(props) {
	this.usable = true;
	
	var p = props || {};
	
	if (__U.isUndef(p.transparent)) p.transparent = false;
	if (__U.isUndef(p.format)) p.format = p.transparent ? "image/png" : "image/jpeg";
	if (__U.isUndef(p.bgcolor)) p.bgcolor = "0xffffff";
	if (__U.isUndef(p.layers))  p.layers = null;
	if (__U.isUndef(p.srs))  p.srs = "none";
	if (__U.isUndef(p.visible))  p.visible = true;
	if (__U.isUndef(p.zoomMin))  p.zoomMin = -1;
	if (__U.isUndef(p.zoomMax))  p.zoomMax = -1;
	if (__U.isUndef(p.opacity))  p.opacity = null;
				
	var layers = [];
	if (p.layers != null) {
		var userLayers = p.layers;
		for (var i = 0; i < p.layers.length; i++) {
			if (typeof(p.layers[i]) == 'string') {
				layers[i] = { name: p.layers[i], visible: true, default_theme_name: '', themes: [] };
			} else {
				layers[i] = p.layers[i];
			}
		}
	}
	p.layers = layers;
	
	if (p.name) this.name = p.name;
	
	this.props = p;
	
	this.extraParams = [];
}

/**
 * @private
 */
Layer.prototype.isVisibleInZoom = function(zoom) {
	return (this.props.zoomMin < 0 || zoom >= this.props.zoomMin) &&
		(this.props.zoomMax < 0 || zoom <= this.props.zoomMax); 
}

/**
 * Imposta la visibilit&agrave; del layer
 */
Layer.prototype.setVisible = function(visible) {
    this.props.visible = visible;
}

Layer.prototype.setName = function(name) { 
	this.name = name;
}

/**
 * aggiunge un parametro al layer, il parametro viene inviato nella chiamata al server WMS
 */
Layer.prototype.addParam = function(n, v) {
	var ok = true;
	for (var i = 0; ok && i < this.extraParams.length; i++) {
		if (this.extraParams[i].name == name) {
			this.extraParams[i].value = value;
			ok = false;
		}
	}
	if (ok) this.extraParams.push({name: n, value: v});
}
	
/**
 * Rimuove tutti i parametri aggiunti
 */
Layer.prototype.clearParams = function() {
	this.extraParams = [];
}
	
Layer.prototype.repaint = function(dbmap, level) {
}

Layer.prototype.hideImages = function(dbmap) {
}
	
Layer.prototype.getLegend = function(dbmap, w) {
	var ret = $("<div/>").css({ "font-family": "Verdana, Arial", "font-weight": "bold", "font-size": "10px", "margin-bottom": 5 });
		
	var layer = this;
	var dummy = $("<input type='checkbox'/>");
	dummy.attr("checked", this.props.visible);
	dummy.click(function() {
		layer.setVisible($(this).attr("checked"));
		dbmap.repaint();
	});
	ret.append(dummy).append(this.name);
		
	if (this.props.layers.length > 1) {
		var div = $("<div/>").css({ position: "relative", top: 0, left: 10 });
		for (var i = 0; i < this.props.layers.length; i++) {
			dummy = $("<input type='checkbox'/>")
				.attr("checked", this.props.layers[i].visible)
				.data("layer", this.props.layers[i]);
			
			dummy.click(function() {
				$(this).data("layer").visible = $(this).attr("checked");
				dbmap.repaint();
			});
			
			if (i > 0) div.append($("<br/>"));
			div.append(dummy);
			div.append('<img src="' + this.props.urlLayerIcon + 'layerIndex=' + i + '"/>');
			div.append(this.props.layers[i].name);
			
			for (var j = 0; j < this.props.layers[i].themes.length; j++) {
				var theme = this.props.layers[i].themes[j];
				if (theme.name == this.props.layers[i].default_theme_name) {
					for (var k = 0; k < theme.entries.length; k++) {
						div.append('<br/>')
						div.append('<img style="margin-left:20px" src="' + this.props.urlLayerThemeIcon + 'layerIndex=' + i + '&themeIndex=' + j + '&themeEntryIndex=' + k + '"/>');
						div.append(theme.entries[k].description);
					}
				}
			}
		}
		ret.append(div);
	}
		
	return ret;
}
function GridLayer(props) {
	Layer.call(this, props);
	this.images = {};	
}

GridLayer.prototype = new Layer();

GridLayer.prototype.iterateTiles = function(dbmap, tileIterator) {
	for (var j = 0; j < dbmap.mapGrid.xNumTiles; j++) {
		for (var k = 0; k < dbmap.mapGrid.yNumTiles; k++) {
			tileIterator(j, k, dbmap.mapGrid.grid[j][k]);
		}
	}
}

GridLayer.prototype.iterateImages = function(dbmap, imageIterator) {
		var images = this.images;
		this.iterateTiles(dbmap, function(xTile, yTile, tile) {
			var image = images[xTile + 'x' + yTile];
			if (image != null) {
				imageIterator(image, xTile, yTile);
			}
		});
	},
	
GridLayer.prototype.hideImages = function(dbmap) {
	this.iterateImages(dbmap, function(image, xTile, yTile) {
		image.css("display", "none");
	});
},
	
GridLayer.prototype.src = function(tile, tileSize) {
	return '';
}
	
GridLayer.prototype.repaint = function(dbmap, level) {
	var layer = this;
		
	// index images by src
	var imageIndex = {};
	this.iterateImages(dbmap, function(image, xTile, yTile) {
		imageIndex[image.attr("src")] = { image: image, xTile: xTile, yTile: yTile };
	});

	var newImagesQueue = new Array();

	if (this.props.visible && this.isVisibleInZoom(dbmap.mapGrid.getZoomLevel())) {
		// move existing images in the grid or add new images data to a queue
		this.iterateTiles(dbmap, function(xTile, yTile, tile) {
			var src = layer.src(tile, dbmap.tileSize);
				
			if (imageIndex[src] != null) {
				var image = imageIndex[src].image;
				image.css({ position: "absolute", top: tile.screenPosition.top, left: tile.screenPosition.left, display: "", zIndex: level });
				layer.images[xTile + 'x' + yTile] = image;
				delete imageIndex[src];
			} else {
				newImagesQueue.push({ xTile: xTile, yTile: yTile, top: tile.screenPosition.top, left: tile.screenPosition.left, src: src });
			}
		});
	} else {
		this.images = {};
	}
	
	// clean grid		
	for (var src in imageIndex) { 
		if (imageIndex[src] != null) {
			imageIndex[src].image.remove();
		}
	}

	// create new images
	for (var i = 0; i < newImagesQueue.length; i++) {
		var imageData = newImagesQueue[i];
		
		var image = dbmap.addImg(imageData.src);
		image.css({ position: "absolute", top: imageData.top, left: imageData.left, zIndex: level });
		
		if (this.props.opacity != null) {
			image.css({ opacity: this.props.opacity / 100, filter: 'alpha(opacity=' + this.props.opacity + ')' });
		}
		
		layer.images[imageData.xTile + 'x' + imageData.yTile] = image;
	}
}/**
 * @class Layer WMS. Si collega ad un server WMS.
 */
function WMSLayer(props) {
	GridLayer.call(this, props);
}

WMSLayer.prototype = new GridLayer();

WMSLayer.prototype.src = function(tile, tileSize) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + tileSize + "&HEIGHT=" + tileSize;
	url += "&BBOX=" + tile.bbox.xmin + "," + tile.bbox.ymin + "," + tile.bbox.xmax + "," + tile.bbox.ymax;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}/**
 * @class Tile Layer. Si collega ad un server Abaco Tile Server.
 */
function TileLayer(props) {
	GridLayer.call(this, props);
}

TileLayer.prototype = new GridLayer();

TileLayer.prototype.src = function(tile, tileSize) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&project=" + escape(this.props.project);
	url += "&tileSize=" + tileSize;
	url += "&x=" + tile.x + "&y=" + tile.y + "&z=" + tile.z;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}
function SingleRequestWMSLayer(props) {
	Layer.call(this, props);
	this.image = null;
}

SingleRequestWMSLayer.prototype = new Layer();

SingleRequestWMSLayer.prototype.repaint = function(dbmap, level) {
	var src = this.src({ 
			xmin: dbmap.mapGrid.currentView.xmin, 
			ymin: dbmap.mapGrid.currentView.ymin, 
			xmax: dbmap.mapGrid.currentView.xmax, 
			ymax: dbmap.mapGrid.currentView.ymax 
		}, dbmap.w, dbmap.h);
				
	if (this.image != null) {
		this.image.remove();
	}
	
	this.image = dbmap.addImg(src);
	this.image.css({ width: dbmap.w, height: dbmap.h });
	this.image.css({ position: "absolute", top: 0, left: 0, zIndex: level });
}

SingleRequestWMSLayer.prototype.hideImages = function(dbmap) {
	if (this.image != null) {
		this.image.css("display", "none");
	}
}

SingleRequestWMSLayer.prototype.src = function(bbox, width, height) {
	if (!this.usable) {
		return null;
	}
	
	var layersToShow = "";
	for (var i = 0; i < this.props.layers.length; i++) {
		if (this.props.layers[i].visible) {
			if (layersToShow.length > 0) layersToShow += ',';
			layersToShow += this.props.layers[i].name;
		}
	}
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(layersToShow);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + width + "&HEIGHT=" + height;
	url += "&BBOX=" + bbox.xmin + "," + bbox.ymin + "," + bbox.xmax + "," + bbox.ymax;
	
	for (var i = 0; i < this.extraParams.length; i++) {
		url += '&' + this.extraParams[i].name + '=' + escape(this.extraParams[i].value);
	}
	
	return url;
}
function SingleRequestOnGridWMSLayer(props) {
	SingleRequestWMSLayer.call(this, props);

	this.lastGridBox = null;
}

SingleRequestOnGridWMSLayer.prototype = new SingleRequestWMSLayer();

SingleRequestOnGridWMSLayer.prototype.repaint = function(dbmap, level) {
	var topLeftTile = dbmap.mapGrid.grid[0][dbmap.mapGrid.yNumTiles - 1];
	var bottomRightTile = dbmap.mapGrid.grid[dbmap.mapGrid.xNumTiles - 1][0];
	
	var top = topLeftTile.screenPosition.top;
	var left = topLeftTile.screenPosition.left;
	var width = dbmap.mapGrid.xNumTiles * dbmap.tileSize;
	var height = dbmap.mapGrid.yNumTiles * dbmap.tileSize;
	
	var gridBox = new BBox({ 
		xmin: topLeftTile.x, 
		ymin: bottomRightTile.y,
		xmax: bottomRightTile.x, 
		ymax: topLeftTile.y });
	
	if (this.lastGridBox == null || !this.lastGridBox.equals(gridBox)) {
		var src = this.src({ 
			xmin: topLeftTile.bbox.xmin, 
			ymin: bottomRightTile.bbox.ymin, 
			xmax: bottomRightTile.bbox.xmax, 
			ymax: topLeftTile.bbox.ymax 
		}, width, height);
				
		if (this.image != null) {
			this.image.remove();
		}
		this.image = dbmap.addImg(src);
		this.image.css({ width: width, height: height });
		this.lastGridBox = gridBox;
	} else {
		this.image.css("display", "");
	}
	
	this.image.css({ position: "absolute", top: top, left: left, zIndex: level });
}/**
 * @class Map Overview
 */
function MapOverview(dbmap, props) {
	this.props = props;
	this.gui = $('<div id="mapOverview"/>');

	var unitsPerPixel = (this.props.xmax - this.props.xmin) / this.props.width;
	this.unitsPerPixel = unitsPerPixel;
	
	this.props.width  = Math.round((this.props.xmax - this.props.xmin) / this.unitsPerPixel);
	this.props.height = Math.round((this.props.ymax - this.props.ymin) / this.unitsPerPixel);
	
	this.props.xmax = this.props.width  * this.unitsPerPixel + this.props.xmin;
	this.props.ymax = this.props.height * this.unitsPerPixel + this.props.ymin;
	
	this.gui.css({ position: "absolute", top: (dbmap.h - this.props.height), left: (dbmap.w - this.props.width) });
	
	var url = this.props.url;
	url += (url.indexOf('?') > -1 ? '&' : '?');
	url += "VERSION=1.1.1&STYLES=&REQUEST=GetMap&EXCEPTIONS=application/vnd.ogc.se_inimage";
	url += "&SRS=" + escape(this.props.srs);
	url += "&BGCOLOR=" + escape(this.props.bgcolor);
	url += "&TRANSPARENT=" + (this.props.transparent + "").toUpperCase();
	url += "&LAYERS=" + escape(this.props.layers);
	url += "&FORMAT=" + escape(this.props.format);
	url += "&WIDTH=" + this.props.width + "&HEIGHT=" + this.props.height;
	url += "&BBOX=" + this.props.xmin + "," + this.props.ymin + "," + this.props.xmax + "," + this.props.ymax;	
	
	this.map = $('<img src="' + url + '" width="' + this.props.width + '" height="' + this.props.height + '"/>');
	this.map.css({ margin: 0, padding: 0, border: 0 });

	var currentViewDiv = $('<img src="' + dbmap.emptyImg() + '"/>').css({ margin: 0, padding: 0, border: '1px solid #BB0000', 
		position: 'absolute', width: (this.props.width - 1), height: (this.props.height - 1), top: 0, left: 0 });
	
	currentViewDiv.draggable({
	  containment: 'parent',
	  stop: function(event, ui) {
	  	var position = currentViewDiv.position();
	  	var x = props.xmin + position.left * unitsPerPixel + parseInt(currentViewDiv.css('width')) * unitsPerPixel / 2;
	  	var y = props.ymax - position.top * unitsPerPixel - parseInt(currentViewDiv.css('height')) * unitsPerPixel / 2;
	  	
	  	dbmap.panToPoint(x, y);
	  }
	});
	
	this.gui.append(this.map);
	this.gui.append(currentViewDiv);
	this.currentViewDiv = currentViewDiv;
}

/**
 * Restituisce il DIV contenente la mappa
 */
MapOverview.prototype.getGUI = function() {
	return this.gui;
};

/**
 * Aggiorna il DIV che evidenzia la porzione di mappa visualizzata
 * 
 * @param dbmap un'istanza di DbMAP
 */
MapOverview.prototype.updateViewDiv = function(dbmap) {
	var xmin = dbmap.mapGrid.currentView.xmin;
	var ymin = dbmap.mapGrid.currentView.ymin;
	var xmax = dbmap.mapGrid.currentView.xmax;
	var ymax = dbmap.mapGrid.currentView.ymax;

	if (xmin < this.props.xmin) xmin = this.props.xmin;
	if (ymin < this.props.ymin) ymin = this.props.ymin;
	if (xmax > this.props.xmax) xmax = this.props.xmax;
	if (ymax > this.props.ymax) ymax = this.props.ymax;

	var visible = xmin <= xmax && ymin <= ymax;

	if (visible) {
		var width  = Math.round((xmax - xmin) / this.unitsPerPixel);
		var height = Math.round((ymax - ymin) / this.unitsPerPixel);
	
		if (width < 5) width = 5;
		if (height < 5) height = 5;
		
		var top = Math.round((this.props.ymax - ymax) / this.unitsPerPixel);
		var left = Math.round((xmin - this.props.xmin) / this.unitsPerPixel);
		
		this.currentViewDiv.css({ width: width, height: height, top: top, left: left, display: "" });
	} else {
		this.currentViewDiv.css({ display: "none" });
	}
};

/**
 * @private
 */
MapOverview.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;
	this.updateViewDiv(evt.dbmap);
	
	this.gui.css({ position: "absolute", top: (dbmap.h - this.props.height), left: (dbmap.w - this.props.width) });
};/**
 * @class Scalimetro
 * 
 * @param dbmap un'istanza di DbMAP
 * @param unitOfMeasure unit&agrave; di misura
 */
function Scalimeter(dbmap, unitOfMeasure) {
	this.gui = $("<div/>").css({ position: "absolute", top:-50, left:0 });
	this.labelDiv = $("<div/>").css({ position: "absolute", top: 0, left: 6, height:"12px", width: "100px", color: "#000000" });
	this.labelDiv.css("text-align", "center");
	this.labelDiv.css("font-size", "10px");
	this.labelDiv.css("font-weight", "bold");
	this.labelDiv.css("font-family", "Verdana, Arial");
	
	this.labelBoxDiv = $("<div/>").css({ position: "absolute", top: 0, left: 0, height:"12px", width: "100px", color: "#000000", background: "#ffffff", opacity: 0.8 });
	
	this.leftDiv = $("<div/>").css({ position:"absolute", top: 5, left: 2, height:"20px", width:"3px" });
	this.leftDiv.css("background-repeat", "repeat-y");
	this.leftDiv.css("background-position", "left");
	this.leftDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-vert.gif)");

	this.centerDiv = $("<div/>").css({ position:"absolute", top: 5, left:4, height:"20px", width:"3px" });
	this.centerDiv.css("background-repeat", "repeat-x");
	this.centerDiv.css("background-position", "center");
	this.centerDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-center.gif)");
	
	this.rightDiv = $("<div/>").css({ position:"absolute", top: 5, left:150, height:"20px", width:"3px" });
	this.rightDiv.css("background-repeat", "repeat-y");
	this.rightDiv.css("background-position", "left");
	this.rightDiv.css("background-image", "url(" + dbmap.getImageDir() + "/dbmap/scalebar-vert.gif)");
	
	this.unit = unitOfMeasure || "m";
	this.refLen = 100;
	
	this.gui.append(this.labelBoxDiv).append(this.labelDiv)
			.append(this.leftDiv).append(this.rightDiv).append(this.centerDiv);
}

Scalimeter.prototype.getGUI = function() {
	return this.gui;
};

Scalimeter.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;

	var dbmap = evt.dbmap;
	
	// Calcolo lunghezze in px e mt (a step di 1, 2, 5) 
	var val = this.refLen / dbmap.mapGrid.pixelValue;
	var exp = 0, mult = 1;
	while (val > (mult * Math.pow(10, exp))) {
		switch (mult) {
		case 1:
			mult = 2;
			break;
		case 2:
			mult = 5;
			break;
		case 5:
			mult = 1;
			exp++;
			break;
		}
	}
	
	var lenMt = mult * Math.pow(10, exp);
	var lenPx = Math.round(lenMt * this.refLen / val);
	
	var y = dbmap.h - 25;
	var x = 5;

	this.gui.css({ top: y - 5, left: x - 2, width: lenPx + 8, height: 28 });
	
	this.labelBoxDiv.css({ width: lenPx + 8, height: 28 });
	
	//this.leftDiv.css({ top: y, left: x });
	//this.centerDiv.css({ top: y, left: x + 2, width: lenPx });
	//this.rightDiv.css({ top: y, left: x + lenPx + 1 });
	//this.labelDiv.html(lenMt + " " + this.unit).css({ top: y - 5, left: x + 4, width: lenPx - 4 });
	
	this.centerDiv.css({ width: lenPx });
	this.rightDiv.css({ left: 2 + lenPx + 1 });
	this.labelDiv.html(lenMt + " " + this.unit).css({ width: lenPx - 4 });
	
};/**
 * @class Zoom Slider
 * 
 * @param dbmap un'istanza di DbMAP
 */
function ZoomSlider(dbmap) {
	this.gui = $('<div id="zoomSliderContainer"/>');
	this.gui.css({ position: "absolute", top: 0, left: 0 });	
	
	this.dbmap = dbmap;
	this.maxZ = dbmap.mapGrid.maxZ;
	this.z = dbmap.mapGrid.z;
	
	this.offsetTop = 20;
	this.offsetLeft = 20;
	this.zoombarH = 11;
	this.zoombarW = 18;
	this.zoomButtonH = 18;
	
	// dimensioni: w 18, h 18
	this.zoomInButton = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoom-plus-mini.gif" style="margin:0; padding:0"/>').click(function() {
		dbmap.zoomIn();
	});
	this.zoomInButton.css({ position: "absolute", top: this.offsetTop, left: this.offsetLeft });
	this.gui.append(this.zoomInButton);
	
	for (var i = 0; i <= this.maxZ; i++) {
		// dimensioni: w 18, h 11
		var zoombar = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoombar.gif" style="margin:0; padding:0"/>');
		zoombar.css({ position: "absolute", top: (i * this.zoombarH + this.zoomButtonH + this.offsetTop), left: this.offsetLeft });
		
		if (this.z == i) {
			// dimensioni: w 20, h 9
			this.slider = $('<img src="' + dbmap.getImageDir() + '/dbmap/slider.gif" id="zoomSlider" style="margin:0; padding:0"/>');
			this.updateSliderPosition(this.slider, this.z);
			this.gui.append(this.slider);
		}
		
		this.gui.append(zoombar);
	}
	
	// dimensioni: w 18, h 18
	this.zoomOutButton = $('<img src="' + dbmap.getImageDir() + '/dbmap/zoom-minus-mini.gif" style="margin:0; padding:0"/>').click(function() {
		dbmap.zoomOut();
	});
	this.zoomOutButton.css({ position: "absolute", top: ((this.maxZ + 1) * this.zoombarH + this.zoomButtonH + this.offsetTop), left: this.offsetLeft });
	this.gui.append(this.zoomOutButton);
}

ZoomSlider.prototype.initDraggingSupport = function() {
	var final_this = this;
	
	var sliderOffset = this.slider.offset();
	
	this.slider.draggable({ 
	  containment: [
		sliderOffset.left, 
		this.zoomInButton.offset().top + this.zoomButtonH - 1, 
		sliderOffset.left, 
		this.zoomOutButton.offset().top - this.zoombarH + 1],
	  grid: [ 1, this.zoombarH ],
	  stop: function(event, ui) {  
	  	var newZoom = Math.round((final_this.zoomOutButton.offset().top - final_this.slider.offset().top) / final_this.zoombarH) - 1;
	  	final_this.dbmap.zoomToLevel(newZoom, true, true);
	  }
	});
};

ZoomSlider.prototype.getGUI = function() {
	return this.gui;
};

ZoomSlider.prototype.updateSliderPosition = function(slider, zoom) {
	slider.css({ position: "absolute", top: ((this.maxZ - zoom) * this.zoombarH + this.zoomButtonH + this.offsetTop + 1), left: (this.offsetLeft - 1), zIndex: 1 });
};

ZoomSlider.prototype.updateViewDiv = function(dbmap) {
	if (this.z != dbmap.mapGrid.z) {	
		this.z = dbmap.mapGrid.z;
		this.updateSliderPosition(this.slider, this.z);
	}
};

ZoomSlider.prototype.viewChanged = function(evt) {
	if (evt.paintEnd) return;
	this.updateViewDiv(evt.dbmap);
};
/**
 * 
 * @class Whiteboard
 */
function Whiteboard(dbmap) {
	this._dbmap = dbmap;
	
	this._listener = null;	
	
	this._jg = new jsGraphics($(dbmap.map).get(0));
	this._jg.setColor('#0000ff');
	this._jg.setStroke(2);

	this._MODE_APPEND = '_MODE_APPEND';	
	this._MODE_MOVE = '_MODE_MOVE';
	this._MODE_INSERT = '_MODE_INSERT';
	this._MODE_DELETE = '_MODE_DELETE';
	this._mode = '';
	
	this._type = null;
	
	this._id = null;
	this._points = new Array();	
}

Whiteboard.prototype.setColor = function(color) {
	this._jg.setColor(color);
}

Whiteboard.prototype.setStroke = function(stroke) {
	this._jg.setStroke(stroke);
}

Whiteboard.prototype.addListener = function(listener) {
	this._listener = listener;
}

Whiteboard.prototype.add = function(type) {
	this.clear();
	this._mode = this._MODE_APPEND;
	this._type = type;	
}

Whiteboard.prototype.edit = function(type, id, points) {
	this.clear();
	this._type = type;
	this._id = id;
	this._points = points;
	this._mode = this._MODE_MOVE;
	this.repaint();		
}

Whiteboard.prototype.appendVertex = function() {
	this._mode = this._MODE_APPEND;
}

Whiteboard.prototype.moveVertex = function() {
	this._mode = this._MODE_MOVE;
}

Whiteboard.prototype.insertVertex = function() {
	this._mode = this._MODE_INSERT;	
}

Whiteboard.prototype.deleteVertex = function() {
	this._mode = this._MODE_DELETE;	
}

Whiteboard.prototype.stop = function() {
	this._mode = '';
}

Whiteboard.prototype.getId = function() {
	return this._id;
}

Whiteboard.prototype.getType = function() {
	return this._type;
}

Whiteboard.prototype.getPoints = function() {
	if (this._points.length > 0) {
		return this._points;
	} else {
		return null;
	}
}

Whiteboard.prototype.onClick = function(mapPoint) {
	if (this._mode == this._MODE_APPEND || (this._mode == this._MODE_INSERT && this._points.length < 2)) {
		if (this._type == DbMAPEntity.POINT) {
			this._points[0] = mapPoint;
		} else {
			this._points[this._points.length] = mapPoint; 					
		}
 	} else if (this._mode == this._MODE_MOVE && this._points.length > 0) {
		var nearestPoint = this.findNearestPoint(mapPoint);
		this._points[nearestPoint.index] = mapPoint;
 	} else if (this._mode == this._MODE_INSERT) {
		if (this._type == DbMAPEntity.POINT) {
			this._points[0] = mapPoint;
		} else {
			var nearestMedianPoint = this.findNearestMedianPoint(mapPoint);
			this._points.splice(nearestMedianPoint.index, 0, mapPoint);
		}
 	} else if (this._mode == this._MODE_DELETE && this._points.length > 0) {
		var nearestPoint = this.findNearestPoint(mapPoint); 		
		this._points.splice(nearestPoint.index, 1);
 	}
 	
 	if (this._mode != '') {
		this.repaint();
		if (this._listener != null) this._listener.onClick(mapPoint);
 	}
}

Whiteboard.prototype.clear = function() {
	this._jg.clear();
	
	this._mode = '';
	this._type = '';
	this._id = null;
	this._points = new Array();
}

Whiteboard.prototype.repaint = function(new_bbox) {
	this._jg.clear();
	
	if (this._type == DbMAPEntity.POINT) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		}
	} else if (this._type == DbMAPEntity.LINE) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		} else if (this._points.length > 1) {
			this.drawMapPoint(this._points[0]);
			for (var i = 1; i < this._points.length; i++) {
				this.drawMapPoint(this._points[i]);
				this.drawMapLine(this._points[i - 1], this._points[i]);			
			}		
		}
	} else if (this._type == DbMAPEntity.POLYGON) {
		if (this._points.length == 1) {
			this.drawMapPoint(this._points[0]);
		} else if (this._points.length == 2) {
			this.drawMapPoint(this._points[0]);
			this.drawMapPoint(this._points[1]);
			this.drawMapLine(this._points[0], this._points[1]);			
		} else if (this._points.length > 2) {
			this.drawMapPolygon(this._points);			
		}
	}
	
	if (this._points.length > 0 && this._type != '') {
		this._jg.paint();
	}
}

/**
 * @private
 */
Whiteboard.prototype.findNearestPoint = function(mapPoint) {
	if (this._points.length == 1) {
		return { distance: -1, index: 0 };
	}
	
	var nearestPoint = null;
	for (var i = 0; i < this._points.length; i++) {	
		var distance = this._dbmap.getDistance(this._points[i], mapPoint);
		if (nearestPoint == null || distance < nearestPoint.distance) {
			nearestPoint = { distance: distance, index: i };
		}
	}
	return nearestPoint;
}

/**
 * @private
 */
Whiteboard.prototype.findNearestMedianPoint = function(mapPoint) {
	var nearestPoint = null;
	for (var i = 0; i < this._points.length; i++) {
		var start = i;
		var end = i+1;
		if (end == this._points.length) end = 0;
		
		var medianPoint = this.getMedianPoint(this._points[start], this._points[end]);
		var distance = this._dbmap.getDistance(medianPoint, mapPoint);
		if (nearestPoint == null || distance < nearestPoint.distance) {
			nearestPoint = { distance: distance, index: i+1 };
		}
	}
	return nearestPoint;
}

/**
 * @private
 */
Whiteboard.prototype.getMedianPoint = function(p1, p2) {
	var xm = (p1.x + p2.x) / 2;
	var ym = (p1.y + p2.y) / 2;
	return { x: xm, y: ym };
}

/**
 * @private
 */
Whiteboard.prototype.drawMapPoint = function(mapPoint) {
	var screenPoint = this._dbmap.mapGrid.mapToScreen(mapPoint.x, mapPoint.y, false);
	if (screenPoint != null) {
		this._jg.fillRect(screenPoint.left - 2, screenPoint.top - 2, 5, 5);
	}
}

/**
 * @private
 */
Whiteboard.prototype.drawMapLine = function(p_from, p_to) {
	var screenPoint_from = this._dbmap.mapGrid.mapToScreen(p_from.x, p_from.y, false);
	var screenPoint_to = this._dbmap.mapGrid.mapToScreen(p_to.x, p_to.y, false);
	if (screenPoint_from != null && screenPoint_to!= null) {
		this._jg.drawLine(screenPoint_from.left, screenPoint_from.top, screenPoint_to.left, screenPoint_to.top);			
	}
}

/**
 * @private
 */
Whiteboard.prototype.drawMapPolygon = function(points) {
	var screenPoints_x = new Array();
	var screenPoints_y = new Array();
	
	for (var i = 0; i < points.length; i++) {
		this.drawMapPoint(this._points[i]);
		
		var screenPoint = this._dbmap.mapGrid.mapToScreen(points[i].x, points[i].y, true);
		screenPoints_x[screenPoints_x.length]=screenPoint.left;
		screenPoints_y[screenPoints_y.length]=screenPoint.top;
	}
	
	this._jg.drawPolygon(screenPoints_x, screenPoints_y);
}
