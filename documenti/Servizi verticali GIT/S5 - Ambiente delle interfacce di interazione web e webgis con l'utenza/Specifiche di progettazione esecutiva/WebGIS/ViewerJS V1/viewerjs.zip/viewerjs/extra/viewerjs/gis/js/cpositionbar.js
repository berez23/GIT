//
// CPositionBar.js
//
// customized position bar
//
function CPositionBar(pi_strUIAnchorID, pi_strId, pi_iWidth, pi_iHeight, pi_bVisible)
{
	// store reference to ui anchor, to which these object is tie in ui position
	this.m_strUIAnchorID = pi_strUIAnchorID;
	
	// check current coordinate for control positioning
	if (undefined == pi_bVisible)
		pi_bVisible = true;
	
	this.m_bVisible = pi_bVisible;
	this.m_iWidth = pi_iWidth;
	this.m_iHeight = pi_iHeight;
	this.m_iLeft = 0;
	this.m_iTop = 0;
	this.m_strId = pi_strId;
	this.buildUI = CPositionBar_buildUI;

	// event notification: client should position control
	this.m_eventChangePosition = undefined;
	
	this.setEventChangePosition = CPositionBar_setEventChangePosition;
	this.fireEventChangePosition = CPositionBar_fireEventChangePosition;

	this.setLeft = CPositionBar_setLeft; 
	this.getLeft = CPositionBar_getLeft;
	
	this.setTop = CPositionBar_setTop;
	this.getTop = CPositionBar_getTop;
	
	this.setWidth = CPositionBar_setWidth;
	this.getWidth = CPositionBar_getWidth;
	
	this.setHeight = CPositionBar_setHeight;
	this.getHeight = CPositionBar_getHeight;
}

CPositionBar.prototype.getGUI = function() {
	return this.gui;
};

CPositionBar.prototype.viewChanged = function(evt) 
{
	try
	{
		this.fireEventChangePosition();
		this.gui.css('left', this.m_iLeft);
		this.gui.css('top', this.m_iTop);
		this.gui.css('width', this.m_iWidth);
		this.gui.css('height', this.m_iHeight);
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar.prototype.viewChanged', e);
	}
	
	return;
}

CPositionBar.prototype.setVisible = function(visible) {
	if (visible) 
	{
		this.gui.show("normal");
	} else 
	{
		this.gui.hide("normal");
	}
};

//
// create user interface
//
function CPositionBar_buildUI()
{
	try
	{
		// fire event to get position
		this.fireEventChangePosition();
		
		var strCSS = 
		{
			position : "absolute"
			, left : this.m_iLeft
			, top : this.m_iTop
			, width : this.m_iWidth
			, height : this.m_iHeight
			, color : "#000000"
			, borderLeft : "thin solid silver"
			, borderTop : "thin solid silver"
			, borderBottom : "thin solid black"
			, borderRight : "thin solid black"
			, background : "rgb(128, 192, 255)"
			, overflow : "hidden"
			, fontName : "verdana"
			, fontSize : "10pt"
			, fontWeight : 'bold'
			, opacity : 0.8
			, padding : '4px'
		};
		this.gui = $("<div/>").css(strCSS);
	
		this.m_span = $("<span id='" + this.m_strId + "'></span>");
		this.m_span.appendTo(this.gui);
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_buildUI', e);
	}
}	// CPositionBar_buildUI


//
// set client handler of event change position request
// 
function CPositionBar_setEventChangePosition(pi_eventValue)
{
	try
	{
		// undefined can be a value
		this.m_eventChangePosition = pi_eventValue;
		return 1;
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_setEventChangePosition', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_setEventChangePosition


//
// fire event change position
//
function CPositionBar_fireEventChangePosition()
{
	try
	{
		if (undefined != this.m_eventChangePosition)
			this.m_eventChangePosition(this);
		
		return 1;
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_fireEventChangePosition XXX', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_fireEventChangePosition


//
// getLeft
//
function CPositionBar_getLeft()
{
	return this.m_iLeft;
}

//
// set left property of control
//
function CPositionBar_setLeft(pi_iValue)
{
	try
	{
		if (undefined == pi_iValue)
			return -2;
		
		this.m_iLeft = pi_iValue;
		return 1;
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_setLeft', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_setLeft


//
// getTop
//
function CPositionBar_getTop()
{
	return this.m_iTop;
}


//
// set top property of control
//
function CPositionBar_setTop(pi_iValue)
{
	try
	{
		if (undefined == pi_iValue)
			return -2;
		
		this.m_iTop = pi_iValue;
		return 1;
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_setTop', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_setTop


//
// getWidth
//
function CPositionBar_getWidth()
{
	return this.m_iWidth;
}


//
// CPositionBar_setWidth
//
function CPositionBar_setWidth(pi_iValue)
{
	try
	{
		if (undefined == pi_iValue)
			return -2;
		
		this.m_iWidth = pi_iValue;
		return 1;
	}
	catch(e)
	{
		handleException('CPositionBar_setWidth', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_setWidth


//
// getHeight
//
function CPositionBar_getHeight()
{
	return this.m_iHeight;
}


//
// CPositionBar_setHeight
//
function CPositionBar_setHeight(pi_iValue)
{
	try
	{
		if (undefined == pi_iValue)
			return -2;
		
		this.m_iHeight = pi_iValue;
		return 1;
	}
	catch(e)
	{
		g_utilProject.handleException('CPositionBar_setHeight', e);
		return -1;
	}
	
	return 0;
}	// CPositionBar_setHeight

