function Commandbar(dbmap)
{
	var btnStyle2 = "border: 1px solid; border-color: #696 #363 #363 #696; width:22; height:22;";
	
	this.gui = $("<div/>").css({position: "absolute", top:10, left:100 , width: 48, height: 24, color: "#000000", background: "#ffffff", opacity: 1});
	
	// Zoom In
		
	$("<input type=\"image\" id=\"btnPdfZoomIn\" src=\"images/zoom_in.gif\" style=\""+btnStyle2+"background-color: white; \"  title=\"Zoom In\">").click(function()
	{
		dbmap.zoomIn();
	}).appendTo(this.gui);

	
	// Zoom Out
	
	$("<input type=\"image\" id=\"btnPdfZoomOut\" src=\"images/zoom_out.gif\" style=\""+btnStyle2+"background-color: white; \" title=\"Zoom Out\">").click(function()
	{
		dbmap.zoomOut();
	}).appendTo(this.gui);
}

Commandbar.prototype.getGUI = function() {
	return this.gui;
};

Commandbar.prototype.viewChanged = function(evt) {
	// do nothing
	return;
}

Commandbar.prototype.setVisible = function(visible) {
	if (visible) 
	{
		this.gui.show("normal");
	} else 
	{
		this.gui.hide("normal");
	}
};