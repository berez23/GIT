

//
// object CUtilProject
//

//
// define project related utility
//
function CUtilProject()
{
	this.getWindowDefatulParam = CUtilProject_getWindowDefatulParam;
	this.handleException = CUtilProject_handleException;
	this.getUIPosition = CUtilProject_getUIPosition;
}
//
//ritorna il parametro per aprire la finestra delle dimensioni indicate centrata sullo schermo
//

function CUtilProject_getWindowDefatulParam(pi_iWidth, pi_iHeight)
{
	var iLeft = (screen.width) ? (screen.width - pi_iWidth) /2 : 0
		, iTop = (screen.height) ? (screen.height - pi_iHeight) /2 : 0
		
	strParam = "width=" + pi_iWidth
		+ ",height="+ pi_iHeight
		+ ",top=" + iTop
		+ ",left=" + iLeft
		+ ",scrollbars=yes,resizable=no";
	
	return strParam;
}


function CUtilProject_handleException(pi_strDescr, pi_exception)
{
	var strMsg;
	
	strMsg = 'Exception description:' + pi_strDescr
		+ '\n\ntostring\n' + pi_exception.toString()
		+ '\n\nmessage\n' + pi_exception.message;
	
	alert(strMsg);
} // handleException


//
// return UI interface position of element
// input can be a string or object it is accessed with YAHOO.util.Dom.get 
//
function CUtilProject_getUIPosition(pi_strIDOrObject)
{
	try
	{
		if (undefined == pi_strIDOrObject)
			return undefined;
		
		var domObj = YAHOO.util.Dom.get(pi_strIDOrObject);

		if (undefined == domObj)
			return undefined;

		// create object
		var objRV = 
		{
			left : g_util.getStyleLeft(domObj)
			, top : g_util.getStyleTop(domObj)
			, width : g_util.getStyleWidth(domObj)
			, height : g_util.getStyleHeight(domObj)
		};

		return objRV;
	}
	catch(e)
	{
		g_utilProject.handleException('CUtilProject_getUIPosition', e);
	}
	
	return undefined;
}


var
	g_utilProject = new CUtilProject();

