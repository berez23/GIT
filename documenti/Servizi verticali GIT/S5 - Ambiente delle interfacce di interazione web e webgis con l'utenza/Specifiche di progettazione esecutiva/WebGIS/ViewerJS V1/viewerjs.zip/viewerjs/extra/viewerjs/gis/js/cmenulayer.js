//
// CMenuLayer.js
//
// create date: 2011-05-04
// update date: 2011-05-04
// version: 1.0
// description: manager menu for choosing layer visibility
//

function CMenuLayer(pi_config)
{
	//TODO put properties for width/height of image
	//
	// properties
	//
	
	// store item to be displayed
	this.m_aMenuItem = new Array();

	// reference to config object for initialization purposes
	this.m_config = pi_config;

	// yiu menu
	this.m_menu = undefined; 

	// store current position of menu button
	this.m_uiPosition = undefined;
		
	//
	// functions
	//
	
	this.addItem = CMenuLayer_addItem;
	this.buildUI = CMenuLayer_buildUI;
	this.setEventItemClicked = CMenuLayer_setEventItemClicked;
	this.setItemCheck = CMenuLayer_setItemCheck;

	// private
	this.buttonMenuClick = CMenuLayer_buttonMenuClick;
	this.getMapPosition = CMenuLayer_getMapPosition;
	this.getUIPosition = CMenuLayer_getUIPosition;
	this.getDefaultStyleUI = CMenuLayer_getDefaultStyleUI;
	
	// gui events
	this.viewChanged = CMenuLayer_viewChanged;
	
	//
	// events
	//
	
	// event fired when an item of menu if clicked
	this.eventItemClicked = undefined;
}

//
// dbmap function management
//
CMenuLayer.prototype.getGUI = function() 
{
	return this.gui;
};

//
// when gui size change need to reposition control
//
function CMenuLayer_viewChanged() 
{
	try
	{
		// compute new position
		this.m_uiPosition = this.getUIPosition();
		
		if (undefined == this.m_uiPosition)
			return -2;
		
		this.gui.css(this.getDefaultStyleUI(this.m_uiPosition));
		
		// do not function, UI is jquery
		// g_util.setStyleLeftTopWidhtHeight(this.gui, this.m_uiPosition);
	}
	catch(e)
	{
		handleException('CMenuLayer_viewChanged', e);
	}
	
}	// CMenuLayer_viewChanged

CMenuLayer.prototype.setVisible = function(visible) 
{
	if (visible) 
		this.gui.show("normal");
	else 
		this.gui.hide("normal");
};


//
// create user interface
//
function CMenuLayer_buildUI()
{
	try
	{
		this.m_uiPosition = this.getUIPosition();
		
		if (undefined == this.m_uiPosition)
			return -2;

		var strCSS = this.getDefaultStyleUI(this.m_uiPosition); 
		this.gui = $("<div/>").css(strCSS);
	
		// menu button
		var strStyleCommon = 'border: 5px solid transparent;' 
			+ 'border-color: none;'	//: #696 #363 #363 #696;' 
			+ 'width:64;' 
			+ 'height:64;'
			+ 'background-color:transparent;';
	
		var strHTML = "<input" 
			+ " type='image'" 
			+ " id='btnMeasure'" 
			+ " src='images/layers.png'" 
			+ " style='" + strStyleCommon + "'" 
			+ " title='Strati'>";
		
		this.m_btnMenu = $(strHTML);
		
		var thisI = this;
		this.m_btnMenu.click
		(
			function()
			{
				thisI.buttonMenuClick();
			}
		);
		
		// add menu button to main gui
		this.m_btnMenu.appendTo(this.gui);
	
		
		// div container for YUI menu
		var strHTML = '<div id=\'kid_menuLayer\' style=\'z-index:100\'></div>';
		this.m_divMenu = $(strHTML);
		this.m_divMenu.appendTo(document.body);

		// build YIU menu
		var aattr = {};
		this.m_menu = new YAHOO.widget.Menu('kid_menuLayer', aattr);
		this.m_menu.cfg.setProperty('xy', [ 0, 0 ]);	// intial position
		this.m_menu.cfg.setProperty('position', 'dynamic');
		this.m_menu.render();
		
		return 1;
	}
	catch(e)
	{
		handleException('CMenuLayer_buildUI', e);
		return -1;
	}

	return 0;
}	// CMenuLayer_buildUI


//
// return style for UI
//
function CMenuLayer_getDefaultStyleUI(pi_position)
{
	if (undefined == pi_position)
		return undefined;
	
	var strRV = 
		{
			position : 'absolute'
			, top : pi_position.top
			, left : pi_position.left
			, width : pi_position.width
			, height : pi_position.height
			, color : "#000000"
			, background : "transparent"
			, opacity : 1
		};
	
	return strRV;
}


//
// return position information from map
//
function CMenuLayer_getMapPosition()
{
	try
	{
		
		var strHtmlMapId = (null == this.m_config ? undefined : this.m_config.getHtmlMapId());
		
		if (undefined == strHtmlMapId)
			return undefined;
		
		return g_utilProject.getUIPosition(strHtmlMapId);
	}
	catch(e)
	{
		handleException('CMenuLayer_getMapPosition', e);
		return undefined;
	}
	
	return undefined;
}	// CMenuLayer_getMapPosition


//
// return position of ui
//
function CMenuLayer_getUIPosition()
{
	try
	{

		var mapPosition = this.getMapPosition();

		if (undefined == mapPosition)
			return undefined;
	
		var iWidth = 64
			, objRV =
				{
					top: 5
					, width: iWidth
					, height: 64
					, left: mapPosition.left + mapPosition.width - iWidth -5
				};
		
		return objRV;
	}
	catch(e)
	{
		handleException('CMenuLayer_getUIPosition', e);
		return undefined;
	}
	
	return undefined;
}


//
// request to open menu to user
//
function CMenuLayer_buttonMenuClick()
{
	try
	{
		// set poistion where to open menu
		this.m_menu.cfg.setProperty('xy', [ this.m_uiPosition.left, this.m_uiPosition.top + this.m_uiPosition.width ]);	// intial position
		
		// need to change zIndex in order to put menu in front of all others elements
		YAHOO.util.Dom.get('kid_menuLayer').style.zIndex = 100;
		this.m_menu.show();
	}
	catch(e)
	{
		handleException('CMenuLayer_buttonMenuClick', e);
	}
}	// CMenuLayer_buttonMenuClick


//
// add listener for event on item click
//
function CMenuLayer_setEventItemClicked(pi_eventValue)
{
	try
	{
		// undefined is a supported value to reset notification
		this.eventItemClicked = pi_eventValue;
		return 1;
	}
	catch(e)
	{
		handleException('CMenuLayer_setEventItemClicked', e);
		return -1;
	}
	
	return 0;
}	// CMenuLayer_setEventItemClicked


//
// add an item to menu layer
//
function CMenuLayer_addItem(pi_menuLayerItem)
{
	try
	{
		if (undefined == pi_menuLayerItem)
			return -2;

		// add menu item to menu
		var menuItem = new YAHOO.widget.MenuItem(pi_menuLayerItem.name);
		menuItem.cfg.setProperty('checked', pi_menuLayerItem.checked);
		menuItem.cfg.setProperty('onclick', { fn: menuLayerItem_clickUI, obj: { kthis: this, menuLayerItem : pi_menuLayerItem } } );
		this.m_menu.addItem(menuItem, 0);
		this.m_menu.render();	// re render items

		// add menu item to array for later references
		this.m_aMenuItem[pi_menuLayerItem.ID] = menuItem; 
		
		return 1;
	}
	catch(e)
	{
		handleException('CMenuLayer_addItem', e);
		return -1;
	}
	
	return 0;
}	// CMenuLayer_addItem



//
// called when a single menu item is clicked
//
function menuLayerItem_clickUI(pi_strName, pi_event, pi_param)
{
	try
	{
		if (undefined == pi_param)
			return;
		
		if (undefined != pi_param.kthis.eventItemClicked)
			pi_param.kthis.eventItemClicked(pi_param.menuLayerItem.ID);
	}
	catch(e)
	{
		handleException('menuLayerItem_clickUI', e);
	}
}	// menuLayerItem_clickUI



//
// change item check for specified ID 
//
function CMenuLayer_setItemCheck(pi_ID, pi_bCheck)
{
	try
	{
		if (undefined == pi_ID || undefined == pi_bCheck)
			return -2;
		
		var menuItem = this.m_aMenuItem[pi_ID];
		if (undefined == menuItem)
			return -3;
				
		menuItem.cfg.setProperty('checked', pi_bCheck);				
		return 1;
	}
	catch(e)
	{
		handleException('CMenuLayer_setItemCheck', e);
		return -1;
	}
	
	return 0;
}	// CMenuLayer_setItemCheck


//
// class CMenuLayerItem
//

//
// store information about a single layer item
//
function CMenuLayerItem()
{
	// name of menu item
	this.name = undefined;

	// set if menu item is checked
	this.checked = false;
}	// CMenuLayerItem


//
// CMenuLayerConfig
//
// store configuration option for object CMenuLayer
function CMenuLayerConfig()
{
	// id of html control that enclose map
	this.m_strHtmlMapId = undefined;
	
	this.setHtmlMapId = CMenuLayerConfig_setHtmlMapId;
	this.getHtmlMapId = CMenuLayerConfig_getHtmlMapId; 
}

//
// set property of HtmlMapId
//
function CMenuLayerConfig_setHtmlMapId(pi_strValue)
{
	try
	{
		if (undefined == pi_strValue)
			return -2;
		
		if ('string' != typeof(pi_strValue))
			return -3;
		
		this.m_strHtmlMapId = pi_strValue; 
	}
	catch(e)
	{
		handleException('CMenuLayerConfig_setHtmlMapId', e);
		return -1;
	}
}	// CMenuLayerConfig_setHtmlMapId


//
// return property value
//
function CMenuLayerConfig_getHtmlMapId()
{
	return this.m_strHtmlMapId;
}	// CMenuLayerConfig_getHtmlMapId
