// CCommandBar.js

function CCommandBar(dbmap)
{
	// properties
	this.m_dbmap = dbmap;
	// current button
	this.m_iIdxCurrentButton = undefined;	
	this.setIndexButtonCurrent = CCommandBar_setIndexButtonCurrent;
	this.getIndexButtonCurrent = CCommandBar_getIndexButtonCurrent;
	
	this.addButton = CCommandBar_addButton;
	
	// store all button to be displayed
	this.m_aButton = new Array();
	// store all button HTML created
	this.m_aHtmlButton = new Array();
	
	// event when a button is cliecked 
	this.m_eventButtonClicked = undefined;
	this.setEventButtonClicked = CCommandBar_setEventButtonClicked;
	this.fireEventButtonClicked = CCommandBar_fireEventButtonClicked;
	
	// functions
	this.buildUI = CCommandBar_buildUI;
}

CCommandBar.prototype.getGUI = function() 
{
	return this.gui;
};

CCommandBar.prototype.viewChanged = function(evt) 
{
	return;
};

CCommandBar.prototype.setVisible = function(visible) 
{
	if (visible) 
	{
		this.gui.show("normal");
	} else 
	{
		this.gui.hide("normal");
	}
};


//
// create user interface
//
function CCommandBar_buildUI()
{
	//
	// create DIV for Command Bar container
	//
	
	var iButtonCount = this.m_aButton.length;
	var strCSS = 
	{
		position : "relative"
		, top : 5
		, left : 5
		, width : (50+10) * iButtonCount
		, height : 50
		, color : "#000000"
		, background : "transparent"
		, opacity : 1
	};
	this.gui = $("<div/>").css(strCSS);

	//
	// add buttons to Command Bar
	//
	this.m_strBackgroundToggleOff = "none";
	this.m_strBackgroundToggleOn = "yellow";
	
	var strStyleCommon = "border: 5px solid transparent;" 
		+ "border-color:none;"	// left unassigned #696 #363 #363 #696; 
		+ "width:48;" 
		+ "height:48;"
		+ "background-color: " + this.m_strBackgroundToggleOff + ";";
	
	// following buttons are toggle button
	
	var iIterButton
		, iIterButtonMax = this.m_aButton.length;
	
	for (iIterButton = 0; iIterButton < iIterButtonMax; ++iIterButton)
	{
		var buttonCurrent = this.m_aButton[iIterButton]
			, strHTML = "<input" 
				+ " type=\"image\"" 
				+ " id=\"" + buttonCurrent.getId() + "\"" 
				+ " src=\"" + buttonCurrent.getImageURL() + "\"" 
				+ " style=\"" + strStyleCommon + "\"" 
				+ " title=\"" + buttonCurrent.getToolTip() + "\""
				+ ">";
			var htmlButton = $(strHTML); 
			
			// append button to GUI
			htmlButton.appendTo(this.gui);

			var kthis = this;
			
			// add attribute for handler
			htmlButton.attr("kindex", buttonCurrent.getIndex());
			
			// when button is clicked set current button index
			htmlButton.click
			(
				function(event)
				{
					var domI = YAHOO.util.Dom.get(event.currentTarget.id);
					var strIndex = domI.getAttribute("kindex");
					var iIndex = parseInt(strIndex);

					// TODO P6 [dev] to prevent m_commandbar in code add index to control and add collection of m_commandbar
					m_commandbar.setIndexButtonCurrent(iIndex);
				}
			);
			
			// add button to array
			this.m_aHtmlButton.push(htmlButton); 
	}	// for button

}	// CCommandBar_buildUI


/**
 * CCommandBar_setEventButtonClicked
 *
 * set event listener for event buttonClicked
 */
function CCommandBar_setEventButtonClicked(pi_eventValue)
{

	try
	{
		this.m_eventButtonClicked = pi_eventValue;
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBar_setEventButtonClicked", e);
		return -1;
	}
	
}	// eof CCommandBar_setEventButtonClicked



/**
 * CCommandBar_fireEventButtonClicked
 *
 * fire event buttonClicked
 */
function CCommandBar_fireEventButtonClicked()
{

	try
	{
		if ("undefined" != typeof(this.m_eventButtonClicked))
			return this.m_eventButtonClicked(this);

		return 1;
	}
	catch(e)
	{
		handleException("CCommandBar_fireEventButtonClicked", e);
		return -1;
	}
	
}	// eof CCommandBar_fireEventButtonClicked



/**
 * CCommandBar_addButton
 *
 * add a button to list
 */
function CCommandBar_addButton(pi_button)
{

	try
	{
		if ("object" != typeof(pi_button))
			return -2;
		
		this.m_aButton.push(pi_button);
		// store index in button
		pi_button.setIndex(this.m_aButton.length -1);
		
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBar_addButton", e);
		return -1;
	}
	
}	// eof CCommandBar_addButton



/**
 * CCommandBar_setIndexButtonCurrent
 *
 * set index of current button
 */
function CCommandBar_setIndexButtonCurrent(pi_iValue)
{

	try
	{
		if ("number" != typeof(pi_iValue))
			return -2;
		
		// check range
		if (pi_iValue < 0 || pi_iValue >= this.m_aButton.length)
			return -3;
		
		this.m_iIdxCurrentButton = pi_iValue;
		
		// manage UI
		// scan all buttons
		var iIter;
		for (iIter = 0; iIter < this.m_aButton.length; ++iIter)
		{
			if (this.m_iIdxCurrentButton == iIter)
				this.m_aHtmlButton[iIter].css({background: this.m_strBackgroundToggleOn});
			else
				this.m_aHtmlButton[iIter].css({background: this.m_strBackgroundToggleOff});
		}	// for
		
		return this.fireEventButtonClicked();
	}
	catch(e)
	{
		handleException("CCommandBar_setIndexButtonCurrent", e);
		return -1;
	}
	
}	// eof CCommandBar_setIndexButtonCurrent



function CCommandBar_getIndexButtonCurrent()
{
	return this.m_iIdxCurrentButton;
}


/**
 * store information about a single button
 */
function CCommandBarButton()
{
	// index of button in command bar list
	this.m_iIndex = undefined;
	this.setIndex = CCommandBarButton_setIndex;
	this.getIndex = CCommandBarButton_getIndex;
	
	// id attribute of input html control
	this.m_strId = undefined;
	this.setId = CCommandBarButton_setId;
	this.getId = CCommandBarButton_getId;

	// URL of image of button
	this.m_strImageURL = undefined;
	this.setImageURL = CCommandBarButton_setImageURL;
	this.getImageURL = CCommandBarButton_getImageURL;

	// tooltip over button control
	this.m_strToolTip = undefined;
	this.setToolTip = CCommandBarButton_setToolTip;
	this.getToolTip = CCommandBarButton_getToolTip;
}


/**
 * set property index
 */
function CCommandBarButton_setIndex(pi_iValue)
{
	try
	{
		if ("number" != typeof(pi_iValue))
			return -2;
		
		this.m_iIndex = pi_iValue;
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBarButton_setIndex", e);
		return -1;
	}
	
}


function CCommandBarButton_getIndex()
{
	return this.m_iIndex;
}


/**
 * set property id
 */
function CCommandBarButton_setId(pi_strValue)
{
	try
	{
		if ("string" != typeof(pi_strValue))
			return -2;
		
		this.m_strId = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBarButton_setId", e);
		return -1;
	}
	
}


function CCommandBarButton_getId()
{
	return this.m_strId;
}


/**
 * set property imageURL
 */
function CCommandBarButton_setImageURL(pi_strValue)
{
	try
	{
		if ("string" != typeof(pi_strValue))
			return -2;
		
		this.m_strImageURL = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBarButton_setImageURL", e);
		return -1;
	}
	
}


function CCommandBarButton_getImageURL()
{
	return this.m_strImageURL;
}


/**
 * set property toolTip
 */
function CCommandBarButton_setToolTip(pi_strValue)
{
	try
	{
		if ("string" != typeof(pi_strValue))
			return -2;
		
		this.m_strToolTip = pi_strValue;
		return 1;
	}
	catch(e)
	{
		handleException("CCommandBarButton_setToolTip", e);
		return -1;
	}
	
}


function CCommandBarButton_getToolTip()
{
	return this.m_strToolTip;
}
