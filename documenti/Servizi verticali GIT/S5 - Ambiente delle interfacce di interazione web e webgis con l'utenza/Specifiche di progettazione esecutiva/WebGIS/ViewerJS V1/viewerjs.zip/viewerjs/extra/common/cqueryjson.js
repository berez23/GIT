/**
 * filename: cqueryjson.js
 * author: CALEFFI Andrea
 * create : 2011-06-30
 * update version: 2011-06-30
 * version: 1.0
 * description: utilities for queryjson
 */


//
// generic function to call queryJSON server procedure
//
function handlerQueryJSON(pi_strURL, pi_strCallback, pi_strPostData)
{
	try
	{
		if (undefined == pi_strURL)
			return -3;
		
		if (undefined == pi_strCallback)
			return -4;
		
		function callFail(o)
		{
			try
			{
				var thisI = o.argument[0];
				var objEvent = 
					{ 
						code: -100
						, ajax: o
						, url: o.argument[1]
						, postData: o.argument[2] 
					};
				thisI[pi_strCallback](objEvent);
			}
			catch(e)
			{
				handleException('callFail', e);
			}
			
		}	// callFail
		
		function callSuccess(o)
		{
			var thisI = o.argument[0];
			var objEvent = 
			{ 
				code: 0
				, ajax: o
				, url: o.argument[1]
				, postData: o.argument[2] 
			};
			
			try
			{
				var strJSON = o.responseText;
				
				if (undefined == strJSON)
					objEvent.code = -101;
				else
				{
					objEvent.object = eval("(" + strJSON + ")");
					
					if (undefined == objEvent.object)
						objEvent.code = -102;
					else
					{
						if (undefined == objEvent.object.status)
							objEvent.code = -103;
						else
						{
							if (objEvent.object.status.code <= 0)
								objEvent.code = -104;
							else
								objEvent.code = 1;
						}
					}
				}
			}
			catch(e)
			{
				objEvent.code = -1;
				objEvent.exception = e; 
			}
			thisI[pi_strCallback](objEvent);
		}	// callSuccess
	
		var 
			ajaxCallback =
			{
				  success : callSuccess,
				  failure : callFail,
				  argument: [ this, pi_strURL, pi_strPostData, pi_strCallback ]
			};
		
		var request = YAHOO.util.Connect.asyncRequest('POST', pi_strURL, ajaxCallback, pi_strPostData);
	}
	catch(e)
	{
		handleException('handlerQueryJSON', e);
		return -1;
	}
} // eof handlerQueryJSON


//
//check event object parameter return from an asyncrhonous call to server
//
function checkEventObject(pi_eventObj)
{
	try
	{
		if (undefined == pi_eventObj)
		{
			alert('Evento oggetto non definito');
			return -100;
		}
		
		if (undefined == pi_eventObj.code)
		{
			alert('Codice evento oggetto non definito');
			return -101;
		}
		
		if (pi_eventObj.code <= 0)
		{
			var strMsg = 'Errore codice evento [' + pi_eventObj.code + ']';
			
			if (undefined != pi_eventObj.exception)
				strMsg += '\nDettagli eccezione'
					+ '\n  ' + pi_eventObj.exception.toString();
	
			if (undefined != pi_eventObj.object)
				if (undefined != pi_eventObj.object.status)
					strMsg += '\nDettagli stato'
						+ '\n  Codice [' + pi_eventObj.object.status.code + ']'
						+ '\n  Descrizione [' + pi_eventObj.object.status.descr + ']';
	
			if (undefined != pi_eventObj.ajax)
				strMsg += '\nDettagli Ajax'
					+ '\n  Transaction id: ' + pi_eventObj.ajax.tId
					+ '\n  HTTP status: ' + pi_eventObj.ajax.status
					+ '\n  Status code message'
					+ '\n  URL=' + pi_eventObj.url
					+ '\n  PostData=' + pi_eventObj.postData;
				
			alert(strMsg);
			return -102;
		}
		
		return 1;
	}
	catch(e)
	{
		handleException('checkEventObject', e);
		return -1;
	}
	
	return 0;
} // checkEventObject