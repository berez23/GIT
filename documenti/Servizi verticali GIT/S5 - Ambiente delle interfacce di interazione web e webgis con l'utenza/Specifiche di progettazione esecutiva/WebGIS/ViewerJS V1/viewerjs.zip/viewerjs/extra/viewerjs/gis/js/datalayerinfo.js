/**
 * filename : datalayerinfo.js
 * version : 1.0
 * create date : 2011-07-06
 * update date : 2011-07-06
 * description : store info about a single layer
 */


/**
 * Store info about a layer to be displayed in map
 */
function CDataLayerInfo()
{
	// index of layer in dbmap
	//this.dbmapIdx = undefined;

	// name of layer in dbmapjs
	this.m_strLayerName = undefined;
	this.setLayerName = CDataLayerInfo_setLayerName;
	this.getLayerName = CDataLayerInfo_getLayerName;
	
	// url of wms layer (prefix) - required
	this.m_strLayerURL = undefined;
	this.setLayerURL = CDataLayerInfo_setLayerURL;
	this.getLayerURL = CDataLayerInfo_getLayerURL;

	// srs to be used - optional
	this.m_strLayerSRS = undefined;
	this.setLayerSRS = CDataLayerInfo_setLayerSRS;
	this.getLayerSRS = CDataLayerInfo_getLayerSRS;

	// wms image retrieval format - required
	this.m_strLayerFormat = undefined;
	this.setLayerFormat = CDataLayerInfo_setLayerFormat;
	this.getLayerFormat = CDataLayerInfo_getLayerFormat;

	//minimum level of zoom to display layer
	this.m_iLayerZoomIn = undefined;
	this.setLayerZoomIn = CDataLayerInfo_setLayerZoomIn;
	this.getLayerZoomIn = CDataLayerInfo_getLayerZoomIn;
	
	// maximum level of zoom to display layer
	this.m_iLayerZoomOut = undefined;
	this.setLayerZoomOut = CDataLayerInfo_setLayerZoomOut;
	this.getLayerZoomOut = CDataLayerInfo_getLayerZoomOut;

	// state if layer is visible
	this.m_bLayerVisible = undefined;
	this.setLayerVisible = CDataLayerInfo_setLayerVisible;
	this.getLayerVisible = CDataLayerInfo_getLayerVisible;

	// name of menu item to display in UI - required
	this.m_strMenuName = undefined;
	this.setMenuName = CDataLayerInfo_setMenuName;
	this.getMenuName = CDataLayerInfo_getMenuName;

	// store list of items in layer
	this.m_astrItem = new Array();
	this.addItem = CDataLayerInfo_addItem;
	this.getItemCount = CDataLayerInfo_getItemCount;
	this.getItem = CDataLayerInfo_getItem;
	
	// id of layer
	this.m_iId = undefined;
	this.setId = CDataLayerInfo_setId;
	this.getId = CDataLayerInfo_getId;
	
	// index of layer in dbmapjs control
	this.m_iDbMAPIndex = undefined;
	this.setDbMAPIndex = CDataLayerInfo_setDbMAPIndex; 
	this.getDbMAPIndex = CDataLayerInfo_getDbMAPIndex; 
}


/*
 * set LayerName
 */
function CDataLayerInfo_setLayerName(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strLayerName = pi_strValue;
	return 1;
}


function CDataLayerInfo_getLayerName()
{
	return this.m_strLayerName;
}


/*
 * set LayerURL
 */
function CDataLayerInfo_setLayerURL(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strLayerURL = pi_strValue;
	return 1;
}


function CDataLayerInfo_getLayerURL()
{
	return this.m_strLayerURL;
}


/*
 * set LayerSRS
 */
function CDataLayerInfo_setLayerSRS(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strLayerSRS = pi_strValue;
	return 1;
}


function CDataLayerInfo_getLayerSRS()
{
	return this.m_strLayerSRS;
}


/*
 * set LayerFormat
 */
function CDataLayerInfo_setLayerFormat(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strLayerFormat = pi_strValue;
	return 1;
}


function CDataLayerInfo_getLayerFormat()
{
	return this.m_strLayerFormat;
}


/*
 * set LayerZoomIn
 */
function CDataLayerInfo_setLayerZoomIn(pi_iValue)
{
	if ("undefined" == typeof(pi_iValue))
		return -2;
	
	this.m_iLayerZoomIn = pi_iValue;
	return 1;
}


function CDataLayerInfo_getLayerZoomIn()
{
	return this.m_iLayerZoomIn;
}


/*
 * set LayerZoomOut
 */
function CDataLayerInfo_setLayerZoomOut(pi_iValue)
{
	if ("undefined" == typeof(pi_iValue))
		return -2;
	
	this.m_iLayerZoomOut = pi_iValue;
	return 1;
}


function CDataLayerInfo_getLayerZoomOut()
{
	return this.m_iLayerZoomOut;
}


/*
 * set LayerVisible
 */
function CDataLayerInfo_setLayerVisible(pi_bValue)
{
	if ("undefined" == typeof(pi_bValue))
		return -2;
	
	this.m_bLayerVisible = pi_bValue;
	return 1;
}


function CDataLayerInfo_getLayerVisible()
{
	return this.m_bLayerVisible;
}


/*
 * set MenuName
 */
function CDataLayerInfo_setMenuName(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_strMenuName = pi_strValue;
	return 1;
}


function CDataLayerInfo_getMenuName()
{
	return this.m_strMenuName;
}


/**
 * add an item to list
 * 
 * @param pi_strValue
 * @returns
 */
function CDataLayerInfo_addItem(pi_strValue)
{
	if ("undefined" == typeof(pi_strValue))
		return -2;
	
	this.m_astrItem.push(pi_strValue);
}



/**
 * Return number of items in list
 * @returns
 */
function CDataLayerInfo_getItemCount()
{
	return this.m_astrItem.length;
}



/**
 * Return specified item at index
 * 
 * @param pi_iIndex
 * @returns
 */
function CDataLayerInfo_getItem(pi_iIndex)
{
	if ("undefined" == typeof(pi_iIndex))
		return undefined;
	
	if (pi_iIndex >= this.m_astrItem.length)
		return undefined;
	
	return this.m_astrItem[pi_iIndex];
}



/*
 * set LayerId
 */
function CDataLayerInfo_setId(pi_iValue)
{
	if ("undefined" == typeof(pi_iValue))
		return -2;
	
	this.m_iId = pi_iValue;
	return 1;
}


function CDataLayerInfo_getId()
{
	return this.m_iId;
}


/*
 * set DbMAPIndex
 */
function CDataLayerInfo_setDbMAPIndex(pi_iValue)
{
	if ("undefined" == typeof(pi_iValue))
		return -2;
	
	this.m_iDbMAPIndex = pi_iValue;
	return 1;
}


function CDataLayerInfo_getDbMAPIndex()
{
	return this.m_iDbMAPIndex;
}
