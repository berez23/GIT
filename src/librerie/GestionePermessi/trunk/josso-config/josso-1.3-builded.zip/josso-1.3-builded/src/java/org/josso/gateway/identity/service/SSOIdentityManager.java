/*
Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
All rights reserved.
Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

* Neither the name of the JOSSO team nor the names of its
  contributors may be used to endorse or promote products derived
  from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.gateway.identity.service;

import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.service.store.IdentityStore;
import org.josso.gateway.identity.service.store.IdentityStoreKeyAdapter;

/**
 * Single Sing-On Identity Manager Business Interface.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOIdentityManager.java,v 1.16 2005/05/06 21:31:09 sgonzalez Exp $
 */

public interface SSOIdentityManager {

    /**
     * Finds a user based on its name.  The name is a unique identifier of the user, probably the user login.
     * @param name
     *
     * @throws org.josso.gateway.identity.exceptions.NoSuchUserException if the user does not exist.
     */
    SSOUser findUser(String name)
            throws NoSuchUserException, SSOIdentityException;

    /**
     * Finds the user associated to a sso session
     * @param sessionId the sso session identifier
     *
     * @throws org.josso.gateway.identity.exceptions.NoSuchUserException if no user is associated to this session id.
     */
    SSOUser findUserInSession(String sessionId)
        throws NoSuchUserException, SSOIdentityException;

    /**
     * Finds an array of user's roles.
     * Elements in the collection are SSORole instances.
     *
     * @param username
     *
     * @throws org.josso.gateway.identity.exceptions.SSOIdentityException
     */
    SSORole[] findRolesByUsername(String username)
        throws SSOIdentityException;

    /**
     * This method validates that the received username matchs an existing user
     * @param username
     *
     * @throws NoSuchUserException if the user does not exists or is invalid.
     * @throws SSOIdentityException if an error occurs while checking if user exists.
     */
    void useExists(String username)
        throws NoSuchUserException, SSOIdentityException;

    

    void setIdentityStore(IdentityStore is);

    void setIdentityStoreKeyAdapter(IdentityStoreKeyAdapter a);

}
