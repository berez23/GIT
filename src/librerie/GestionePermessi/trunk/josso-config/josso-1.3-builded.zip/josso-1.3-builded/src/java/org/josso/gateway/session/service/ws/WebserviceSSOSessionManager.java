/* 
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:
   
   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.gateway.session.service.ws;

import org.josso.gateway.session.SSOSession;
import org.josso.gateway.session.service.SSOSessionManager;
import org.josso.gateway.session.service.SessionIdGenerator;
import org.josso.gateway.session.service.store.SessionStore;
import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Collection;

/**
 * Webservice client implementation for the SSO Session Manager based on
 * the Axis-generated Stub & Skeleton.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a> 
 * @version CVS $Id: WebserviceSSOSessionManager.java,v 1.8 2005/04/20 18:54:50 sgonzalez Exp $
 */

public class WebserviceSSOSessionManager implements org.josso.gateway.session.service.SSOSessionManager {
    private static final Log logger = LogFactory.getLog(SSOSessionManager.class);

    private org.josso.gateway.session.service.ws.impl.SSOSessionManager _wsSSOSessionManager;

    /**
     * Build a Webservice SSO Session Manager.
     *
     * @param wsSSOSessionManager the SOAP stub to be invoked.
     */
    public WebserviceSSOSessionManager(org.josso.gateway.session.service.ws.impl.SSOSessionManager wsSSOSessionManager) {
        _wsSSOSessionManager = wsSSOSessionManager;
    }

    /**
     * Initiates a new session. The session id is returned.
     *
     * @return the new session identifier.
     */
    public String initiateSession(String username)
            throws SSOSessionException {
        try {
            return _wsSSOSessionManager.initiateSession(username);
        } catch (java.rmi.RemoteException e) {
            throw new SSOSessionException(e.getMessage(), e);
        }
    }

    /**
     * This method accesss the session associated to the received id.
     * This resets the session last access time and updates the access count.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    public void accessSession(String sessionId)
            throws NoSuchSessionException, SSOSessionException {

        try {
            _wsSSOSessionManager.accessSession(sessionId);
        } catch (org.josso.gateway.session.service.ws.impl.NoSuchSessionException e) {
            throw new org.josso.gateway.session.exceptions.NoSuchSessionException(e.getMessage());

        } catch (java.rmi.RemoteException e) {
            throw new SSOSessionException(e.getMessage(), e);
        }

    }

    /**
     * Gets an SSO session based on its id.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    public SSOSession getSession(String sessionId)
            throws NoSuchSessionException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }

    /**
     * Gets all SSO sessions.
     */
    public Collection getSessions() throws SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }

    /**
     * Gets an SSO session based on the associated user.
     *
     * @param username the username used when initiating the session.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    public Collection getUserSessions(String username)
            throws NoSuchSessionException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }


    /**
     * Invalidates a session.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    public void invalidate(String sessionId)
            throws NoSuchSessionException, SSOSessionException {

        try {
             _wsSSOSessionManager.invalidate(sessionId);
        } catch (java.rmi.RemoteException e) {
            throw new SSOSessionException(e.getMessage(), e);
        }

    }

    /**
     * Check all sessions and remove those that are not valid from the store.
     * This method is invoked periodically to update sessions state.
     */
    public void checkValidSessions() {

        try {
             _wsSSOSessionManager.checkValidSessions();
        } catch (java.rmi.RemoteException e) {
        }

    }

    /**
     * For compatibility only
     */
    public void initialize() {
    }

    /**
     * For compatibility only
     */
    public void setSessionStore(SessionStore ss) {
        throw new UnsupportedOperationException("Not supporte by this implementation");
    }

    /**
     * For compatibility only
     */
    public void setSessionIdGenerator(SessionIdGenerator g) {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }
}
