/**
 * SSOIdentityManagerSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha ago 27, 2004 (08:42:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.identity.service.ws.impl;

import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.SecurityDomain;
import org.josso.Lookup;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class SSOIdentityManagerSoapBindingImpl implements org.josso.gateway.identity.service.ws.impl.SSOIdentityManager {

    public void setIdentityStoreKeyAdapter(Object in0) throws RemoteException {

    }

    public org.josso.gateway.identity.service.ws.impl.SSOUser findUser(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException {

        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();

            org.josso.gateway.identity.SSOUser ssoUser;
            ssoUser = domain.getIdentityManager().findUser(in0);
            return adaptSSOUser(ssoUser);
        } catch (NoSuchUserException e) {
            throw new org.josso.gateway.identity.service.ws.impl.NoSuchUserException();
        } catch (SSOIdentityException e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        } catch (Exception e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        }

    }

    public org.josso.gateway.identity.service.ws.impl.SSOUser findUserInSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException {


        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            org.josso.gateway.identity.SSOUser ssoUser;
            ssoUser = domain.getIdentityManager().findUserInSession(in0);
            return adaptSSOUser(ssoUser);
        } catch (NoSuchUserException e) {
            throw new org.josso.gateway.identity.service.ws.impl.NoSuchUserException();
        } catch (SSOIdentityException e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        } catch (Exception e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        }
    }

    public SSORole[] findRolesByUsername(String in0) throws RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException {


        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            org.josso.gateway.identity.SSORole[] ssoUserRoles;
            ssoUserRoles = domain.getIdentityManager().findRolesByUsername(in0);
            return adaptSSORoles(ssoUserRoles);
        } catch (SSOIdentityException e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        } catch (Exception e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        }

    }

    public void useExists(String in0) throws RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, NoSuchUserException {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            domain.getIdentityManager().useExists(in0);
        } catch (NoSuchUserException e) {
            throw new org.josso.gateway.identity.service.ws.impl.NoSuchUserException();
        } catch (SSOIdentityException e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        } catch (Exception e) {
            throw new org.josso.gateway.identity.service.ws.impl.SSOIdentityException();
        }
    }

    protected org.josso.gateway.identity.service.ws.impl.SSOUser
            adaptSSOUser(org.josso.gateway.identity.SSOUser srcSSOUser) {
        org.josso.gateway.identity.service.ws.impl.SSOUser targetSSOUser =
                new org.josso.gateway.identity.service.ws.impl.SSOUser();

        targetSSOUser.setName(srcSSOUser.getName());
        targetSSOUser.setSessionId(srcSSOUser.getSessionId());

        //org.josso.gateway.identity.service.ws.impl.SSONameValuePair targetSSONameValuePair[];

        List targetSSONameValuePair = new ArrayList();
        org.josso.gateway.SSONameValuePair[] srcSSONameValuePair =
                srcSSOUser.getProperties();

        for (int i = 0; i < srcSSONameValuePair.length; i++) {
            targetSSONameValuePair.add(adaptSSONameValuePair(srcSSONameValuePair[i]));
        }

        targetSSOUser.setProperties((org.josso.gateway.identity.service.ws.impl.SSONameValuePair[])
                targetSSONameValuePair.toArray(
                        new org.josso.gateway.identity.service.ws.impl.SSONameValuePair[srcSSONameValuePair.length]
                )
        );


        return targetSSOUser;
    }

    protected org.josso.gateway.identity.service.ws.impl.SSONameValuePair
            adaptSSONameValuePair(org.josso.gateway.SSONameValuePair srcSSONameValuePair) {
        org.josso.gateway.identity.service.ws.impl.SSONameValuePair targetSSONameValuePair =
                new org.josso.gateway.identity.service.ws.impl.SSONameValuePair();

        targetSSONameValuePair.setName(srcSSONameValuePair.getName());
        targetSSONameValuePair.setValue(srcSSONameValuePair.getValue());

        return targetSSONameValuePair;
    }


    protected org.josso.gateway.identity.service.ws.impl.SSORole
            adaptSSORole(org.josso.gateway.identity.SSORole srcSSORole) {
        org.josso.gateway.identity.service.ws.impl.SSORole targetSSORole =
                new org.josso.gateway.identity.service.ws.impl.SSORole();

        targetSSORole.setName(srcSSORole.getName());
        return targetSSORole;

    }

    protected org.josso.gateway.identity.service.ws.impl.SSORole[]
            adaptSSORoles(org.josso.gateway.identity.SSORole[] srcSSORoles) {

        ArrayList targetRoles = new ArrayList();
        for (int i = 0; i < srcSSORoles.length; i++) {
            targetRoles.add(adaptSSORole(srcSSORoles[i]));
        }

        return (org.josso.gateway.identity.service.ws.impl.SSORole[])
                targetRoles.toArray(new SSORole[targetRoles.size()]);
    }


}
