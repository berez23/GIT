/* 
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:
   
   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.jb32.agent;

import org.jboss.util.CachePolicy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.HashMap;
import java.security.Principal;

/**
 * Security Manager JBoss Cache Policy proxy.
 * <p>
 * Its used inside JBoss's JaasSecurityManager class to cache authenticated user entries.
 * This class replaces, in the JaasSecurityManager, the default CachePolicy to allow
 * handling cache entry lookups using SSO Session Identifier Principals as keys.
 *
 * @deprecated No longer needed for JBoss 3.2.6 .
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: SessionMappingCachePolicy.java,v 1.1 2005/04/20 21:27:33 sgonzalez Exp $
 */

public class SessionMappingCachePolicy implements CachePolicy {
    private static final Log logger = LogFactory.getLog(SessionMappingCachePolicy.class);

    /** HashMap<SSOUserPrincipal, JossoSessionIdPrincipal> */
    private HashMap _userSessionMap = new HashMap();

    /** Proxyed Cache Policy */
    private CachePolicy _cachePolicy;

    /**
     * Constructs a SessionMappingCachePolicy instance which acts as a proxy
     * of the supplied CachePolicy instance.
     *
     * @param cachePolicy the cache policy to be proxyed
     */
    public SessionMappingCachePolicy(CachePolicy cachePolicy ) {
        _cachePolicy = cachePolicy;
    }

    /**
     * Used to associate a Session Principal with a SSOUser Principal.
     * This method is invoked by the JBossCatalinaRealm on successful
     * authentication against the SecurityManager.
     * Everytime an entry is requested given a user Principal key, before
     * calling the proxyed CachePolicy, it will map such key to the
     * session key used for storing cache entries.
     *
     * @param session
     * @param user
     */
    public void attachSessionToUser(Principal session, Principal user ) {
        _userSessionMap.put(user, session);
    }

    /**
     * Returns the object paired with the specified key if it's
     * present in the cache, otherwise must return null. <br>
     * If the supplied key is a user session principal, it will be
     * mapped to the associated user.
     *
     * @param key the key paired with the object
     * @see #peek
     */
    public Object get(Object key) {
    Object targetKey = key;

        logger.trace("Get, Entries = " + _cachePolicy.size());

        synchronized (this) {
            if (_userSessionMap.containsKey(key))
            {
                targetKey = _userSessionMap.get(key);

                logger.trace("Get, mapped user principal '" + key + "'" +
                             " to session principal '" + targetKey + "'"
                            );
            }
        }

        return _cachePolicy.get(targetKey);
    }

    /**
     * Returns the object paired with the specified key if it's
     * present in the cache, otherwise must return null. <br>
     * If the supplied key is a user session principal, it will be
     * mapped to the associated user.
     *
     * @param key the key paired with the object
     * @see #get
     */
    public Object peek(Object key) {
    Object targetKey = key;

        logger.trace("Peek, Entries = " + _cachePolicy.size());

        synchronized (this) {
            if (_userSessionMap.containsKey(key))
            {
                targetKey = _userSessionMap.get(key);

                logger.trace("Peek, mapped user principal '" + key + "'" +
                             " to session principal '" + targetKey + "'"
                            );
            }
        }

        return _cachePolicy.peek(targetKey);
    }

    /**
     * Inserts the specified object into the cache following the
     * implemented policy. <br>
     *
     * @param key the key paired with the object
     * @param object the object to cache
     * @see #remove
     */
    public void insert(Object key, Object object) {
        logger.trace("Insert, key = " + key + ", object = " + object + " Entries = " + _cachePolicy.size());

        _cachePolicy.insert(key, object);
    }

    /**
     * Remove the cached object paired with the specified key. <br>
     * In case the supplied key is a user principal mapped to a session principal, it will
     * be removed.
     *
     * @param key the key paired with the object
     * @see #insert
     */
    public void remove(Object key) {
        logger.trace("Remove, key = " + key +", Entries = " + _cachePolicy.size());

            synchronized (this) {
                if (_userSessionMap.containsKey(key))
                {
                    _userSessionMap.remove(key);
                    logger.trace("Remove, removed session mapping for user '" + key + "'");
                }
            }

        _cachePolicy.remove(key);
    }

    /**
     * Flushes the cached objects from the cache.<br>
     * All user-to-session mapping are removed as well.
     */
    public void flush() {
        logger.trace("Flush Entries = " + _cachePolicy.size());

        _userSessionMap.clear();
        _cachePolicy.flush();
    }

    /**
     * Get the size of the cache.
     */
    public int size() {
        return _cachePolicy.size();
    }

    /**
     * create the service, do expensive operations etc
     */
    public void create() throws Exception {
        _cachePolicy.create();
    }

    /**
     * start the service, create is already called
     */
    public void start() throws Exception {
        _cachePolicy.start();
    }

    /**
     * stop the service
     */
    public void stop() {
        _cachePolicy.stop();
    }

    /**
     * destroy the service, tear down
     */
    public void destroy() {
        _cachePolicy.destroy();
    }
}
