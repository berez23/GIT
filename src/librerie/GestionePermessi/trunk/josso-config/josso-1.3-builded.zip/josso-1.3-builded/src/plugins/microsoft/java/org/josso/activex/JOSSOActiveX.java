/*
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.activex;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.beanutils.BeanUtils;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.GatewayServiceLocator;
import org.josso.gateway.session.service.SSOSessionManager;
import org.josso.gateway.session.exceptions.NoSuchSessionException;

import java.util.*;
import java.lang.reflect.InvocationTargetException;
import java.io.InputStream;

/**
 * This component is based on JavaBeans components architecture.
 * It is packaged by the J2SDK ActiveX bridge as an ActiveX control,
 * thereby allowing it to be used as a functional component in an ActiveX container.
 *
 * To use this ActiveX control, you have to follow this steps :
 *
 * <ul>
 *   <li>1. Instantiate the control.</li>
 *   <li>2. Configure control properties using setProperty method. The default implementation uses SOAP,
 *          so you must configure the SOAP end point i.e. setProperty("endpoint", "myhost.com:8080");</li>
 *   <li>3. Initialize the control : invoke the init() method befor using the control.</li>
 *   <li>4. Invoke operations, i.e. accessSession("2F122BEE8684C0BEE186C0BE91083171");</li>
 * </ul>
 *
 * You could specify a differente GatewayServiceLocator class and configure specific properties for it.
 * If no GatewayServiceLocator FQCN is specified, the WebserviceGatewayServiceLocator is used as default.
 *
 * The control configuration can be specified through the "setProperty" method, all properties starting with
 * the "gwy." prefix will be used to configure the GatewayServiceLocator this control uses.
 *
 * If you use the WebserviceGatweayServiceLocator, you can use the following properties :
 * <ul>
 *  <li>gwy.endpoint : the SOAP endpoint</li>
 *  <li>gwy.transportSecurity : "none" or "confidential", default to "none"./li>
 *  <li>gwy.username : the username credential used for the "confidential" transport security.</li>
 *  <li>gwy.password : the passwrord credential used for "confidential" transport security.</li>
 * </ul>
 *
 * Check the Java Console for log messages.
 *
 * @see org.josso.gateway.GatewayServiceLocator
 * @see org.josso.gateway.WebserviceGatewayServiceLocator
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: JOSSOActiveX.java,v 1.1 2005/04/20 21:27:35 sgonzalez Exp $
 */

public class JOSSOActiveX  {

    private static final Log logger = LogFactory.getLog(JOSSOActiveX.class);

    private String _version;
    private SSOIdentityManager _im;
    private SSOSessionManager _sm;
    private Properties _props;

    private String _gwyServiceLocatorClass = "org.josso.gateway.WebserviceGatewayServiceLocator";

    public JOSSOActiveX() {

        _props = new Properties();

        Properties p= new Properties();
        InputStream is = getClass().getResourceAsStream("/org/josso/josso.properties");
        try {
            p.load(is);
            _version = p.get("Name") + "-" + p.get("version");
        } catch (Exception e) {
            _version = "n/a";
        }
    }

    public void init() {
        try {
            GatewayServiceLocator sl = doMakeGatewayServiceLocator();

            logger.info("JOSSOActiveX:Getting new SSOIdentityManager instance");
            _im = sl.getSSOIdentityManager();

            logger.info("JOSSOActiveX:Getting new SSOSessionManager instance");
            _sm = sl.getSSOSessionManager();

            logger.info("JOSSOActiveX:" + getVersion()+" initialized OK");

        } catch (Exception e) {
            logger.error("JOSSOActiveX:" + e.getMessage(), e);
            logger.info("JOSSOActiveX:" + getVersion()+" initialized with ERRORS");
            
            throw new RuntimeException("JOSSOActiveX:Error during initialization : "+
                                       e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

    }

    /**
     * The version associated with this control.
     */
    public String getVersion() {
        return _version;
    }

    /**
     * Finds the user associated to a sso session
     *
     * @param sessionId the sso session identifier
     */
    public SSOUser findUserInSession(String sessionId) {
        try {
            return getIdentityManager().findUserInSession(sessionId);
        } catch (NoSuchUserException e) {
            return null;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }
    }

    /**
     * Returns all properties associated to a given user.
     */
    public SSOProperties getUserProperties(String username) {
        try {
            SSOUser user = getIdentityManager().findUser(username);
            return new SSOProperties(user.getProperties());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

    }

    /**
     * Returns all roles associated to a given user.
     */
    public SSORoles getUserRoles(String username)  {
        try {
            return new SSORoles (getIdentityManager().findRolesByUsername(username));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

    }

    /**
     * Returns true if the user belongs to the given rolename.
     */
    public boolean isUserInRole(String username,String rolename)  {
        try {
            SSORole[] roles = getIdentityManager().findRolesByUsername(username);

            for (int i = 0; i < roles.length; i++) {
                SSORole role = roles[i];
                if (role.getName().equals(rolename)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

    }

    // -----------------------------------------------------------------------------

    /**
     * This method accesss the session associated to the received id.
     * This resets the session last access time and updates the access count.
     *
     * @param sessionId the session id previously returned by initiateSession.
     *
     * @return true if the session is valid, flase otherwise.
     */
    public boolean accessSession(String sessionId) {
        try {
            getSessionManager().accessSession(sessionId);
            return true;
        } catch (NoSuchSessionException e) {
            return false;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

    }

    // -----------------------------------------------------------------------------

    /**
     * This method is used to configure the control.
     * Available properties
     *
     * @param name the property name (i.e. .endpoint)
     * @param value
     */
    public void setProperty(String name, String value) {
        _props.setProperty(name, value);
    }

    /**
     * Returns the value of the specified property.
     */
    public String getProperty(String name) {
        return _props.getProperty(name);
    }

    /**
     * Getter for the configuration property to define the concrete GatewayServiceLocator class.
     *
     * @return the FQCN used to create the GatewayServiceLocatorInstance
     */
    public String getGwyServiceLocatorClass() {
        return _gwyServiceLocatorClass;
    }

    /**
     * Configuration property to define the concrete GatewayServiceLocator class.
     *
     * @param gwyServiceLocatorClass the FQCN used to create the GatewayServiceLocatorInstance
     */
    public void setGwyServiceLocatorClass(String gwyServiceLocatorClass) {
        _gwyServiceLocatorClass = gwyServiceLocatorClass;
    }


    /**
     * Getter for the Identity Manager this control is using.
     */
    protected SSOIdentityManager getIdentityManager() {
        return _im;
    }

    /**
     * Getter for the Session Manager this control is using.
     */
    protected SSOSessionManager getSessionManager() {
        return _sm;
    }


    /**
     * This method creates a new GatewayServiceLocatorInstance using the
     * configured GatewayServiceLocator class.
     *
     * It also sets all configured properties with the prefix "gwy." to the new service locator instance.
     * For example : the "gwy.endpoint" property will be used to set the endpoint property (setEndpoint(""))
     * in the new gateway service locator instance.
     *
     *
     */
    protected GatewayServiceLocator doMakeGatewayServiceLocator() {

        GatewayServiceLocator serviceLocator = null;

        try {
            serviceLocator = (GatewayServiceLocator) Class.forName(_gwyServiceLocatorClass).newInstance();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new RuntimeException("JOSSOActiveX:Can't instantiate gwy service locator : \n" +
                                       e.getMessage() != null ? e.getMessage() : e.toString(), e);
        }

        Enumeration en = _props.keys();
        while (en.hasMoreElements()) {
            String key = (String) en.nextElement();
            Object value = _props.get(key);

            if (key.startsWith("gwy.")) {

                String name = key.substring(4);

                try {


                    if (value != null)
                        BeanUtils.setProperty(serviceLocator, name, value);

                    logger.info("JOSSOActiveX:setting property to GatewayServiceLocator : " + name+ "=" + value);

                } catch (IllegalAccessException e) {
                    logger.info("JOSSOActiveX:Can't set property to GatewayServiceLocator : " + name + "=" + value + "\n" + e.getMessage(), e);

                } catch (InvocationTargetException e) {
                    logger.info("JOSSOActiveX:Can't set property to GatewayServiceLocator : " + name + "=" + value + "\n" + e.getMessage(), e);
                }
            }
        }

        return serviceLocator;
    }



}
