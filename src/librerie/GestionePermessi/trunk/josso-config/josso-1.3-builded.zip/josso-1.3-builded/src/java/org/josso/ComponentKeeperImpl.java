/*
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso;

import org.josso.gateway.session.service.store.SessionStore;
import org.josso.gateway.session.service.SSOSessionManager;
import org.josso.gateway.session.service.SessionIdGenerator;
import org.josso.gateway.identity.service.store.IdentityStore;
import org.josso.gateway.identity.service.store.IdentityStoreKeyAdapter;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.reverseproxy.ReverseProxyConfiguration;
import org.josso.gateway.reverseproxy.ReverseProxyConfigurationImpl;
import org.josso.gateway.GatewayServiceLocator;
import org.josso.gateway.SSOWebConfiguration;
import org.josso.gateway.SSOWebConfigurationImpl;
import org.josso.auth.scheme.AuthenticationScheme;
import org.josso.auth.CredentialStore;
import org.josso.auth.Authenticator;
import org.josso.auth.CredentialStoreKeyAdapter;
import org.josso.agent.SSOAgent;
import org.josso.agent.SSOAgentConfiguration;
import org.josso.agent.SSOAgentConfigurationImpl;
import org.apache.commons.configuration.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.net.URL;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;
import java.io.File;

/**
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: ComponentKeeperImpl.java,v 1.17 2005/04/20 18:54:49 sgonzalez Exp $
 */

public class ComponentKeeperImpl implements ComponentKeeper {

    private static final Log logger = LogFactory.getLog(ComponentKeeperImpl.class);

    /**
     * Package private constructor so that it can be instantiated
     * only by Lookup.
     */
    ComponentKeeperImpl() {

    }

    public SecurityDomain fetchSecurityDomain() throws Exception {

        try {

            Configuration config = loadConfig("josso-config.xml");

            SecurityDomain sd = new SecurityDomainImpl();

            Authenticator a = fetchAuthenticator(config.subset("authenticator"));
            SSOIdentityManager im = fetchIdentityManager(config.subset("sso-identity-manager"));
            SSOSessionManager sm = fetchSessionManager(config.subset("sso-session-manager"));

            sd.setAuthenticator(a);
            sd.setIdentityManager(im);
            sd.setSessionManager(sm);

            fillProperties(config, sd, new String[]{"class"});

            return sd;

        } catch (ConfigurationException ce) {
            logger.error(ce.getMessage(), ce);
            return null;
        }


    }

    protected Authenticator fetchAuthenticator(Configuration config) throws Exception {
        String clazz = config.getString("class");
        Authenticator a = (Authenticator) Class.forName(clazz).newInstance();

        // The AuthenticationScheme
        AuthenticationScheme[] as = fetchAuthenticationSchemes(config);
        a.setAuthenticationSchemes(as);
        fillProperties(config, a, new String[]{"class"});

        return a;
    }

    protected AuthenticationScheme[] fetchAuthenticationSchemes(Configuration config) throws Exception {

        List authSchemes = new ArrayList();
        Collection c = null;

        if (!(config.getProperty("authentication-schemes.authentication-scheme.name") instanceof java.util.Collection)) {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("authentication-schemes.authentication-scheme.name"));
            c = nCol;
        } else
            c = (Collection) config.getProperty("authentication-schemes.authentication-scheme.name");

        for (int i = 0; i < c.size(); i++) {
            Configuration asConfig = config.subset("authentication-schemes.authentication-scheme(" + i + ")");
            AuthenticationScheme as = fetchAuthenticationScheme(asConfig);
            authSchemes.add(as);
        }

        return (AuthenticationScheme[]) authSchemes.toArray(new AuthenticationScheme[authSchemes.size()]);
    }

    /**
    public AuthenticationScheme fetchAuthenticationScheme() throws Exception {

        Configuration config = loadConfig("josso-config.xml");
        AuthenticationScheme as = fetchAuthenticationScheme(config.subset("authenticator.authentication-scheme"));
        return as;

    }
    **/

    protected SSOIdentityManager fetchIdentityManager(Configuration config) throws Exception {

        String clazz = config.getString("class");
        SSOIdentityManager im = (SSOIdentityManager) Class.forName(clazz).newInstance();

        // the identity store
        IdentityStore is = fetchIdentityStore(config.subset("sso-identity-store"));

        IdentityStoreKeyAdapter iska = fetchIdentityStoreKeyAdapter(config.subset("sso-identity-store-key-adapter"));

        im.setIdentityStore(is);
        im.setIdentityStoreKeyAdapter(iska);

        fillProperties(config, im, new String[]{"class"});

        return im;
    }

    protected IdentityStore fetchIdentityStore(Configuration config) throws Exception {
        String clazz = config.getString("class");
        IdentityStore is = (IdentityStore) Class.forName(clazz).newInstance();

        fillProperties(config, is, new String[] {"class"} );
        return is;
    }

    protected IdentityStoreKeyAdapter fetchIdentityStoreKeyAdapter(Configuration config) throws Exception {
        String clazz = config.getString("class");
        IdentityStoreKeyAdapter iska = (IdentityStoreKeyAdapter) Class.forName(clazz).newInstance();

        fillProperties(config, iska, new String[] {"class"} );
        return iska;
    }



    protected AuthenticationScheme fetchAuthenticationScheme(Configuration config) throws Exception {

        String clazz = config.getString("class");
        AuthenticationScheme as = (AuthenticationScheme) Class.forName(clazz).newInstance();

        CredentialStore cs = fetchCredentialStore(config.subset("credential-store"));

        cs.setAuthenticationScheme(as);
        as.setCredentialStore(cs);


        CredentialStoreKeyAdapter cska = fetchCredentialStoreKeyAdapter(config.subset("credential-store-key-adapter"));
        as.setCredentialStoreKeyAdapter(cska);

        fillProperties(config, as, new String[]{"class"});

        return as;
    }

    protected CredentialStore fetchCredentialStore(Configuration config) throws Exception {
        String clazz = config.getString("class");
        CredentialStore cs = (CredentialStore) Class.forName(clazz).newInstance();

        fillProperties(config, cs, new String[]{"class"});
        return cs;
    }

    protected CredentialStoreKeyAdapter fetchCredentialStoreKeyAdapter(Configuration config) throws Exception {
        String clazz = config.getString("class");
        CredentialStoreKeyAdapter cska = (CredentialStoreKeyAdapter) Class.forName(clazz).newInstance();

        fillProperties(config, cska, new String[]{"class"});
        return cska;
    }



    protected SSOSessionManager fetchSessionManager(Configuration config) throws Exception {

        String clazz = config.getString("class");
        SSOSessionManager sm = (SSOSessionManager) Class.forName(clazz).newInstance();

        // the session store
        SessionStore ss = fetchSessionStore(config.subset("sso-session-store"));
        SessionIdGenerator sig = fetchSessionIdGenerator(config.subset("sso-session-id-generator"));

        sm.setSessionStore(ss);
        sm.setSessionIdGenerator(sig);

        fillProperties(config, sm, new String[]{"class"});

        // Initializes the manager ....
        sm.initialize();

        return sm;
    }

    protected SessionStore fetchSessionStore(Configuration config) throws Exception {
        String clazz = config.getString("class");
        SessionStore ss = (SessionStore) Class.forName(clazz).newInstance();

        fillProperties(config, ss, new String[]{"class"});
        return ss;
    }

    protected SessionIdGenerator fetchSessionIdGenerator(Configuration config) throws Exception {
        String clazz = config.getString("class");
        SessionIdGenerator sig = (SessionIdGenerator) Class.forName(clazz).newInstance();

        fillProperties(config, sig, new String[]{"class"});
        return sig;
    }

    /**
     * Instantiates and configurates an SSOAgent.
     */
    public SSOAgent fetchSSOAgent( ) throws Exception {
        try {
            Configuration config = loadConfig("josso-config.xml");

            String agentClass = config.getString("class");

            SSOAgent agent = (SSOAgent)Class.forName(agentClass).newInstance();
            SSOAgentConfiguration cfg = fetchSSOAgentConfiguration(config);
            agent.setConfiguration(cfg);

            GatewayServiceLocator gsl = fetchGatewayServiceLocator(config.subset("service-locator"));

            agent.setGatewayServiceLocator(gsl);

            fillProperties(config, agent, new String[] {"class"} );

            return agent;
        } catch (ConfigurationException ce) {
            throw ce;
        }

    }

    public SSOAgentConfiguration fetchSSOAgentConfiguration(Configuration config) {

        SSOAgentConfiguration cfg = new SSOAgentConfigurationImpl();
        if (config.getList("partner-apps.partner-app.context").size() < 1) {
            return cfg;
        }

        Collection c = null;
        if (!(config.getProperty("partner-apps.partner-app.context") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("partner-apps.partner-app.context"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("partner-apps.partner-app.context");

        for(int i=0; i < c.size(); i++) {
            String context = config.getString("partner-apps.partner-app(" + i + ").context");
            String[] ignoredWebResources = fetchIgnoredWebResources(
                    c.size() <= 1 ? config.subset("partner-apps.partner-app") : config.subset("partner-apps.partner-app(" + i + ")"));

            cfg.addSSOPartnerApp(context, ignoredWebResources);
        }

        return cfg;

    }

    protected String[] fetchIgnoredWebResources(Configuration config) {

        if (config.getList("security-constraint.ignore-web-resource-collection").size() < 1) {
            return new String[0];
        }

        String[] result = config.getStringArray("security-constraint.ignore-web-resource-collection");
        /*
        List result = new ArrayList();
        Collection c = null;

        if (!(config.getProperty("security-constraint.ignore-web-resource-collection") instanceof java.util.Collection))
        {
            result.add(config.getString("security-constraint.ignore-web-resource-collection"));
        } else {
            c = (Collection)config.getProperty("security-constraint.ignore-web-resource-collection");
            for (Iterator iterator = c.iterator(); iterator.hasNext();) {
                String resource = (String) iterator.next();
                result.add(resource);
            }
        }
        return (String[]) result.toArray(new String[result.size()]);
        */
        for (int i = 0; i < result.length; i++) {
            String s = result[i];
            logger.info("Resource = " + result[i]);
        }
        return result;

    }

    /**
     * Instantiates and configures an SSOAgent.
     */
    public ReverseProxyConfiguration fetchReverseProxyConfiguration( ) throws Exception {
        try {
            ReverseProxyConfiguration rpConfig = new ReverseProxyConfigurationImpl();

            Configuration config = loadConfig("josso-config.xml");

            Collection c = null;
            if (!(config.getProperty("proxy-contexts.proxy-context.name") instanceof java.util.Collection))
            {
                List nCol = new ArrayList();
                nCol.add(config.getProperty("proxy-contexts.proxy-context.name"));
                c = nCol;
            } else
                c = (Collection)config.getProperty("proxy-contexts.proxy-context.name");

            for(int i=0; i < c.size(); i++) {
                String name = config.getString("proxy-contexts.proxy-context(" + i + ").name");
                String context = config.getString("proxy-contexts.proxy-context(" + i + ").context");
                String forwardHost = config.getString("proxy-contexts.proxy-context(" + i + ").forward-host");
                String forwardUri = null;

                    // Uri is optional
                    if (config.containsKey("proxy-contexts.proxy-context(" + i + ").forward-uri")) {
                        forwardUri = config.getString("proxy-contexts.proxy-context(" + i + ").forward-uri");
                    }

                    rpConfig.addProxyContext(name, context, forwardHost, forwardUri);

            }

            return rpConfig;
        } catch (ConfigurationException ce) {
            return null;
        }

    }

    /**
     * Instantiates and configures a Gateway Service Locator.
     *
     */
    public GatewayServiceLocator fetchGatewayServiceLocator(Configuration config) throws Exception {
        String clazz = config.getString("class");
        GatewayServiceLocator gsl = (GatewayServiceLocator) Class.forName(clazz).newInstance();

        fillProperties(config, gsl, new String[] {"class"} );

        return gsl;
    }

    public SSOWebConfiguration fetchSSOWebConfiguration() throws Exception {
        try {
            SSOWebConfigurationImpl ssoWebConfig = new SSOWebConfigurationImpl();

            Configuration config = loadConfig("josso-config.xml");

            // Get SSO Web configuration.
            Configuration subConfig = config.subset("sso-web-config");
            fillProperties(subConfig, ssoWebConfig, new String[0]);

            // Get session token configuration
            Configuration sessionTokenCfg = config.subset("sso-web-config.session-token");
            if (!sessionTokenCfg.isEmpty()) {
                String scope = sessionTokenCfg.getString("scope");
                String secure = sessionTokenCfg.getString("secure");

                ssoWebConfig.setSessionTokenScope(scope);
                ssoWebConfig.setSessionTokenSecure(secure);
            }

            return ssoWebConfig;

        } catch (ConfigurationException ce) {
            return null;
        }
    }

    // Utils

    private Configuration loadConfig(String configResourceName) throws Exception {
        ConfigurationFactory factory = new ConfigurationFactory();
        URL configURL = getClass().getResource("/" + configResourceName);

        // try current directory if can't find in classpath
        if (configURL == null)
            configURL = new File(configResourceName).toURL();

        if (configURL == null)
            throw new java.lang.UnsupportedOperationException("Can't find '" + configResourceName + "'");

        factory.setConfigurationURL(configURL);

        Configuration c = factory.getConfiguration();

        logger.info("SSO Config from [" + configURL + "]");
        System.out.println("----------------------------------");
        ConfigurationUtils.dump(c, System.out);
        System.out.println("\n----------------------------------");

        return c;
    }

    private void fillProperties(Configuration config, Object target, String exclude[]) throws Exception {
        Iterator keys = getKeys(config);

        while (keys.hasNext()) {
            String key = (String) keys.next();

            boolean excluded = false;
            for (int i = 0; i < exclude.length; i++)
                if (exclude[i].equalsIgnoreCase(key)) {
                    excluded = true;
                    break;
                }

            if (excluded)
                continue;


            String propertyMethodName = "set" + Character.toUpperCase(key.charAt(0)) + key.substring(1);

            if (!config.containsKey(key))
                continue;

            String propertyValue = config.getString(key);

            try {
                Method m = target.getClass().getMethod(propertyMethodName, new Class[]{String.class});
                m.invoke(target, new String[]{propertyValue});
            } catch (NoSuchMethodException e) {
                continue;
            }
        }

    }

    /**
     * Given a Configuration of SubsetConfiguration instance, returns the associated
     * relative keys.
     *
     * @param cfg the Configuration instance for whom keys are needed.
     *
     */
    private Iterator getKeys(Configuration cfg) {
        List targetKeys = new ArrayList();

        if (!(cfg instanceof SubsetConfiguration)) {
            Iterator keys = cfg.getKeys();
            while (keys.hasNext()) {
                String key = (String) keys.next();

                if (key.indexOf('.') == -1) {
                    targetKeys.add(key);
                }
            }


        } else {

            SubsetConfiguration sc = (SubsetConfiguration) cfg;

            String prefix = sc.getPrefix();

            prefix = prefix.replaceAll("\\([0-9]+\\)", "");

            Iterator keys = sc.getParent().getKeys(prefix);

            while (keys.hasNext()) {
                String key = (String) keys.next();
                String key2 = key.substring(prefix.length() + 1);
                if (key2.indexOf('.') != -1)
                    continue;

                String propertyName = key.substring(key.lastIndexOf(".") + 1);
                targetKeys.add(propertyName);
            }
        }
        return targetKeys.iterator();
    }

    public static void main(String[] args) throws Exception {
        //new ComponentKeeperImpl().fetchSecurityDomain();
        ReverseProxyConfiguration rpc = new ComponentKeeperImpl().fetchReverseProxyConfiguration();

        for (int i=0; i < 2; i++)
            System.out.println("context=" + rpc.getProxyContexts()[i]);
    }

}
