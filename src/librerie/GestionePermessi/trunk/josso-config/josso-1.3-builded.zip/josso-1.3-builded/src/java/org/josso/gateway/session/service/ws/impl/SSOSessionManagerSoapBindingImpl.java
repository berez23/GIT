/**
 * SSOSessionManagerSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha ago 27, 2004 (08:42:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.session.service.ws.impl;

import org.josso.SecurityDomain;
import org.josso.Lookup;

import java.rmi.RemoteException;
import java.util.Collection;

public class SSOSessionManagerSoapBindingImpl implements org.josso.gateway.session.service.ws.impl.SSOSessionManager{
    public org.josso.gateway.session.service.ws.impl.SSOSession getSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        return null;
    }

    public java.lang.String initiateSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    /**
     * Gets all SSO sessions.
     */
    public Object[] getSessions() throws RemoteException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }
    
    public Object[] getUserSessions(String in0) throws RemoteException, NoSuchSessionException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void accessSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            domain.getSessionManager().accessSession(in0);
        } catch (org.josso.gateway.session.exceptions.NoSuchSessionException e) {
          throw new org.josso.gateway.session.service.ws.impl.NoSuchSessionException();
        } catch (Exception e) {
          throw new org.josso.gateway.session.service.ws.impl.SSOSessionException();
        }

    }



    public void invalidate(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void checkValidSessions() throws java.rmi.RemoteException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void initialize() throws RemoteException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

}
