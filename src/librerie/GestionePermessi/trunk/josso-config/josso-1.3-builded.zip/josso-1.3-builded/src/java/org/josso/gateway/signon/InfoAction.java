package org.josso.gateway.signon;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.log4j.Logger;
import org.josso.gateway.SSOGateway;
import org.josso.gateway.SSOException;
import org.josso.gateway.session.SSOSession;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.SSORole;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: InfoAction.java,v 1.3 2004/09/18 21:08:44 sgonzalez Exp $
 */

public class InfoAction extends SignonBaseAction {

    private static final Logger logger = Logger.getLogger(InfoAction.class);

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) {
        String jossoSessionId = getJossoSessionId(request);

        if (jossoSessionId != null) {
            try {
                SSOGateway g = getSSOGateway();
                SSOUser user = g.findUserInSession(jossoSessionId);
                SSOSession session = g.findSession(jossoSessionId);
                SSORole[] roles = g.findRolesByUsername(user.getName());

                request.setAttribute(KEY_JOSSO_USER, user);
                request.setAttribute(KEY_JOSSO_USER_ROLES, roles);
                request.setAttribute(KEY_JOSSO_SESSION, session);

                if (logger.isDebugEnabled())
                    logger.debug("[execute()] stored user : " + user + " under key : " + KEY_JOSSO_USER);
                
                if (logger.isDebugEnabled())
                    logger.debug("[execute()] stored session : " + session + " under key : " + KEY_JOSSO_SESSION);

            } catch (SSOException e) {
                if (logger.isDebugEnabled())
                    logger.error(e.getMessage(), e);
                
            } catch (Exception e) {
                logger.error(e, e);
            }

        }

        return mapping.findForward("success");
    }

}
