package org.josso.gateway.signon;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.cert.X509Certificate;

/**
 * This action redirects to the propper action based on the authentication scheme configurated.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: LoginSelectorAction.java,v 1.3 2005/03/30 20:07:39 sgonzalez Exp $
 */
public class LoginSelectorAction extends SignonBaseAction {
    private static final Log logger = LogFactory.getLog(LoginSelectorAction.class);

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) {

        boolean clientAuth =
                (request.getAttribute("javax.servlet.request.X509Certificate") != null);

        if (clientAuth) {

            ActionForward af = mapping.findForward("strong-authentication");
            String path = af.getPath();

            String host = request.getHeader("Host");

            // if (host.indexOf(':') != -1)
            //    host = host.substring(0, host.indexOf(':'));

            String strongAuthLoginUrl = "https://" + host + path + "?josso_cmd=login" +
                    (request.getQueryString() != null ?
                    "&" + request.getQueryString() : ""
                    );


            try {
                logger.debug("Redirecting to: " + strongAuthLoginUrl);
                response.sendRedirect(strongAuthLoginUrl);
                return null;
            } catch (Exception e) {
            }
        }

        return mapping.findForward("username-password");

    }

}
