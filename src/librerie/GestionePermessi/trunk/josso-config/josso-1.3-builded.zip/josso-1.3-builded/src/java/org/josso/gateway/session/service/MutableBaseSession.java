/*
   Copyright (c) 2004, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.gateway.session.service;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.josso.gateway.session.SSOSessionListener;

import java.util.ArrayList;

/**
 * This session implementation can be modified after creation, session stores that need re-build session
 * state can use this class to restore original session attribute values.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: MutableBaseSession.java,v 1.2 2005/04/14 15:38:59 sgonzalez Exp $
 */
public class MutableBaseSession extends BaseSessionImpl {

    private static final Log logger = LogFactory.getLog(MutableBaseSession.class);

    /**
     * Setter for the expirig property, normale set to false.
     */
    public void setExpiring(boolean expiring) {
        _expiring = expiring;
    }

    /**
     * Setter for the last access time.  This value is also modified by the setCreation time method.
     */
    public void setLastAccessedTime(long lastAccessedTime) {
        _lastAccessedTime = lastAccessedTime;
    }

    /**
     * Setter for the access count.
     */
    public void setAccessCount(long accessCount) {
        _accessCount = accessCount;
    }

    
    public void setListeners(SSOSessionListener listener[]) {
        _listeners = new ArrayList();
        for (int i = 0; i < listener.length; i++) {
            SSOSessionListener ssoSessionListener = listener[i];
            _listeners.add(ssoSessionListener);
        }
    }



}
