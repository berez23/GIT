<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<?php
/**
 Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
 All rights reserved.
 Redistribution and use in source and binary forms, with or
 without modification, are permitted provided that the following
 conditions are met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in
   the documentation and/or other materials provided with the
   distribution.

 * Neither the name of the JOSSO team nor the names of its
   contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.
*/

/**
 * php JOSSO parnter application sample
 *
 * @version $Id: sample.php,v 1.6 2005/02/02 16:22:03 sgonzalez Exp $
 */
?>
<html>
<head>
	<title>Sample Partner Application - JOSSO</title>
	<meta name="description" content="Java Open Single Signon">
</head>

<body>
    <h1>This is a very simple PHP Josso partner application</h1>
<?php
// jossoagent is automatically instantiated by josso.php,
// declared in auto_prepend_file property of php.ini.

// Get current sso user information,
$user = $josso_agent->getUserInSession();

// Check if user is authenticated
if (isset($user)) {

    // Username associated to authenticated user
    echo 'Username : ' . $user->getName() . '<br><br>';

    // Get a specific user property
    echo 'description=' . $user->getProperty('description') . '<br>';

    // Get all user properties
	$properties = $user->getProperties();
	foreach ($properties as $property) {
		echo $property['name'] . '=' . $property['value'] . '<br>';
	}

	// Get all user roles
	$roles = $josso_agent->findRolesByUsername($user->getName());
	echo '<h2>Roles</h2>';
	foreach ($roles as $role) {
		echo $role->getName() . '<br>';
	}

	// Check if user belongs to a specific role
	if ($josso_agent->isUserInRole('role1')) {
		echo '<h3>user is in role1</h3>';
	}

    // Display logout url, use the "back_to" parameter to tell
    // the gateway where to redirect the user go after logout.
	// Replace localhost by your php server hostname
	$logout_url = $josso_agent->getGatewayLogoutUrl() .
	    '?josso_back_to=http://localost/php-partnerapp/sample.php';

	echo 'Click <a href="' . $logout_url . '">here</a> to logout ...<br>';


} else {

    // User is unknown..
    echo '<h2>you are an annonymous user ...</h2>';

    // Display login url, use the "back_to" parameter to tell
    // the gateway where to redirect the user after a the authentication succeeds.
	// Replace localhost by your php server hostname
	$login_url = $josso_agent->getGatewayLoginUrl() .
	    '?josso_back_to=http://localhost/php-partnerapp/sample.php';

	echo 'Click <a href="' . $login_url . '">here</a> to login ...';

}
?>
</body>
</html>