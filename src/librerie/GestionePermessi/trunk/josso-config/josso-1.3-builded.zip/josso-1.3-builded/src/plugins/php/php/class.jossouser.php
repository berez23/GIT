<?php
/**
 * PHP Josso User class definition.
 */

/**
 Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
 All rights reserved.
 Redistribution and use in source and binary forms, with or
 without modification, are permitted provided that the following
 conditions are met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in
   the documentation and/or other materials provided with the
   distribution.

 * Neither the name of the JOSSO team nor the names of its
   contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.
*/

/**
 * PHP Josso User implementation.
 * @package  org.josso.agent.php
 *
 * @author Sebastian Gonzalez Oyuela <sgonzalez@josso.org>
 * @version $Id: class.jossouser.php,v 1.1 2005/04/20 21:27:36 sgonzalez Exp $
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 */
class jossouser {

	// Current user name, string
	var $name;
	
	// User properties, string[]
	var $properties;
	
	/**
	* Constructor
	* 
	* @param string n the user name
	* @param array p user custom properties
	* @param strgin s sso session id
	*
	* @access public
	*/
	function jossouser($n, $p) {
		$this->name = $n;
		$this->properties = $p;
	}
	
	/**
	 * Gets the user name.
	 *
	 * @return string the username.
	 *
	 * @access public
	 */
	function getName() {
		return $this->name;
	}
	
	/**
	 * Gets user custom properties. Each element is a two elements array represneting a property with name and value.
	 * Sample properties :
	 * <pre>
     * Array
     *   (
     *       [0] => Array
     *           (
     *               [name] => description
     *               [value] => User1 CN
     *           )
     *
     *       [1] => Array
     *           (
     *               [name] => mail
     *               [value] => user1@joss.org
     *           )
     *
     *   )
     * </pre>
     *
	 * @return array
	 */
	function getProperties() {
		return $this->properties;
	}
	
	/**
	 * Gets a property value based on its name, if any.
	 *
	 * @return string
	 *
	 * @access public
	 */
	function getProperty($name) {
		foreach ($this->properties as $property) {
			if ($property['name'] == $name) {
				return $property['value'];
			}
		}
		return ;	
	}
}
?>