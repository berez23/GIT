package org.josso.gateway.signon;

import org.apache.struts.action.*;
import org.apache.log4j.Logger;
import org.josso.gateway.SSOGateway;
import org.josso.gateway.SSOException;
import org.josso.gateway.SSOWebConfiguration;
import org.josso.gateway.SSOExternalContext;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.Lookup;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: LogoutAction.java,v 1.6 2005/01/13 19:07:58 sgonzalez Exp $
 */

public class LogoutAction extends SignonBaseAction {

    private static final Logger logger = Logger.getLogger(LogoutAction.class);

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {
        try {

            SSOExternalContext ctx = getSSOExternalContext(request);

            // Clear josso cookie
            Cookie ssoCookie = newJossoCookie("-");
            response.addCookie(ssoCookie);

            // Logout user
            SSOGateway g = getSSOGateway();
            g.logout(ctx);

        } catch (SSOException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.login.failed"));
            saveErrors(request, errors);
        }

        // Redirect the user to the propper page, if any
        String back_to = request.getParameter(PARAM_JOSSO_BACK_TO);

        if (back_to == null) {
            // Try with the configured URL if any.
            SSOWebConfiguration c = Lookup.getInstance().lookupSSOWebConfiguration();
            back_to = c.getLogoutBackToURL();
        }

        if (back_to != null) {
            if (logger.isDebugEnabled())
                logger.debug("[logout()], ok->redirecting to : " + back_to);
            response.sendRedirect(response.encodeRedirectURL(back_to));
            return null; // No forward is needed.
        }

        if (logger.isDebugEnabled())
            logger.debug("[logout()], ok");

        return mapping.findForward("success");
    }

}
