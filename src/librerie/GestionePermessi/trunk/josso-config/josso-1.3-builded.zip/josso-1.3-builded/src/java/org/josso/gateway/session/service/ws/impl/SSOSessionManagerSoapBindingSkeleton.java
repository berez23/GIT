/**
 * SSOSessionManagerSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 19, 2005 (03:59:52 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.session.service.ws.impl;

public class SSOSessionManagerSoapBindingSkeleton implements org.josso.gateway.session.service.ws.impl.SSOSessionManager, org.apache.axis.wsdl.Skeleton {
    private org.josso.gateway.session.service.ws.impl.SSOSessionManager impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("initialize", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "initialize"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("initialize") == null) {
            _myOperations.put("initialize", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("initialize")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("initiateSession", _params, new javax.xml.namespace.QName("", "initiateSessionReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "initiateSession"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("initiateSession") == null) {
            _myOperations.put("initiateSession", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("initiateSession")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("TooManyOpenSessionsException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.TooManyOpenSessionsException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "TooManyOpenSessionsException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("accessSession", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "accessSession"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("accessSession") == null) {
            _myOperations.put("accessSession", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("accessSession")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.NoSuchSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "NoSuchSessionException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSession", _params, new javax.xml.namespace.QName("", "getSessionReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSession"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "getSession"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSession") == null) {
            _myOperations.put("getSession", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSession")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.NoSuchSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "NoSuchSessionException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("getSessions", _params, new javax.xml.namespace.QName("", "getSessionsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "ArrayOf_xsd_anyType"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "getSessions"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSessions") == null) {
            _myOperations.put("getSessions", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSessions")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getUserSessions", _params, new javax.xml.namespace.QName("", "getUserSessionsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "ArrayOf_xsd_anyType"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "getUserSessions"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getUserSessions") == null) {
            _myOperations.put("getUserSessions", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getUserSessions")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.NoSuchSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "NoSuchSessionException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("invalidate", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "invalidate"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("invalidate") == null) {
            _myOperations.put("invalidate", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("invalidate")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.NoSuchSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "NoSuchSessionException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOSessionException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.session.service.ws.impl.SSOSessionException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSessionException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("checkValidSessions", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "checkValidSessions"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("checkValidSessions") == null) {
            _myOperations.put("checkValidSessions", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("checkValidSessions")).add(_oper);
    }

    public SSOSessionManagerSoapBindingSkeleton() {
        this.impl = new org.josso.gateway.session.service.ws.impl.SSOSessionManagerSoapBindingImpl();
    }

    public SSOSessionManagerSoapBindingSkeleton(org.josso.gateway.session.service.ws.impl.SSOSessionManager impl) {
        this.impl = impl;
    }
    public void initialize() throws java.rmi.RemoteException
    {
        impl.initialize();
    }

    public java.lang.String initiateSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.TooManyOpenSessionsException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        java.lang.String ret = impl.initiateSession(in0);
        return ret;
    }

    public void accessSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        impl.accessSession(in0);
    }

    public org.josso.gateway.session.service.ws.impl.SSOSession getSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        org.josso.gateway.session.service.ws.impl.SSOSession ret = impl.getSession(in0);
        return ret;
    }

    public java.lang.Object[] getSessions() throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        java.lang.Object[] ret = impl.getSessions();
        return ret;
    }

    public java.lang.Object[] getUserSessions(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        java.lang.Object[] ret = impl.getUserSessions(in0);
        return ret;
    }

    public void invalidate(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException
    {
        impl.invalidate(in0);
    }

    public void checkValidSessions() throws java.rmi.RemoteException
    {
        impl.checkValidSessions();
    }

}
