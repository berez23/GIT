/*
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.auth.scheme.AuthenticationScheme;
import org.josso.agent.SSOAgent;
import org.josso.gateway.reverseproxy.ReverseProxyConfiguration;
import org.josso.gateway.GatewayServiceLocator;
import org.josso.gateway.SSOWebConfiguration;

/**
 * This class provides a singleton interface to the SSO components
 * This class should be used by any client that needs a reference to a
 * component.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: Lookup.java,v 1.7 2005/02/02 16:21:55 sgonzalez Exp $
 */

public class Lookup {
    private static final Log logger = LogFactory.getLog(Lookup.class);

    /** Single statically instantiated instance of lookup. */
    private static final Lookup INSTANCE = new Lookup();

    /** Reference to the component keeper. */
    private ComponentKeeper _componentKeeper;

    /** Reference to the Cached component instances */
    private SecurityDomain _securityDomain;
    private SSOAgent _ssoAgent;
    private ReverseProxyConfiguration _reverseProxyConfiguration;
    private SSOWebConfiguration _ssoWebConfiguration;

    /**
     * Private constructor so that this class can only be instantiated by the singleton.
     */
    private Lookup() {
    }

    /**
     * Static factory method for getting a reference to the singleton
     * Lookup.
     *
     * @return Lookup
     */
    public static Lookup getInstance() {
        return Lookup.INSTANCE;
    }

    /**
     * Fetches the security domain component.
     *
     * @return a reference to the component specified by name
     */
    public SecurityDomain lookupSecurityDomain() throws Exception {
        if (_securityDomain == null)
            _securityDomain = getComponentKeeper().fetchSecurityDomain();

        return _securityDomain;
    }

    // TODO: REMOVE
    /**
     * Fetches the authentication scheme component by instantiating it each time.
     *
     * @return a reference to the component specified by name
     */
/*
    public AuthenticationScheme lookupAuthenticationScheme() throws Exception {
        return getComponentKeeper().fetchAuthenticationScheme();
    }
*/

    /**
     * Fetches the Single Sign-On agent component.
     *
     * @return a reference to the agent component.
     */
    public SSOAgent lookupSSOAgent() throws Exception {
        if (_ssoAgent == null)
            _ssoAgent = getComponentKeeper().fetchSSOAgent();

        return _ssoAgent;
    }

    /**
     * Fetches the Reverse Proxy Configuration.
     *
     * @return a reference to the reverse proxy configuration.
     */
    public ReverseProxyConfiguration lookupReverseProxyConfiguration() throws Exception {
        if (_reverseProxyConfiguration == null)
            _reverseProxyConfiguration = getComponentKeeper().fetchReverseProxyConfiguration();

        return _reverseProxyConfiguration;
    }

    public SSOWebConfiguration lookupSSOWebConfiguration() throws Exception {
        if (_ssoWebConfiguration == null)
            _ssoWebConfiguration = getComponentKeeper().fetchSSOWebConfiguration();

        return _ssoWebConfiguration ;
    }


    /**
     * Gets the ComponentKeeper for the system.
     * @return the ComponentKeeper
     */
    public ComponentKeeper getComponentKeeper() {
        if (this._componentKeeper == null) {
            this._componentKeeper =
                    new ComponentKeeperImpl();
        }

        return this._componentKeeper;
    }


    public static void main(String args[]) throws Exception {
        SecurityDomain sd = Lookup.getInstance().lookupSecurityDomain();
    }

}
