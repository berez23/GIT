/**
 * SSOSession.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 19, 2005 (03:59:52 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.session.service.ws.impl;

public class SSOSession  implements java.io.Serializable {
    private long accessCount;
    private long creationTime;
    private java.lang.String id;
    private long lastAccessTime;
    private int maxInactiveInterval;
    private java.lang.String username;
    private boolean valid;

    public SSOSession() {
    }

    public SSOSession(
           long accessCount,
           long creationTime,
           java.lang.String id,
           long lastAccessTime,
           int maxInactiveInterval,
           java.lang.String username,
           boolean valid) {
           this.accessCount = accessCount;
           this.creationTime = creationTime;
           this.id = id;
           this.lastAccessTime = lastAccessTime;
           this.maxInactiveInterval = maxInactiveInterval;
           this.username = username;
           this.valid = valid;
    }


    /**
     * Gets the accessCount value for this SSOSession.
     * 
     * @return accessCount
     */
    public long getAccessCount() {
        return accessCount;
    }


    /**
     * Sets the accessCount value for this SSOSession.
     * 
     * @param accessCount
     */
    public void setAccessCount(long accessCount) {
        this.accessCount = accessCount;
    }


    /**
     * Gets the creationTime value for this SSOSession.
     * 
     * @return creationTime
     */
    public long getCreationTime() {
        return creationTime;
    }


    /**
     * Sets the creationTime value for this SSOSession.
     * 
     * @param creationTime
     */
    public void setCreationTime(long creationTime) {
        this.creationTime = creationTime;
    }


    /**
     * Gets the id value for this SSOSession.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this SSOSession.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }


    /**
     * Gets the lastAccessTime value for this SSOSession.
     * 
     * @return lastAccessTime
     */
    public long getLastAccessTime() {
        return lastAccessTime;
    }


    /**
     * Sets the lastAccessTime value for this SSOSession.
     * 
     * @param lastAccessTime
     */
    public void setLastAccessTime(long lastAccessTime) {
        this.lastAccessTime = lastAccessTime;
    }


    /**
     * Gets the maxInactiveInterval value for this SSOSession.
     * 
     * @return maxInactiveInterval
     */
    public int getMaxInactiveInterval() {
        return maxInactiveInterval;
    }


    /**
     * Sets the maxInactiveInterval value for this SSOSession.
     * 
     * @param maxInactiveInterval
     */
    public void setMaxInactiveInterval(int maxInactiveInterval) {
        this.maxInactiveInterval = maxInactiveInterval;
    }


    /**
     * Gets the username value for this SSOSession.
     * 
     * @return username
     */
    public java.lang.String getUsername() {
        return username;
    }


    /**
     * Sets the username value for this SSOSession.
     * 
     * @param username
     */
    public void setUsername(java.lang.String username) {
        this.username = username;
    }


    /**
     * Gets the valid value for this SSOSession.
     * 
     * @return valid
     */
    public boolean isValid() {
        return valid;
    }


    /**
     * Sets the valid value for this SSOSession.
     * 
     * @param valid
     */
    public void setValid(boolean valid) {
        this.valid = valid;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SSOSession)) return false;
        SSOSession other = (SSOSession) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.accessCount == other.getAccessCount() &&
            this.creationTime == other.getCreationTime() &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            this.lastAccessTime == other.getLastAccessTime() &&
            this.maxInactiveInterval == other.getMaxInactiveInterval() &&
            ((this.username==null && other.getUsername()==null) || 
             (this.username!=null &&
              this.username.equals(other.getUsername()))) &&
            this.valid == other.isValid();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getAccessCount()).hashCode();
        _hashCode += new Long(getCreationTime()).hashCode();
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        _hashCode += new Long(getLastAccessTime()).hashCode();
        _hashCode += getMaxInactiveInterval();
        if (getUsername() != null) {
            _hashCode += getUsername().hashCode();
        }
        _hashCode += (isValid() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SSOSession.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/session/service/ws/impl", "SSOSession"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accessCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accessCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creationTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "creationTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastAccessTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lastAccessTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxInactiveInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxInactiveInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("username");
        elemField.setXmlName(new javax.xml.namespace.QName("", "username"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
