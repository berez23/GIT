/**
 * SSOSessionManager.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 19, 2005 (03:59:52 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.session.service.ws.impl;

public interface SSOSessionManager extends java.rmi.Remote {
    public void initialize() throws java.rmi.RemoteException;
    public java.lang.String initiateSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.TooManyOpenSessionsException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public void accessSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public org.josso.gateway.session.service.ws.impl.SSOSession getSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public java.lang.Object[] getSessions() throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public java.lang.Object[] getUserSessions(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public void invalidate(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException;
    public void checkValidSessions() throws java.rmi.RemoteException;
}
