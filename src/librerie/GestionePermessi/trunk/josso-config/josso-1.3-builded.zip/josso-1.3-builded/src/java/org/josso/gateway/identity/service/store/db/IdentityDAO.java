/*
Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
All rights reserved.
Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

* Neither the name of the JOSSO team nor the names of its
  contributors may be used to endorse or promote products derived
  from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.gateway.identity.service.store.db;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.josso.gateway.identity.service.store.SimpleUserKey;
import org.josso.gateway.identity.service.BaseUser;
import org.josso.gateway.identity.service.BaseUserImpl;
import org.josso.gateway.identity.service.BaseRole;
import org.josso.gateway.identity.service.BaseRoleImpl;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.SSONameValuePair;
import org.josso.auth.Credential;
import org.josso.auth.CredentialProvider;
import org.josso.auth.exceptions.SSOAuthenticationException;

import java.sql.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * JDBC Identity DAO, used by AbstractDBIdentityStore.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: IdentityDAO.java,v 1.10 2005/04/20 18:54:49 sgonzalez Exp $
 */

public class IdentityDAO {

    private static final Log logger = LogFactory.getLog(IdentityDAO.class);

    private Connection _conn;
    private CredentialProvider _cp;
    private String _userQueryString;
    private String _rolesQueryString;
    private String _credentialsQueryString;
    private String _userPropertiesQueryString;
    private int _userPropertiesQueryVariables = 0; // This will be calcultated when setting _userPropertiesQueryString

    public IdentityDAO(Connection conn,
                       CredentialProvider cp,
                       String userQueryString,
                       String rolesQueryString,
                       String credentialsQueryString,
                       String userPropertiesQueryString) {

        _conn = conn;
        _cp = cp;
        _userQueryString = userQueryString;
        _rolesQueryString = rolesQueryString;
        _credentialsQueryString = credentialsQueryString;

        // User properties query :
        if (userPropertiesQueryString != null) {
            _userPropertiesQueryString = userPropertiesQueryString;
            _userPropertiesQueryVariables = countQueryVariables(_userPropertiesQueryString);
        }
    }

    public BaseUser selectUser(SimpleUserKey key) throws SSOIdentityException {
        PreparedStatement stmt = null;
        ResultSet result = null;

        try {

            stmt = createPreparedStatement(_userQueryString);
            stmt.setString(1, key.getId());
            result = stmt.executeQuery();

            BaseUser user = fetchUser(result);
            if (user == null)
                throw new SSOIdentityException("Can't find user for : " + key);

            return user;
        } catch (SQLException sqlE) {
            logger.error("SQLException while listing user", sqlE);
            throw new SSOIdentityException("During user listing: " + sqlE.getMessage());
        } catch (IOException ioE) {
            logger.error("IOException while listing user", ioE);
            throw new SSOIdentityException("During user listing: " + ioE.getMessage());
        } catch (Exception e) {
            logger.error("Exception while listing user", e);
            throw new SSOIdentityException("During user listing: " + e.getMessage());
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
        }

    }

    public BaseRole[] selectRolesByUserKey(SimpleUserKey key) throws SSOIdentityException {
        PreparedStatement stmt = null;
        ResultSet result = null;

        try {

            stmt = createPreparedStatement(_rolesQueryString);
            stmt.setString(1, key.getId());
            result = stmt.executeQuery();

            BaseRole[] roles = fetchRoles(result);

            return roles;
        } catch (SQLException sqlE) {
            logger.error("SQLException while listing roles", sqlE);
            throw new SSOIdentityException("During roles listing: " + sqlE.getMessage());

        } catch (IOException ioE) {
            logger.error("IOException while listing roles", ioE);
            throw new SSOIdentityException("During roles listing: " + ioE.getMessage());

        } catch (Exception e) {
            logger.error("Exception while listing roles", e);
            throw new SSOIdentityException("During roles listing: " + e.getMessage());

        } finally {
            closeResultSet(result);
            closeStatement(stmt);
        }
    }

    public Credential[] selectCredentials(SimpleUserKey key) throws SSOIdentityException {
        PreparedStatement stmt = null;
        ResultSet result = null;

        try {

            if (logger.isDebugEnabled())
                logger.debug("[selectCredemtiasl()]]: key=" + key.getId());
            stmt = createPreparedStatement(_credentialsQueryString);
            stmt.setString(1, key.getId());
            result = stmt.executeQuery();

            Credential[] creds = fetchCredentials(result);

            return creds;
        } catch (SQLException sqlE) {
            logger.error("SQLException while listing credentials", sqlE);
            throw new SSOIdentityException("During credentials listing: " + sqlE.getMessage());

        } catch (IOException ioE) {
            logger.error("IOException while listing credentials", ioE);
            throw new SSOIdentityException("During credentials listing: " + ioE.getMessage());

        } catch (Exception e) {
            logger.error("Exception while listing credentials", e);
            throw new SSOIdentityException("During credentials listing: " + e.getMessage());

        } finally {
            closeResultSet(result);
            closeStatement(stmt);
        }

    }

    /**
     * This will execute the configured query to get all user properties.
     * Because we sugested the use of 'UNION' key words to retrieve properties from multiple columns/tables,
     * we probably must send multiple times the username value to "avoid not all variables bound" error.
     * We could avoid this by using JDBC 3.0 drivers in the future.
     * @param key
     *
     * @throws SSOIdentityException
     */

    public SSONameValuePair[] selectUserProperties(SimpleUserKey key) throws SSOIdentityException {
        PreparedStatement stmt = null;
        ResultSet result = null;

        try {

            if (logger.isDebugEnabled())
                logger.debug("[selectUserProperties()]]: key=" + key.getId());
            stmt = createPreparedStatement(_userPropertiesQueryString);

            // We don't jave JDBC 3.0 drivers, so ... bind all variables manually
            for (int i = 1 ; i <= _userPropertiesQueryVariables ; i ++) {
                stmt.setString(i, key.getId());
            }

            result = stmt.executeQuery();

            SSONameValuePair[] props = fetchSSONameValuePairs(result);

            return props;
        } catch (SQLException sqlE) {
            logger.error("SQLException while listing user properties", sqlE);
            throw new SSOIdentityException("During user properties listing: " + sqlE.getMessage());

        } catch (IOException ioE) {
            logger.error("IOException while listing user properties", ioE);
            throw new SSOIdentityException("During user properties listing: " + ioE.getMessage());

        } catch (Exception e) {
            logger.error("Exception while listing user properties", e);
            throw new SSOIdentityException("During user properties listing: " + e.getMessage());

        } finally {
            closeResultSet(result);
            closeStatement(stmt);
        }


    }

    // ------------------------------------------------------------------------------------------
    // Protected DB utils.
    // ------------------------------------------------------------------------------------------

    /**
     * Builds an array of credentials based on a ResultSet
     * Column names are used to build a credential.
     */
    protected Credential[] fetchCredentials(ResultSet rs)
            throws SQLException, IOException, SSOAuthenticationException {

        if (rs.next()) {

            List creds = new ArrayList();
            ResultSetMetaData md = rs.getMetaData();

            // Each column is a credential, the column name is used as credential name ...
            for (int i = 1 ; i <= md.getColumnCount() ; i++) {
                String cName = md.getColumnName(i);
                String cValue = rs.getString(i);
                Credential c = _cp.newCredential(cName, cValue);
                creds.add(c);
            }

            return (Credential[]) creds.toArray(new Credential[creds.size()]);
        }

        return new Credential[0];

    }

    /**
     * Builds an array of name-value pairs on a ResultSet
     * The resultset must have two columns, the first one contains names and the second one values.
     */
    protected SSONameValuePair[] fetchSSONameValuePairs(ResultSet rs)
            throws SQLException, IOException, SSOAuthenticationException {
        List props = new ArrayList();

        while (rs.next()) {
            // First column is a name and second is a value.
            String cName = rs.getString(1);
            String cValue = rs.getString(2);
            SSONameValuePair prop = new SSONameValuePair (cName, cValue);
            props.add(prop);
        }

        return (SSONameValuePair[]) props.toArray(new SSONameValuePair[props.size()]);
    }


    /**
     * Builds a user based on a result set.
     * ResultSet must have one and only one record.
     */
    protected BaseRole[] fetchRoles(ResultSet rs)
            throws SQLException, IOException {

        List roles = new ArrayList();

        while (rs.next()) {

            BaseRole role = new BaseRoleImpl();
            String rolename = rs.getString(1);
            role.setName(rolename);

            roles.add(role);

        }

        return (BaseRole[]) roles.toArray(new BaseRole[roles.size()]);
    }

    /**
     * Builds a user based on a result set.
     */
    protected BaseUser fetchUser(ResultSet rs)
            throws SQLException, IOException {

        if (rs.next()) {
            BaseUser user = new BaseUserImpl();
            String username = rs.getString(1);
            user.setName(username);

            return user;
        }

        return null;
    }


    /**
     * Creates a new prepared statement for the received query string.
     *
     * @param query
     *
     * @throws SQLException
     */
    private PreparedStatement createPreparedStatement(String query)
            throws SQLException {

        if (logger.isDebugEnabled())
            logger.debug("[createPreparedStatement()] : " + "(" + query + ")");

        PreparedStatement stmt =
                _conn.prepareStatement(query + " ");

        return stmt;
    }

    protected void closeStatement(PreparedStatement stmt)
            throws SSOIdentityException {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException se) {
            if (logger.isDebugEnabled()) {
                logger.debug("Error clossing statement");
            }

            throw new SSOIdentityException("Error while clossing statement: \n " + se.getMessage());

        } catch (Exception e) {
            if (logger.isDebugEnabled()) {
                logger.debug("Error clossing statement");
            }

            throw new SSOIdentityException("Error while clossing statement: \n " + e.getMessage());
        }
    }


    protected void closeResultSet(ResultSet result)
            throws SSOIdentityException {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException se) {
            if (logger.isDebugEnabled()) {
                logger.debug("Error while clossing result set");
            }

            throw new SSOIdentityException("SQL Exception while closing\n" + se.getMessage());
        } catch (Exception e) {
            if (logger.isDebugEnabled()) {
                logger.debug("Error while clossing result set");
            }

            throw new SSOIdentityException("Exception while closing Result Set\n" + e.getMessage());

        }
    }

    /**
     * This util counts the number of times that the '?' char appears in the received query string.
     */
    protected int countQueryVariables(String qry) {
        StringTokenizer st = new StringTokenizer (qry, "?", true);
        int count = 0;
        while(st.hasMoreTokens()) {
            String tk = st.nextToken();
            if ("?".equals(tk)) {
                count ++;
            }
        }
        return count;
    }


}
