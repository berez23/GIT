/*
Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
All rights reserved.
Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

* Neither the name of the JOSSO team nor the names of its
  contributors may be used to endorse or promote products derived
  from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.auth.scheme;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.josso.auth.*;
import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.gateway.identity.exceptions.SSOIdentityException;

import javax.security.auth.Subject;
import java.security.Principal;

import java.util.Set;

/**
 * Specific authentiation schemes can extend this base implementation providing
 * specific logic in the authenticate method.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: AbstractAuthenticationScheme.java,v 1.5 2005/02/02 16:21:57 sgonzalez Exp $
 */
public abstract class AbstractAuthenticationScheme implements AuthenticationScheme {

    private static final Log logger = LogFactory.getLog(AbstractAuthenticationScheme.class);

    private boolean _authenticated;

    // The subjtect beeng authenticated.
    protected Subject _subject;

    // The credential store used to retrieve konw or trusted credentials.
    protected CredentialStore _credentialStore;
    protected CredentialStoreKeyAdapter _credentialStoreKeyAdapter ;

    // The credentials provided by the user as input.
    protected Credential[] _inputCredentials;
    private String _name;

    /**
     * Initializes the authentication scheme.
     *
     * @param userCredentials
     */
    public void initialize(Credential[] userCredentials, Subject s) {
        _inputCredentials = userCredentials;
        _subject = s;
        _authenticated = false;

    }

    /**
     * Confirms the authentication process, populates the Subject with Principal and Credentials information.
     */
    public void confirm() {

        // Only add security information if authentication was successful.
        if (!isAuthenticated()) {
            if (logger.isDebugEnabled())
                logger.debug("[cancel()], ignored. Not authenticated for this scheme.");
            return;
        }

        // Get the username associated with input credentials.
        Principal principal = getPrincipal();

        // Public / Private credentials.
        Credential[] pc = null;

        // Populate the Subject
        Set principals = _subject.getPrincipals();
        principals.add(principal);

        // Private credentials :
        Set privateCredentials = _subject.getPrivateCredentials();
        pc = getPrivateCredentials();
        for (int i = 0; i < pc.length; i++) {
            privateCredentials.add(pc[i]);
        }

        // Public credentials :
        Set publicCredentials = _subject.getPublicCredentials();
        pc = getPublicCredentials();
        for (int i = 0; i < pc.length; i++) {
            publicCredentials.add(pc[i]);
        }

        if (logger.isDebugEnabled())
            logger.debug("[confirm()], ok");


    }

    /**
     * Cancels the authentication process.
     */
    public void cancel() {
        if (logger.isDebugEnabled())
            logger.debug("[cancel()], ok");
        setAuthenticated(false);
    }

    // ------------------------------------------------------------------------------
    // Protected utils
    // ------------------------------------------------------------------------------

    /**
     * Gets the authentication status associated to the scheme. Subclasses should set this flag
     * in the authenticate method implementation.
     */
    protected boolean isAuthenticated() {
        return _authenticated;
    }

    /**
     * Sets the authentication status associated to the scheme. Subclasses should set this flag
     * in the authenticate method implementation.
     */
    protected void setAuthenticated(boolean a) {
        _authenticated = a;
    }

    /**
     * Utility to load credentials from the store.
     *
     * @return the array of konw credentials associated with the authenticated Principal.
     *
     * @throws SSOAuthenticationException if an error occures while accessing the store.
     */
    protected Credential[] getKnownCredentials() throws SSOAuthenticationException {
        try {
            CredentialKey key = getCredentialStoreKeyAdapter().getKeyForPrincipal(getPrincipal());
            return _credentialStore.loadCredentials(key);
        } catch (SSOIdentityException e) {
            throw new SSOAuthenticationException(e.getMessage(), e);
        }
    }

    protected CredentialStore getCredentialStore() {
        return _credentialStore;
    }

    protected CredentialStoreKeyAdapter getCredentialStoreKeyAdapter() {
        return _credentialStoreKeyAdapter;
    }

    public void setCredentialStore(CredentialStore c) {
        _credentialStore = c;
    }

    public void setCredentialStoreKeyAdapter(CredentialStoreKeyAdapter a) {
        _credentialStoreKeyAdapter = a;
    }


    /**
     * Clones this authentication scheme.
     */
    public Object clone() {
        try { return super.clone(); }
        catch (CloneNotSupportedException e) { /* Ignore this ... */ }
        return null;
    }

    /*------------------------------------------------------------ Properties

    /**
     * Sets Authentication Scheme name
     */
    public void setName(String name) {
        logger.debug("setName() = " + name );
        _name = name;
    }

    /**
     * Obtains the Authentication Scheme name
     */
    public String getName() {
        return _name;
    }


}
