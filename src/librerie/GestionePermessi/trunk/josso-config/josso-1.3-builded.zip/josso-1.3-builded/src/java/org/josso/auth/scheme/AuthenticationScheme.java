/*
Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
All rights reserved.
Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

* Neither the name of the JOSSO team nor the names of its
  contributors may be used to endorse or promote products derived
  from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.auth.scheme;

import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.auth.Credential;
import org.josso.auth.CredentialStoreKeyAdapter;
import org.josso.auth.CredentialStore;
import org.josso.auth.CredentialProvider;

import javax.security.auth.Subject;
import java.security.Principal;

/**
 * Represents any authentication scheme, like user&password, certificate, kerveros 5, etc.
 * The authentication mechanism should be :
 *
 * 1. Initialize the AuthenticationScheme withe input credentials received from user.
 * 2. Optionally get the principal name derived from input credentials.
 * 3. Authenticate the user providing known or trusted credentials.
 * 4. Confirm or cancel the authentication process.
 * 5. Optinalliy get private / public credentials.
 *
 * Authentication schemes are cloneable, a first instance is used as a "prototype" to build new ones.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: AuthenticationScheme.java,v 1.12 2005/04/20 18:54:49 sgonzalez Exp $
 */

public interface AuthenticationScheme extends CredentialProvider, Cloneable {

    /**
     * Obtains the Authentication Scheme name
     */
    String getName();

    /**
     * Initializes this authentication scheme with the received credentials.
     *
     * @param inputCredentials the list of credentials used to authenticate the user, like username and password.
     *
     */
    void initialize (Credential[] inputCredentials, Subject s);

    /**
     * This method authenticates a user based on its credentials.
     *
     * @return The Principal associated with the user if the authentication success, null otherwise.
     */
    boolean authenticate()
            throws SSOAuthenticationException;

    /**
     * Confirms the authentication process, populates the subject with Principal and credential information.
     */
    void confirm();

    /**
     * Cancels the authentication process.
     */
    void cancel();

    /**
     * This method returns the principal name derived from input credentials.
     *
     */
    Principal getPrincipal();

    /**
     * Returns an array of private credentials that can be associated to a Subject by the authenticator.
     *
     */
    Credential[] getPrivateCredentials();

    /**
     * Returns an array of public credentials that can be associated to a Subject by the authenticator.
     *
     */
    Credential[] getPublicCredentials();

    /**
     * Setter for the CredentialStore used by the scheme to retrieve known credentials if necessary.
     */
    void setCredentialStore(CredentialStore cs);

    /**
     * Setter for the CredentialStoreKeyAdapter used by the scheme to retrieve known credentials if necessary.
     */
    void setCredentialStoreKeyAdapter(CredentialStoreKeyAdapter a);

    /**
     * Creates a new credential based on its name and value.
     */
    Credential newCredential(String name, Object value);

    /**
     * All authenticatio schemes should be cloneable.
     */
    Object clone();


}
