/*
   Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
   All rights reserved.
   Redistribution and use in source and binary forms, with or
   without modification, are permitted provided that the following
   conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the JOSSO team nor the names of its
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
   BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
   OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.tc50.agent;

import org.apache.catalina.Context;
import org.apache.catalina.Container;
import org.apache.catalina.Realm;
import org.josso.agent.AbstractSSOAgent;
import org.josso.agent.SSOAgentRequest;

import java.security.Principal;

/**
 * Catalina SSO Agent Implementation that authenticates using the configured Catalina Realm's
 * Gateway SSO Login module.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: CatalinaSSOAgent.java,v 1.1 2005/04/20 21:27:37 sgonzalez Exp $
 */
public class CatalinaSSOAgent extends AbstractSSOAgent {

    private Container _container;

    public CatalinaSSOAgent() {
        super();
    }


    public CatalinaSSOAgent(Container container) {
        super();
        _container  = container;

    }

    public void start() {
        super.start();
        // Add context config as partner app ...
        if (_container instanceof Context) {
            Context context = (Context) _container;
            _cfg.addSSOPartnerApp(context.getPath(), null);
        }
    }

    /**
     * Sets the Catalina Context to be used by the authenticator.
     *
     * @param container
     */
    public void setCatalinaContainer(Container container) {
        _container = container;

    }

    /**
     * Authenticates the Single Sign-on Session by calling the
     * configured Realm for the Catalina Context. The configured Realm
     * should be the JAAS one so that the GatewayLoginModule can act
     * and validate de given SSO Session Identifier in the Gateway.
     *
     * @param request
     * @return the authenticated principal.
     */
    protected Principal authenticate(SSOAgentRequest request) {
        CatalinaSSOAgentRequest r = (CatalinaSSOAgentRequest) request;
        Context c = r.getContext();

        // Invoke authentication
        Realm realm = c.getRealm();

        if (debug > 0)
            log("Using realm : " + realm.getClass().getName() + " SSOSID : " + r.getSessionId());

        Principal p = realm.authenticate(r.getSessionId(), r.getSessionId());

        if (debug > 0)
            log("Received principal : " + p + "[" + ( p != null ? p.getClass().getName() : "<null>" ) +"]");

        return p;
    }

    protected void log(String message) {
        org.apache.catalina.Logger logger = _container.getLogger();
        if (logger != null)
            logger.log(this.toString() + ": " + message);
        else
            System.out.println(this.toString() + ": " + message);
    }

    protected void log(String message, Throwable throwable) {
        org.apache.catalina.Logger logger = _container.getLogger();
        if (logger != null)
            logger.log(this.toString() + ": " + message, throwable);
        else
            System.out.println(this.toString() + ": " + message);
    }

    /**
     * Return a String rendering of this object.
     */
    public String toString() {

        StringBuffer sb = new StringBuffer("CatalinaSSOAgent[");
        sb.append(_container.getName());
        sb.append("]");
        return (sb.toString());

    }


}
