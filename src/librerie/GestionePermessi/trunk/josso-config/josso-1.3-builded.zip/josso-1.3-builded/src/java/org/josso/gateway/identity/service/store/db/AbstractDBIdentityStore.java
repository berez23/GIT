/*
Copyright (c) 2004-2005, Novascope S.A. and the JOSSO team
All rights reserved.
Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the
  distribution.

* Neither the name of the JOSSO team nor the names of its
  contributors may be used to endorse or promote products derived
  from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package org.josso.gateway.identity.service.store.db;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.josso.gateway.identity.service.BaseUser;
import org.josso.gateway.identity.service.BaseRole;
import org.josso.gateway.identity.service.store.UserKey;
import org.josso.gateway.identity.service.store.SimpleUserKey;
import org.josso.gateway.identity.service.store.AbstractStore;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.SSONameValuePair;
import org.josso.auth.Credential;
import org.josso.auth.CredentialKey;
import org.josso.auth.CredentialProvider;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * DB implementation of an IdentityStore and CredentialStore.
 * Three querys have to be configured to the store :
 *
 * - UserQueryString : Used to validate user existence = "SELECT MY_USER FROM MY_USER_TABLE WHERE MY_USR = '?'"
 * - RolesQueryString : Used to retrieve user's roles = "SELECT MY_ROLE FROM MY_USER_ROLES_TABLE WHERE MY_USER = '?'";
 * - CredentialQueryString : Used to retrieve known credentials for a user.
 * This query depends on the configured authentication scheme.  For a user / password based scheme the query could be
 * "SELECT MY_USER AS USERNAME, MY_PWD AS PASSWORD FROM MY_USER_TABLE WHERE MY_USER ='?';
 * The alias is important as is used to map the retrieved value to a specific credential type.
 *
 * Subclasses have to implement getDBConnection() method, this allows jdbc/datasource based stores.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: AbstractDBIdentityStore.java,v 1.5 2005/02/02 16:21:59 sgonzalez Exp $
 */

public abstract class AbstractDBIdentityStore extends AbstractStore {

    private static final Log logger = LogFactory.getLog(AbstractDBIdentityStore.class);

    private String _userQueryString;
    private String _rolesQueryString;
    private String _credentialsQueryString;
    private String _userPropertiesQueryString;

    public BaseUser loadUser(UserKey key) throws NoSuchUserException, SSOIdentityException {
        Connection c = null;
        try {
            if (! (key instanceof SimpleUserKey)) {
                throw new SSOIdentityException("Unsupported key type : " + key.getClass().getName());
            }
            
            c = getDBConnection();
            IdentityDAO dao = getIdentityDAO(c, getAuthenticationScheme());
            BaseUser user = dao.selectUser((SimpleUserKey)key);

            // Optionally find user properties.
            if (getUserPropertiesQueryString() != null) {
                SSONameValuePair[] props = dao.selectUserProperties((SimpleUserKey)key);
                user.setProperties(props);
            }

            return user;

        } finally {
            closeDBConnection(c);
        }
    }

    public BaseRole[] findRolesByUserKey(UserKey key) throws SSOIdentityException {
        Connection c = null;
        try {
            if (! (key instanceof SimpleUserKey)) {
                throw new SSOIdentityException("Unsupported key type : " + key.getClass().getName());
            }

            c = getDBConnection();
            IdentityDAO dao = getIdentityDAO(c, getAuthenticationScheme());
            BaseRole[] roles = dao.selectRolesByUserKey((SimpleUserKey)key);
            return roles;

        } finally {
            closeDBConnection(c);
        }
    }

    public Credential[] loadCredentials(CredentialKey key) throws SSOIdentityException {
        Connection c = null;
        try {
            if (! (key instanceof SimpleUserKey)) {
                throw new SSOIdentityException("Unsupported key type : " + key.getClass().getName());
            }

            c = getDBConnection();
            IdentityDAO dao = getIdentityDAO(c, getAuthenticationScheme());
            Credential[] credentials = dao.selectCredentials((SimpleUserKey)key);
            return credentials;

        } finally {
            closeDBConnection(c);
        }

    }

    // -----------------------------------------------------------------------------------
    // Protected utils.
    // -----------------------------------------------------------------------------------

    /**
     * Subclasses must implement getDBConnection() method.
     */
    protected abstract Connection getDBConnection() throws SSOIdentityException ;

    protected IdentityDAO getIdentityDAO(Connection c, CredentialProvider cp) {
        return new IdentityDAO(c,
                cp,
                getUserQueryString(),
                getRolesQueryString(),
                getCredentialsQueryString(),
                getUserPropertiesQueryString());
    }




    /**
     * Close the given db connection.
     *
     * @param dbConnection
     * @throws SSOIdentityException
     */
    protected void closeDBConnection(Connection dbConnection) throws SSOIdentityException {

        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
            }
        }
        catch (SQLException se) {
            if (logger.isDebugEnabled()) {logger.debug("Error while clossing connection"); }

            throw new SSOIdentityException(
                "Error while clossing connection\n" + se.getMessage());
        }
        catch (Exception e) {
            if (logger.isDebugEnabled()) {logger.debug("Error while clossing connection"); }

            throw new SSOIdentityException(
                "Error while clossing connection\n" + e.getMessage());

        }

    }

    // ---------------------------------------------------------------
    // Configuration properties.
    // ---------------------------------------------------------------
    public String getUserQueryString() {
        return _userQueryString;
    }

    public String getRolesQueryString() {
        return _rolesQueryString;
    }

    public String getCredentialsQueryString() {
        return _credentialsQueryString;
    }

    public String getUserPropertiesQueryString() {
        return _userPropertiesQueryString;
    }

    public void setUserQueryString(String userQueryString) {
        _userQueryString = userQueryString;
    }

    public void setRolesQueryString(String rolesQueryString) {
        _rolesQueryString = rolesQueryString;
    }

    public void setCredentialsQueryString(String credentialsQueryString) {
        _credentialsQueryString = credentialsQueryString;
    }

    public void setUserPropertiesQueryString(String userPropertiesQueryString) {
        _userPropertiesQueryString = userPropertiesQueryString;
    }


}
